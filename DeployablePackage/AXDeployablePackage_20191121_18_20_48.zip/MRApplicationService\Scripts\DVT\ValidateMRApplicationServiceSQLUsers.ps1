<#
	.Synopsis
	DVT for verifying that SQL User roles and permissions are minimally sufficient for MR's use
#>
[CmdletBinding()]
Param
(
	# DVT log file path.
	[string]
	$Log
)

$scriptName = (Get-Item $PSCommandPath).BaseName
. "$PSScriptRoot\Helpers\ScriptSetup.ps1"
Set-LogPath -FullLogPath $Log
Write-EnvironmentDataToLog
. "$PSScriptRoot\Helpers\DVTScriptSetup.ps1"
Initialize-DVTScript
. "$PSScriptRoot\Helpers\SqlHelpers.ps1"

<#
	.Synopsis
	Return a string or null properly formatted for use in a SQL query
#>
function Get-SqlStringOrNull
{	
	[CmdletBinding()]
	Param
	(
        # PowerShell string or $null to convert to a SQL string value or null
        [string]
        $value
	)

	if($value)
	{
		return "'" + $value + "'"
	}
	else
	{
		return 'null';
	}
}

<#
	.Synopsis
	Return a query string to select from HAS_PERMS_BY_NAME
#>
function Get-SqlPermissionQuery
{
	[CmdletBinding()]
	Param
	(
		# Array of arguments for HAS_PERMS_BY_NAME
		[array]
        $Permission
	)

	if($Permission.Length -ge 3)
	{
		$securable = Get-SqlStringOrNull($Permission[0])
		$securable_class = Get-SqlStringOrNull($Permission[1])
		$permissionName = Get-SqlStringOrNull($Permission[2])
	}

	if($Permission.Length -eq 3)
	{
		return "select HAS_PERMS_BY_NAME ($securable, $securable_class, $permissionName);"
	}
	elseif($Permission.Length -eq 5) 
	{
		$subsecurable = Get-SqlStringOrNull($Permission[3])
		$subsecurable_class = Get-SqlStringOrNull($Permission[4])
		return "select HAS_PERMS_BY_NAME ($securable, $securable_class, $permissionName, $subsecurable, $subsecurable_class);"
	}
	else 
	{
		$numargs = $Permission.Length
		throw "Invalid permission arguments, expected 3 or 5 but found $numargs"
	}
}

<#
	.Synopsis
	Check a user's permissions to objects in a database
#>
function Confirm-SQLUserPermissions
{
	[CmdletBinding()]
	Param
	(
		# Database name
        [string]
        [ValidateNotNullOrEmpty()]
        $DatabaseName,

        # SQL server instance name
        [string]
        [ValidateNotNullOrEmpty()]
        $ServerInstance,

		# Type of user being tested
        [string]
		[ValidateSet('AXRuntimeUser', 'AXAdminUser', 'MRRuntimeUser', 'MRAdminUser')]
        $UserType,

        # SQL User Name
        [string]
        $UserName,

		# SQL User Password
        [string]
        $Password,

		# Array of permissions (arguments to HAS_PERMS_BY_NAME) to check 
		[array]
        [ValidateNotNull()]
        $Permissions,

        # Flag that indicates to pass with warning on dvt failure or fail 
        [switch]
        $PassWithWarning
	)

	$testName = "Confirm-SQLUserPermissions.${UserType}"
	$pass = $true
	if ($UserName -and $Password)
	{
		$credential = New-Object System.Management.Automation.PSCredential($UserName, ($Password | ConvertTo-SecureString))
		$connectionString = Get-ConnectionString -Server $ServerInstance -Database $DatabaseName -Credential $credential
		$messages = @()
		$message = ''
		$permissions | foreach {
			$query = Get-SqlPermissionQuery($_)
			$ok = Invoke-SQLQuery -ConnectionStr $connectionString -Query $query -ResultReader (Get-ExecuteScalarReader)
			if(([DBNull]::Value).Equals($ok))
			{
				$pass = $false
				throw "Invalid permission query did not produce a result: $query"
			}
			elseif(!$ok)
			{
				Write-LogMessage "User $UserName permission check failed using $query"
				$messages += "Permission check failed using $query"
			}
		}

		if($messages.Length -gt 0)
		{
			$pass = $false
			$message = [System.String]::Format("For user {0}:{1}{2}", $UserName, [System.Environment]::NewLine, ($messages | Out-String -Width 500))
		}

		if($PassWithWarning)
		{
			Invoke-Test -TestName $testName -Actual { $true } -Expected True -Message $message -WriteMessageOnSuccess -AddToRun $resultsCollection
		}
		else
		{
			Invoke-Test -TestName $testName -Actual { $messages.Length -eq 0 } -Expected True -Message $message -AddToRun $resultsCollection
		}
	}
	else
	{
		$message = "$UserType user data was not present in input file. Test skipped."
		Write-LogMessage $message
		# Log a passing test result so the result file contains a record of the skipped test
		Invoke-Test -TestName $testName -Actual { $true } -Expected True -Message $message -WriteMessageOnSuccess -AddToRun $resultsCollection
	}

	return $pass
}

function Confirm-SQLUserConnection
{
	[CmdletBinding()]
	Param
	(
		# Database name
		[string]
		[ValidateNotNullOrEmpty()]
		$DatabaseName,

		# SQL server instance name
		[string]
		[ValidateNotNullOrEmpty()]
		$ServerInstance,

		# Type of user being tested
		[string]
		[ValidateSet('AXRuntimeUser', 'AXAdminUser', 'MRRuntimeUser', 'MRAdminUser')]
		$UserType,

		# SQL User Name
		[string]
		$UserName,

		# SQL User Password
		[string]
		$Password,

		# Flag that indicates to pass with warning on dvt failure or fail 
		[switch]
		$PassWithWarning
	)

	$testName = "Confirm-SQLUserConnection.${UserType}"
	$pass = $false
	if ($UserName -and $Password)
	{
		$credential = New-Object System.Management.Automation.PSCredential($UserName, ($Password | ConvertTo-SecureString))
		$connectionString = Get-ConnectionString -Server $ServerInstance -Database $DatabaseName -Credential $credential
		$message = ''
		$query = 'select 1 -- just checking connection'
		try
		{
			$ok = Invoke-SQLQuery -ConnectionStr $connectionString -Query $query -ResultReader (Get-ExecuteScalarReader)
			if(([DBNull]::Value).Equals($ok))
			{
				throw "Query did not produce a result: $query"
			}
			elseif($ok)
			{
				$pass = $true
			}
			else
			{
				$message = "User $UserName connection check failed using $query"
				Write-LogMessage $message
			}
		}
		catch
		{
			# This test shouldn't throw, just log the appropriate error
			$message = "User $UserName connection check failed due to an exception. $_"
			Write-LogMessage $message
		}

		if($PassWithWarning)
		{
			Invoke-Test -TestName $testName -Actual { $true } -Expected True -Message $message -WriteMessageOnSuccess -AddToRun $resultsCollection
		}
		else
		{
			Invoke-Test -TestName $testName -Actual { $message.Length -eq 0 } -Expected True -Message $message -AddToRun $resultsCollection
		}
	}
	else
	{
		$message = "$UserType user data was not present in input file. Test skipped."
		Write-LogMessage $message
		# Log a passing test result so the result file contains a record of the skipped test
		Invoke-Test -TestName $testName -Actual { $true } -Expected True -Message $message -WriteMessageOnSuccess -AddToRun $resultsCollection
		$pass = $true
	}

	return $pass
}

try
{
	# AX Database -----------------------------------------------------------------------------------------
	$axDatabaseServer = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.DbServer'
	$axDatabaseName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.Database'

	#
	# Test permissions for the AX Admin User
	#
	$axUserName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.SqlUser'
	$axPassword = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.SqlPwd'
	$axPerms = ($null, 'DATABASE', 'CREATE TABLE'),
			($null, 'DATABASE', 'CREATE VIEW'),
			('ReportingIntegration', 'schema', 'ALTER'),
			('ReportingIntegration', 'schema', 'DELETE'),
			('ReportingIntegration', 'schema', 'INSERT'),
			('ReportingIntegration', 'schema', 'SELECT'),
			('ReportingIntegration', 'schema', 'UPDATE'),
			('db_owner', 'schema', 'ALTER'),
			('db_owner', 'schema', 'DELETE'),
			('db_owner', 'schema', 'INSERT'),
			('db_owner', 'schema', 'SELECT'),
			('db_owner', 'schema', 'UPDATE'),
			('dbo', 'schema', 'ALTER'),
			('dbo', 'schema', 'DELETE'),
			('dbo', 'schema', 'INSERT'),
			('dbo', 'schema', 'SELECT'),
			('dbo', 'schema', 'UPDATE'),
			('dbo', 'schema', 'REFERENCES'),
			('dbo', 'schema', 'VIEW CHANGE TRACKING')

	Confirm-SQLUserConnection -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserType AXAdminUser -UserName $axUserName -Password $axPassword -PassWithWarning
	$axAdminWorks = Confirm-SQLUserPermissions -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserType AXAdminUser -UserName $axUserName -Password $axPassword -Permissions $axPerms -PassWithWarning
	
	#
	# Test permissions for the AXMRRuntimeUser
	#
	$axRuntimeUserName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.Runtime.DataAccess.SqlUser'
	$axRuntimePassword = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.Runtime.DataAccess.SqlPwd'
	$axRuntimePerms = ($null, 'DATABASE', 'CREATE TABLE'),
			($null, 'DATABASE', 'CREATE VIEW'),
			('ReportingIntegration', 'schema', 'ALTER'),
			('ReportingIntegration', 'schema', 'DELETE'),
			('ReportingIntegration', 'schema', 'INSERT'),
			('ReportingIntegration', 'schema', 'SELECT'),
			('ReportingIntegration', 'schema', 'UPDATE'),
			('dbo', 'schema', 'ALTER'),
			('dbo', 'schema', 'DELETE'),
			('dbo', 'schema', 'INSERT'),
			('dbo', 'schema', 'SELECT'),
			('dbo', 'schema', 'UPDATE'),
			('dbo', 'schema', 'REFERENCES'),
			('dbo', 'schema', 'VIEW CHANGE TRACKING')

	$userResult = Confirm-SQLUserConnection -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserType AXRuntimeUser -UserName $axRuntimeUserName -Password $axRuntimePassword -PassWithWarning:$axAdminWorks
	if($userResult.GetType().Name -ne 'Boolean' -or -not $userResult)
	{
		# If we have access to the admin user, attempt to heal the issue
		if($axAdminWorks)
		{
			Write-LogMessage -Message "Attempting self-heal action for AXRuntimeUser connection issues."
			try
			{
				$adminConnectionString = Get-ConnectionString -Server $axDatabaseServer -Database $axDatabaseName -Credential (New-Object System.Management.Automation.PSCredential($axUserName, ($axPassword | ConvertTo-SecureString)))
				$runtimeCredential = New-Object System.Management.Automation.PSCredential($axRuntimeUserName, ($axRuntimePassword | ConvertTo-SecureString))			
				Update-SqlUserPassword -AdminConnectionString $adminConnectionString -Credential $runtimeCredential
			}
			catch
			{
				# Heal action shouldn't throw, just log it
				Write-LogMessage = "DVT self-heal failed due to an exception. $_"
			}
			Confirm-SQLUserConnection -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserType AXRuntimeUser -UserName $axRuntimeUserName -Password $axRuntimePassword
		}
	}
	
	$userResult = Confirm-SQLUserPermissions -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserType AXRuntimeUser -UserName $axRuntimeUserName -Password $axRuntimePassword -Permissions $axRuntimePerms -PassWithWarning:$axAdminWorks
	if($userResult.GetType().Name -ne 'Boolean' -or -not $userResult)
	{
		# If we have access to the admin user, attempt to heal the issue
		if($axAdminWorks)
		{
			Write-LogMessage -Message "Attempting self-heal action for AXRuntimeUser permission issues."
			try
			{
				$adminConnectionString = Get-ConnectionString -Server $axDatabaseServer -Database $axDatabaseName -Credential (New-Object System.Management.Automation.PSCredential($axUserName, ($axPassword | ConvertTo-SecureString)))
				$runtimeCredential = New-Object System.Management.Automation.PSCredential($axRuntimeUserName, ($axRuntimePassword | ConvertTo-SecureString))
				$runtimeConnectionString = Get-ConnectionString -Server $axDatabaseServer -Database $axDatabaseName -Credential $runtimeCredential
				Update-AxMrRuntimeUserPermissions -AdminConnectionString $adminConnectionString -RuntimeConnectionString $runtimeConnectionString
			}
			catch
			{
				# Heal action shouldn't throw, just log it
				Write-LogMessage = "DVT self-heal failed due to an exception. $_"
			}
			Confirm-SQLUserPermissions -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserType AXRuntimeUser -UserName $axRuntimeUserName -Password $axRuntimePassword -Permissions $axRuntimePerms
		}
	}

	
	# MR Database -------------------------------------------------------------------------------------
	$mrDatabaseServer = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.DataAccess.DbServer'
	$mrDatabaseName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.DataAccess.Database'
	
	#
	# Test permissions for the MR Admin User
	#
	$mrUserName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.DataAccess.SqlUser'
	$mrPassword = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.DataAccess.SqlPwd'
	$mrPerms = ($null, 'DATABASE', 'CREATE TABLE'),
			($null, 'DATABASE', 'CREATE VIEW'),
			('Datamart', 'schema', 'ALTER'),
			('Datamart', 'schema', 'DELETE'),
			('Datamart', 'schema', 'INSERT'),
			('Datamart', 'schema', 'SELECT'),
			('Datamart', 'schema', 'UPDATE'),
			('Connector', 'schema', 'ALTER'),
			('Connector', 'schema', 'DELETE'),
			('Connector', 'schema', 'INSERT'),
			('Connector', 'schema', 'SELECT'),
			('Connector', 'schema', 'UPDATE'),
			('Reporting', 'schema', 'ALTER'),
			('Reporting', 'schema', 'DELETE'),
			('Reporting', 'schema', 'INSERT'),
			('Reporting', 'schema', 'SELECT'),
			('Reporting', 'schema', 'UPDATE'),
			('Scheduling', 'schema', 'ALTER'),
			('Scheduling', 'schema', 'DELETE'),
			('Scheduling', 'schema', 'INSERT'),
			('Scheduling', 'schema', 'SELECT'),
			('Scheduling', 'schema', 'UPDATE')

	Confirm-SQLUserConnection -DatabaseName $mrDatabaseName -ServerInstance $mrDatabaseServer -UserType MRAdminUser -UserName $mrUserName -Password $mrPassword -PassWithWarning
    $mrAdminWorks = Confirm-SQLUserPermissions -DatabaseName $mrDatabaseName -ServerInstance $mrDatabaseServer -UserType MRAdminUser -UserName $mrUserName -Password $mrPassword -Permissions $mrPerms -PassWithWarning

	#
	# Test permissions for the MRRuntimeUser
	#
	$mrRuntimeUserName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.RunTime.DataAccess.SqlUser'
	$mrRuntimePassword = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.RunTime.DataAccess.SqlPwd'
	$mrRuntimePerms = ('Datamart','schema', 'TAKE OWNERSHIP'),
			('Connector','schema', 'TAKE OWNERSHIP'),
			('Reporting','schema', 'TAKE OWNERSHIP'),
			('Scheduling','schema', 'TAKE OWNERSHIP'),
			($null, 'DATABASE', 'VIEW DATABASE STATE'),
			($null, 'DATABASE', 'VIEW DEFINITION'),
			($null, 'DATABASE', 'CREATE TABLE')

			# For testing purposes, the following can be passed to see the effects of a negative test
			#($null, $null, 'VIEW SERVER STATE') # produces zero (0) since only the sysadmin typically has this permission
			#($null, $null, 'VIEW SERVER STATE') # produces zero (0) since only the sysadmin typically has this permission
			#($null, $null, 'VIEW SERVER STATEMENT') # throws exception for no result (query returns null)
			#($null, 'VIEW SERVER STATE') # throws exception for 2 arguments, must be 3 or 5

	$userResult = Confirm-SQLUserConnection -DatabaseName $mrDatabaseName -ServerInstance $mrDatabaseServer -UserType MRRuntimeUser -UserName $mrRuntimeUserName -Password $mrRuntimePassword -PassWithWarning:$mrAdminWorks
	if($userResult.GetType().Name -ne 'Boolean' -or -not $userResult)
	{
		# If we have access to the admin user, attempt to heal the issue
		if($mrAdminWorks)
		{
			Write-LogMessage -Message "Attempting self-heal action for MRRuntimeUser connection issues."
			try
			{
				$adminConnectionString = Get-ConnectionString -Server $mrDatabaseServer -Database $mrDatabaseName -Credential (New-Object System.Management.Automation.PSCredential($mrUserName, ($mrPassword | ConvertTo-SecureString)))
				$runtimeCredential = New-Object System.Management.Automation.PSCredential($mrRuntimeUserName, ($mrRuntimePassword | ConvertTo-SecureString))
				Update-SqlUserPassword -AdminConnectionString $adminConnectionString -Credential $runtimeCredential
			}
			catch
			{
				# Heal action shouldn't throw, just log it
				Write-LogMessage = "DVT self-heal failed due to an exception. $_"
			}
			Confirm-SQLUserConnection -DatabaseName $mrDatabaseName -ServerInstance $mrDatabaseServer -UserType MRRuntimeUser -UserName $mrRuntimeUserName -Password $mrRuntimePassword
		}
	}

	$userResult = Confirm-SQLUserPermissions -DatabaseName $mrDatabaseName -ServerInstance $mrDatabaseServer -UserType MRRuntimeUser -UserName $mrRuntimeUserName -Password $mrRuntimePassword -Permissions $mrRuntimePerms -PassWithWarning:$mrAdminWorks
	if($userResult.GetType().Name -ne 'Boolean' -or -not $userResult)	
	{
		# If we have access to the admin user, attempt to heal the issue
		if($mrAdminWorks)
		{
			Write-LogMessage -Message "Attempting self-heal action for MRRuntimeUser permission issues."
			try
			{
				$adminConnectionString = Get-ConnectionString -Server $mrDatabaseServer -Database $mrDatabaseName -Credential (New-Object System.Management.Automation.PSCredential($mrUserName, ($mrPassword | ConvertTo-SecureString)))	
				Update-MrRuntimeUserPermissions -AdminConnectionString $adminConnectionString -RuntimeUserName $mrRuntimeUserName
			}
			catch
			{
				# Heal action shouldn't throw, just log it
				Write-LogMessage = "DVT self-heal failed due to an exception. $_"
			}
			Confirm-SQLUserPermissions -DatabaseName $mrDatabaseName -ServerInstance $mrDatabaseServer -UserType MRRuntimeUser -UserName $mrRuntimeUserName -Password $mrRuntimePassword -Permissions $mrRuntimePerms
		}
	}
}
catch
{ 
	Add-ExceptionFailureToTestRun -Exception $_ -TestName $scriptName -AddToRun $resultsCollection
}

. "$PSScriptRoot\Helpers\DVTResultHandling.ps1"
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCj+JvsoKNxb9CH
# /Eu7TCA2MI6vV7GEF2sggK1I4F6Sl6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgywA7opX6
# E/Ygp8OLSpvsGKiMJnbEu7Lo/utFOtF+tjcwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQAuNhqxevEvBkGtKvx1VvSN0LxjSmz7FNsm+21sG5I5pc8Hk97y
# kVNzyV8ppXDtCFrz5ryu8nRz6PbVN9BX1KcbTxPTUTBigtCDirOdRLURsftZX7D1
# 9HWMAheEIT1ucjHKN6WlvIOVJJXgmbLh5M4DWUgTCApndjf/7r4V72yaRY8jwLOC
# 0i0FBk/D19NPYMJDruk/iJOToyXhrt2JDhjJ7n/WxH9Lyu60NwAy1Nu0WOxeAGVH
# 17VPkztOhvxFs+FyohP3SerNZyEtk/XBEcWRfvpW81klyzWKqjqkvLbZo5shrNkQ
# unkkwMRDMojFTD6W5u+17/h5ShDr8B9bc3ByoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEINgjvERB1NXI8sfDLkkRiC7qhw+1aZRqb00EFYYgCGamAgZd
# Xsa3zQYYEzIwMTkwOTE3MTkyMDAxLjMyMVowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjE3
# OUUtNEJCMC04MjQ2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADbqm3jIn80ACUAAAAAANswDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNjUzWhcNMTkxMTIzMjAyNjUzWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00QkIwLTgyNDYxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCnoZqQDJgki0s2bs39O6xPVFz+Uwqi0RAwzqog
# MN6WuZEmCnUQMJ0JrwMOJRQNnE3wi4xS/c50t/ifvAlhtospxxCIq1YJA6+pxtfB
# 9vK7xu3Y3aETqh1jZmPMsz92BfpIiL+Uau4H12AmLG/tMht+8YFug30ixwTfKCat
# Bmd3O+SeEohlYiBf97aJVD9rPSPlKWUhrDkdpUUMsQYU03Wr764ilEbLUc9zwP/z
# /6wtPI+RqTX837fUquU4ylD5F70/rkRh6K3WOrHWsQqi476BGGKNjQyiwlxDwt5v
# CwUiu1ldAk0sI9wKiTQv7HobNvot2RdvZHMx9YrTsyUvqk0LAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUsrrfHYBcc6bNtu3kHIyt3ipDA0gwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAFULCmp29GWB+IkeJJOmBldVebldjUZv6R+yXk1kxTFhpIBUB
# /QCZFORPrhHy4I63UDKvzcnBOECKtHG9B1Z2Dijxp4rxQ4ZmnWR9WgUFkH/w5b4s
# hxoSA/X2qp7TzgLZudYwBr56Ox+MRs3e0s5rLwPYYMPc63bIgrZMdbObgj3FRXRA
# BYvqEvTS5NjRQubrTyuiRzjS5BTQ6QQWLL+T3dQ9g8mNST4EobIQ0a/1MVeG3DPh
# BxjCl0ZnrsDAHRGJPt2t6jKKTEbfbGSKyKNx+sNt0Oy0RGapXLgazF8U/KTl5VKl
# H1hYv4976/IaD/BCcxyWUa5Kv3CZOlpUZD0hizCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxNzlFLTRCQjAtODI0NjElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAW6UpTq8YrPhwPCRPakRbrW/H2zCggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOEri8swIhgPMjAxOTA5MTgw
# MDQzNTVaGA8yMDE5MDkxOTAwNDM1NVowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4SuLywIBADAKAgEAAgIOGwIB/zAHAgEAAgISNDAKAgUA4SzdSwIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAAW7fZdyednYWskD1wod1bWxg//2EOSk7CXXEO7h
# VtdMAY6Hice6dAs09GWuODjFm8cOFC0aDoUDpxnopksO0JJaDe3D2SMRCisS2X7C
# 7yf/GkpO255BbcHtPIBny2jlwkYuUjK4OrAlkZ+4/Lc9Je5pdb+MKNmRiWCDCU7Y
# TmkrMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADbqm3jIn80ACUAAAAAANswDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgmKy9OKKQ6nhy57ld
# LL0LgDGbQV0qY5ZRvDKpQVed6mcwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCACUx2x05gBLSK1aiMlY7CLfUe24iC3/LD68uudIYz+qjCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA26pt4yJ/NAAlAAAAAADbMCIE
# INFzdQ1lp9SOXhgJoT4KO8yZ/A2FQh1ZIo0H3l7vdmd2MA0GCSqGSIb3DQEBCwUA
# BIIBABJO2ccZwlmhqRGtZHXlOSrJY5jnxFnKYW6tAbDrZgqTl2qaNi/NSLXFiXE6
# duaMOlCqDdeezwEEMoT8knqlbGnDgX+JLu6zyHs1Epnn40ciz2mGPt6W/n8lPW3v
# zS9plF2TEv6mKt6mveed7s2pSyafJLM/Ww7BHvPlQ3/4/GSPomy/UoTXz4aRmy9p
# tq6jiu40cMpQ3LQeWyrEWH1zL5QxaVUecbCNsi0f5F9wypAuKTVjaG3e02VwEgG3
# 39TmTbLeN7X3cGSwCcPD5vO0U61ORBQ1P2uWWtwGSIslJwRVScooku4pzVwmlrQF
# lwjeCNHFzLT05Fa6kaDjrjFX/Nc=
# SIG # End signature block
