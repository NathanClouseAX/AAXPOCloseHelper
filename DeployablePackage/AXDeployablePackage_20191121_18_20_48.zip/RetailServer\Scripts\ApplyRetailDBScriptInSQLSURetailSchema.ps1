param(
    [string]$config = $(Throw 'config parameter required'), 
    [string]$log = $(Throw 'log parameter required'),
    [string]$channelDatabaseDacpacFolderOverridePath,
    [string]$customScriptFolderOverridePath
)
function Drop-ExistingChannelDatabaseSchema(
    [string]$serviceModelRootPath = $(Throw 'serviceModelRootPath parameter required'),
    [string]$config = $(Throw 'config parameter required'),
    [string]$log = $(Throw 'log parameter required')
)
{
    $dropChannelDatabaseSchemaScriptPath = Join-Path -Path $serviceModelRootPath -ChildPath 'Scripts\ApplyRetailDBScriptInSQLSUDropObjects.ps1'
    Write-Log -Message 'Dropping existing retail channel database schema'

    $global:LASTEXITCODE = 0
    & $dropChannelDatabaseSchemaScriptPath -config $config -log $log
    $capturedExitCode = $global:LASTEXITCODE

    if ($capturedExitCode -ne 0)
    {
        $errorMessage = "Error dropping existing retail channel database schema, exit code: $capturedExitCode"
        Write-Log -Message  $errorMessage -IsError
    }

    Write-Log -Message 'Successfully dropped existing retail channel database schema'
}

$global:LASTEXITCODE = 0

$settings = @{}
try
{
    $decodedConfig = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($config))
    $settings = ConvertFrom-Json $decodedConfig

    $ScriptDir = Split-Path -Parent $PSCommandPath
    . $ScriptDir\Common-Configuration.ps1
    . $ScriptDir\Common-Database.ps1
    
    $dbServer = $settings.AxDbServer
    $dbName = $settings.AxDbName
    $dbUser = $settings.AxDbDeploySqlUser
    $dbPassword = $settings.AxDbDeploySqlPwd
    $retailRunTimeUser = $settings.dbUser
    $retailRunTimeUserPassword = $settings.dbPassword
    $retailDataSyncDbUser = $settings.dataSyncDbUser
    $retailDataSyncDbUserPassword = $settings.dataSyncDbUserPassword
    $retailExtensionsUser = $settings.AxDeployExtUser
    $retailExtensionsUserPassword = $settings.AxDeployExtUserPassword

    Write-Log ('Parameters retrieved from configuration string: dbServer = {0}; dbName = {1}; dbUser = {2}; dbPassword: *******; retailRunTimeUser = {3}; retailRuntimeDbUser = {4}; retailExtensionsUser = {5}' `
            -f $dbServer, $dbName, $dbUser, $retailRunTimeUser, $retailDataSyncDbUser, $retailExtensionsUser)

    $retailUsersToEnsure = @{$retailRunTimeUser = $retailRunTimeUserPassword; $retailDataSyncDbUser = $retailDataSyncDbUserPassword; $retailExtensionsUser = $retailExtensionsUserPassword}
    foreach($user in $retailUsersToEnsure.Keys)
    {
        try
        {
            $password = $retailUsersToEnsure[$user]
            $queryToEnsureUser = "
                DECLARE @isSqlAzure BIT
                SELECT @isSqlAzure = 0
                DECLARE @errorCode INT
                SELECT @errorCode = 0

                if (CHARINDEX('SQL Azure',@@VERSION) > 0)
                BEGIN
                    SELECT @isSqlAzure = 1
                END

                IF (@isSqlAzure = 0) -- Handle non SQL Azure
                BEGIN
                    -- Create login if not exists
                    IF NOT EXISTS(SELECT 1 FROM dbo.syslogins WHERE [NAME] = '$user')
                    BEGIN
                        CREATE LOGIN $user WITH PASSWORD = '$password'
                        SELECT @errorCode = @errorCode | 1
                    END

                    -- Create user from the login
                    IF NOT EXISTS (SELECT 1 FROM [sys].[sysusers] WHERE [NAME] = '$user' AND issqluser = 1)
                    BEGIN
                        CREATE USER $user FOR LOGIN $user
                        SELECT @errorCode = @errorCode | 4
                    END
                    
                    ALTER LOGIN $user WITH PASSWORD = '$password'
                    
                    -- Reassociate user and login
                    EXEC sp_change_users_login 'Update_One', '$user', '$user'

                END
                ELSE -- Handle SQL Azure
                BEGIN
                    -- SQL Azure login creation requires access to master database, we may not have this permission in current context, skip this part for now.
                    -- IF NOT EXISTS (SELECT 1 FROM [master].[sys].[sql_logins] WHERE [NAME] = '$user')
                    -- BEGIN
                    --  CREATE LOGIN $user WITH PASSWORD = '$password'
                    -- END

                    -- Create user if not exists
                    IF NOT EXISTS (SELECT 1 FROM [sys].[sysusers] WHERE [NAME] = '$user' AND islogin = 1 AND issqluser = 1)
                    BEGIN
                        -- For SQL Azure when the user is not available for login then we can't provision it during the script execution
                        -- needs to be provisioned in the 'master' database by DSE
                        -- RAISERROR('User $user not found as a valid login, it will need to be created in the master database, and the user should be created in the $dbName.  In Production environments this should be done by DSE team', 16, 1)
                        SELECT @errorCode = @errorCode | 8
                    END
                END
                SELECT @errorCode AS ErrorCode "
            Write-Log "Ensure user $user"
            $result = Invoke-SqlCmd -ServerInstance $dbServer -Database  $dbName -Username $dbUser -Password $dbPassword -Query $queryToEnsureUser -ErrorAction Stop
            
            if($result.ErrorCode -gt 0)
            {
                # This will leave the environment with a state that the Retail function may not work correctly.
                # But we will just generate a warning here in order not to break the updgrade automation. 
                # Migitation plan has been created to fix this environment with manual steps.
                Write-Warning "WARNING: Login or User '$user' doesn't exist in database, ErrorCode $($result.ErrorCode)."
            }
        }
        catch
        {
            $message = ($global:error[0] | format-list * -f | Out-String)
            Write-Warning "WARNING:$message"
        }
    }

    $PackageDirectory = Split-Path -Parent $ScriptDir
    $dbDeploymentAssetsRoot = Join-Path $PackageDirectory 'Data'
    
    $ChannelDatabaseBaselineScriptPath = Join-Path $dbDeploymentAssetsRoot 'CommerceRuntimeScripts_Create.sql'
    $ChannelDatabaseUpgradeCustomScriptFolderPath = Join-Path $dbDeploymentAssetsRoot 'Upgrade\Custom'
    $ChannelDatabaseUpgradeDacpacFileFolderPath = $dbDeploymentAssetsRoot
    $ChannelDatabaseUpgradeRetailScriptFolderPath = Join-Path $dbDeploymentAssetsRoot 'Upgrade\Retail'

    if (-not [String]::IsNullOrWhitespace($channelDatabaseDacpacFolderOverridePath))
    {
        # we only need to change $ChannelDatabaseUpgradeDacpacFileFolderPath because that is the only path used by Common-Database
        # to retrieve the dacpac used to create/update the database when deploying the channel database
        Write-Log "Channel database dacpac folder path was overriden to: $channelDatabaseDacpacFolderOverridePath"
        $ChannelDatabaseUpgradeDacpacFileFolderPath = $channelDatabaseDacpacFolderOverridePath
    }

    # If $customScriptFolderOverridePath is specified, use it to apply the database customizations.
    if (-not [String]::IsNullOrWhitespace($customScriptFolderOverridePath))
    {
        Write-Log "Channel database custom scripts folder path was overriden to: $customScriptFolderOverridePath"
        $ChannelDatabaseUpgradeCustomScriptFolderPath = $customScriptFolderOverridePath
    }

    # Drop the existing channel database schema before attempting to regenerate it.
    # By default, this step will be executed for initial deployment since the databackup may contains retail schema.
    # For minor version upgrdade, this step will be skipped since we want to perform a in-pleace upgrade.
    if($settings.SkipDatabaseSchemaDeletion -ieq "true")
    {
        Write-Log "SkipDatabaseSchemaDeletion is set to true, will skip the schema deletion."
    }
    else
    {
        Drop-ExistingChannelDatabaseSchema -serviceModelRootPath $PackageDirectory -config $config -log $log
    }
    
    $channelDbTopology = Join-Path $ScriptDir 'channeldb-topology-cloud.xml'
    $channelDbSettingTemplate = Join-Path $ScriptDir 'channeldb-settings-cloud.xml'
    $ChannelDbSettingCloud = Join-Path $ScriptDir 'channeldb-settings-cloudupdated.xml'
    $credentials = New-Object System.Management.Automation.PSCredential($dbUser, (ConvertTo-SecureString $dbPassword -AsPlainText -Force))
    $extensionUserCredentials = New-Object System.Management.Automation.PSCredential($retailExtensionsUser, (ConvertTo-SecureString $retailExtensionsUserPassword -AsPlainText -Force))



    Write-Log "Trying to upgrade Retail Channel database."
    
    Write-Log "setting up $ChannelDbSettingCloud for Microsoft upgrade."

    Set-Location $ScriptDir
    
    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Setup-SettingsForDatabaseDeployment.ps1') `
                                -channelDatabaseServerName $dbserver `
                                -channelDatabaseName $dbname `
                                -SqlUserName $dbUser `
                                -ChannelDatabaseBaselineScriptPath $ChannelDatabaseBaselineScriptPath `
                                -ChannelDatabaseUpgradeCustomScriptFolderPath $ChannelDatabaseUpgradeCustomScriptFolderPath `
                                -ChannelDatabaseUpgradeDacpacFileFolderPath $ChannelDatabaseUpgradeDacpacFileFolderPath `
                                -ChannelDatabaseUpgradeRetailScriptFolderPath $ChannelDatabaseUpgradeRetailScriptFolderPath `
                                -SettingsXmlFilePathInput $channelDbSettingTemplate `
                                -SettingsXmlFilePathOutput $ChannelDbSettingCloud
    } -logFile $log
    
    Write-Log "Finished setting up $ChannelDbSettingCloud for Microsoft upgrade."
    Write-Log "Trying to upgrade base version for Retail Channel database."

    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Deploy-Databases.ps1') `
                                -TopologyXmlFilePath $channelDbTopology `
                                -SettingsXmlFilePath $ChannelDbSettingCloud `
                                -Credentials $credentials `
                                -Verbose $True `
                                -DeploymentType "ChannelDB"
    } -logFile $log
    
    Write-Log "Finished upgrading base version for Retail Channel database."

    Log-TimedMessage 'Update roles for retail database users.'
    Set-RolesForCloudRetailChannelDatabase `
                            -Server $dbServer `
                            -Database $dbName `
                            -Credentials $credentials
    Log-TimedMessage 'Finished updating roles for retail database users.'

    Write-Log "setting up $ChannelDbSettingCloud for upgrading customizations for Retail Channel database."
    
    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Setup-SettingsForDatabaseDeployment.ps1') `
                                -channelDatabaseServerName $dbserver `
                                -channelDatabaseName $dbname `
                                -SqlUserName $retailExtensionsUser `
                                -ChannelDatabaseBaselineScriptPath $ChannelDatabaseBaselineScriptPath `
                                -ChannelDatabaseUpgradeCustomScriptFolderPath $ChannelDatabaseUpgradeCustomScriptFolderPath `
                                -ChannelDatabaseUpgradeDacpacFileFolderPath $ChannelDatabaseUpgradeDacpacFileFolderPath `
                                -ChannelDatabaseUpgradeRetailScriptFolderPath $ChannelDatabaseUpgradeRetailScriptFolderPath `
                                -SettingsXmlFilePathInput $channelDbSettingTemplate `
                                -SettingsXmlFilePathOutput $ChannelDbSettingCloud
    } -logFile $log

    Write-Log "Finished setting up $ChannelDbSettingCloud for upgrading customizations for Retail Channel database."
    Write-Log "Trying to upgrade customizations for Retail Channel database."

    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Deploy-Databases.ps1') `
                                -TopologyXmlFilePath $channelDbTopology `
                                -SettingsXmlFilePath $ChannelDbSettingCloud `
                                -Credentials $extensionUserCredentials `
                                -Verbose $True `
                                -DeploymentType "Customizations"
    } -logFile $log
    
    Write-Log "Finished upgrading customizations for Retail Channel database."
    
    
    $capturedExitCode = $global:LASTEXITCODE
    if($capturedExitCode -ne 0)
    {
        $errorMessage = "Error deploying retail channel database, exit code: $capturedExitCode"
        Write-Log -Message  $errorMessage -IsError
        throw $errorMessage
    }

    exit $capturedExitCode
}
catch
{
    # Will throw if the database deployment fails, generally this is a critical failure and it should fail, leave it to the caller to handle it if necessary.
    $exceptionMsg = ($global:error[0] | Format-List * -f | Out-String)
    $errorMsg = "Error executing the script ApplyRetailDBScriptInSQLSURetailSchema: $exceptionMsg."
    Write-Log $errorMsg
    throw $errorMsg
}
# SIG # Begin signature block
# MIIjrQYJKoZIhvcNAQcCoIIjnjCCI5oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBb25ipRhR1PNWR
# 1SMmAyb04EwreWZqQb9JgPiEgZ6toqCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVgjCCFX4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgYOr/BLQg
# GtL54kymXis03fNJ4pYCkQRbprn518HHq0AwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQB/Hw0G1IuZn2HnJCoh0xpkSi/R1EFQbH8s1NXR91CI+sI6jIZy
# vjUDeQ4idV0cYWB2sBhP59PThxRRQguyEPCDu5nSN0RXKBs80Im7as9jrA/fjqax
# r35aK23KqtdBbMw2EfLdA1LtxtINbs/UIqnXI5FXiQS9YKl71+ae4lAH6pnE56/0
# s4SnJi20ZgIpKZ2zAG9ykzjaIConUraqBHHsyOUidoo4h0rDx4iI+JyQt50na9eq
# Dy9MpWAxLGTRz5BFxTg5eYd1+QwmEygMt9r1VtFwXUkzGeIjNVUaAbl8JmoZOoT0
# 4oGHsSJDwxt9Fkpk7zQZlA6WmUqO7wSqsdFjoYIS4jCCEt4GCisGAQQBgjcDAwEx
# ghLOMIISygYJKoZIhvcNAQcCoIISuzCCErcCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIPCIY3HHzGig90ONfmU1rivRTVpNJrCbyZp++Mle1sHmAgZd
# Xbd3TFAYEzIwMTkwOTE3MTkyMDU4Ljc4NlowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29m
# dCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjIy
# NjQtRTMzRS03ODBDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIOOTCCBPEwggPZoAMCAQICEzMAAADvTPJq2ssEnSwAAAAAAO8wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgxMDI0
# MjExNDE2WhcNMjAwMTEwMjExNDE2WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0
# aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MjI2NC1FMzNFLTc4MEMxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC1OGyDlNGBwjomVJrEi9QmI+PF8k1u2KLCjioc
# NRIwURHMx4Pi/2sKIJ/jgjGh0isFP0BXUdKp8IYH/9bg2mlupq7AvMuBRkOyPMaj
# TMieY8fl+2e7X5RRHsC+TpWQ8/6KTRL3WWCgKtm+JJPOxqiMFfAXgweee6XD3l7n
# 6VKdnnRwHFYr8sT4X1sY/DTXuz4hc8Hs2RTgy8YdN0nEdD51DV6xaC2IgkeBQxNx
# rWlN9uMuUah9GY4iNeNP+J1rVi2H0ZTD5kpwvAlM2RRupjCe+oCTLJbOkMPC4aP5
# S2hSiJ9TPVPhMssit1uuaeeGMGbkVyP7KuJS4vHx9gWYr14JAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUTGQrSjM4PMd3ZBkTCkSYhPZNKS0wHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAdb/GQr7owKPezpR4YRqsePnedCshIdIZ6uoSa2acLliawqJ6
# kSxA7eZMeMslpxUWjDlq2M9ALpnWQ4tA2wnOqA0w0EwyDAWP4auUqN4M56HyPdxc
# DVOo9raNLFQLAd1lH5ZyaMfTfgrHtNU7kKyt6TeBcr1fO7QtUdWLw/50QSDX6xBm
# 7jSKnft3xFC53fcy3xUfYBRvvxuuiJgdN/pYJALeS4yXdF7GxK6YLvFMm0EZDj5b
# 0Osd7qkzsdfsPi5YV/l4lqMzinjehoaQs2sCKT97tV7UjnZ0B9rHc6fUHD6Uq5A5
# 37z1oXh1I6LcoYeGc6MNigpLBPaSo+JmK4RqoTCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAsswggI0AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRp
# b25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyMjY0LUUzM0UtNzgwQzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAJaUg4C3nylyCiC/Q0S10vrXOIV2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErJS8wIhgPMjAxOTA5MTcx
# NzI2MDdaGA8yMDE5MDkxODE3MjYwN1owdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA
# 4SslLwIBADAHAgEAAgIM/jAHAgEAAgIRfDAKAgUA4Sx2rwIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0G
# CSqGSIb3DQEBBQUAA4GBAICvjNizyp6q+0KudfjKZh+9G/K4gSGnQP8sD99SZNJf
# VsuaJr6HHAb4jJnsH0G/qeo7S1ChsaH0eorMzPpl49zWkDWVCvyusaKU5H4ME3/c
# ikBeofdDhsXIilwnDTqvzvaKFpPoBybJ4VpfVHrmiKRFq/GdJjRlE8nqbUPtDdsh
# MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMA
# AADvTPJq2ssEnSwAAAAAAO8wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJ
# AzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgsntLE52AXEs2qxW9rSxL
# jMgLGT066l6DQ2VZsxsgIXowgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCg
# SeqlVZI1WeamrpyUp7YrS49qricKTpYhMLEE3+55ujCBmDCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA70zyatrLBJ0sAAAAAADvMCIEILhq
# iUnLUDBcrh4OxCOOWpvQOOJIR1AbgFnI4TaG5cABMA0GCSqGSIb3DQEBCwUABIIB
# AAPwoNJFcEBnHTDztGPoAPFHr8UtjapdO35MgF8pcezFcO+dZPCWDUshVbmFn54C
# bF3MaX+lD+Q6259g4dh705hZ/oYelAAz614JXBMnWE0DrR6e36FhpAXShgTA8TD3
# 5dg1Ykj4Xd48Mi5eeLrc5QzcRjR7+5/QLNO4/kmMBu5VH9cIF/Sko0L8zhYojUDH
# Di/rV3RCgDSKNK+CDwI1GqUmCmeGhGFMtRHSnvr8BTXGZJZIb6Lk5aftXeRshwwG
# hl8ZphXofjjB2P+rdRe4jSjTMefMfSHtrgtrLKSNycfOpxZcpsCeiS/Ti7GFFHrc
# smYZMUs4EDmCLOAkDjAtY0w=
# SIG # End signature block
