<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

<#
.SYNOPSIS
    Allows a user to update Retail Server deployment.

.DESCRIPTION
    This script provides a mechanism to update existing Retail Server deployment on a local system.

.PARAMETER RETAILSERVERWEBSITENAME
    The name of Retail Server website which is deployed on the local system.

.PARAMETER MINSUPPORTEDVERSION
    An optional parameter to specify the minimum supported build version for Retail Server service. If the current installed version is less than this then the script will not support update.

.EXAMPLE 
    # Update the existing Retail Server deployment with minimum supported version "7.0.0.0". 
    .\UpdateRetailServer.ps1 -MinSupportedVersion "7.0.0.0"
#>

param (
    $RetailServerWebSiteName = 'RetailServer',
    $AosWebsiteName = 'AOSService',
    $MinSupportedVersion
)

$ErrorActionPreference = 'Stop'

function LogConnectionString([string] $webConfigPath = $(throw 'webConfigPath is required'))
{ 
    Log-TimedMessage ('The path of web.config is {0}' -f $webConfigPath)
    $connectionString= Extract-ConnectionStringsFromWebConfig -webConfigPath $webConfigPath  
    if($connectionString -ne $null) 
    {
        if($connectionString.length -gt 300)
        {       
            Log-TimedMessage $connectionString.substring(0,300)
        }
        else
        {
            Log-TimedMessage $connectionString
        }
        $connectionStringHash = Generate-MD5-Hash -param $connectionString
        Log-TimedMessage ('MD5 hash of connection string is {0}' -f $connectionStringHash)        
    }
    else
    {
        Log-TimedMessage 'connection string is null'
    }
}

function Generate-MD5-Hash([string] $param = $(throw 'Parameter is required'))
{
    $md5  = new-object -TypeName System.Security.Cryptography.MD5CryptoServiceProvider
    $utf8 = new-object -TypeName System.Text.UTF8Encoding            
    $hash = [System.BitConverter]::ToString($md5.ComputeHash($utf8.GetBytes($param)))      
    return $hash
}

function Upgrade-RetailServer(
    [string] $webSiteName = $(throw 'webSiteName is required'),
    [string] $AosWebsiteName = $(throw 'AosWebsiteName is required'),
    [string] $webConfigPath = $(throw 'webConfigPath is required'),
    [string] $webSitePhysicalPath = $(throw 'webSitePhysicalPath is required'),
    [string] $scriptDir = $(throw 'scriptDir is required'),
    [ValidateNotNullOrEmpty()]
    [string] $installationInfoXmlPath = $(throw 'installationInfoXmlPath is required'))
{
    Log-TimedMessage 'Begin updating Retail Server deployment...'

    $webConfigFileName = 'web.config'
    try
    {
        LogConnectionString -webConfigPath $webConfigPath

        # Decrypt web.config connection strings section.
        Log-TimedMessage 'Decrypt connectionStrings section in web.config'
        $webSiteId = Get-WebSiteId -webSiteName $webSiteName    
        aspnet_regiis -pd "connectionStrings" -app "/" -Site $webSiteId

        $isMicrosoftPackage = Check-IfUpdatePackageIsReleasedByMicrosoft -installationInfoXml $installationInfoXmlPath

        # Get retail server url before update
        $retailServerUrl = Get-RetailServicerUrlFromWebConfig -retailWebsiteName $webSiteName
        Log-TimedMessage ('Found Retail Server URL - {0}' -f $retailServerUrl)
        
        # Create a temp working folder
        $tempWorkingFolder = Join-Path $env:temp ("{0}_Temp_{1}" -f $webSiteName, $(Get-Date -f yyyy-MM-dd_hh-mm-ss))

        # Get the service model Code folder from the update package
        # If Code folder does not exist or is empty, skip the remaining update process.
        Log-TimedMessage 'Getting the Code folder from the deployable update package.'
        $updatePackageCodeDir = (Join-Path (Split-Path (Split-Path (Split-Path $ScriptDir -Parent) -Parent) -Parent) 'Code')
        
        if(Check-IfAnyFilesExistInFolder -folderPath $updatePackageCodeDir)
        {
            Log-TimedMessage ('Found the Code folder from the deployable update package at - {0}.' -f $updatePackageCodeDir)
            $crtConfigFileName = 'commerceruntime.config'

            if($isMicrosoftPackage)
            {
                # Copy all the update files without ext folder to a temp location 
                Copy-Files -SourceDirPath $updatePackageCodeDir `
                           -DestinationDirPath $tempWorkingFolder `
                           -FilesToCopy '*' `
                           -RobocopyOptions '/S /njs /ndl /np /njh /XD ext'
            
                Log-TimedMessage  'Merge web.config with microsoft updates.'
                Merge-WebConfig -tempWorkingFolder $tempWorkingFolder -webConfigPath $webConfigPath
            
                # Migrate the Real-time Service thumbprint in commerceruntime config file
                Log-TimedMessage 'Updating Real-time Service settings in the commerce runtime config file.'
                Retain-RtsSettingsInCrtConfig -sourceCrtConfigFilePath (Join-Path (Join-Path $webSitePhysicalPath 'bin') $crtConfigFileName) `
                                                     -targetCrtConfigFilePath (Join-Path (Join-Path $tempWorkingFolder 'bin') $crtConfigFileName)
                Log-TimedMessage 'Finished updating Real-time Service settings in the commerce runtime config file.'
                
                # Read cert thumbprint before update
                Log-TimedMessage 'Retrieve Retail Server SSL certificate thumbprint from web.config file.'
                $certThumbprint = Get-RetailServerAuthCertThumbPrintFromWebConfig -webConfigPath $webConfigPath
                Log-TimedMessage ('Found Retail Server SSL certificate thumbprint - {0}' -f $certThumbprint)
            
                # Update the Retail Server authentication cert thumbprint, issuer and open-id configuration file.
                Update-RetailServerAuthenticationKeys -scriptDir $ScriptDir `
                                                  -retailServerDeploymentPath $tempWorkingFolder `
                                                  -retailServerAuthCertThumbprint $certThumbprint `
                                                  -retailServerUrl $retailServerUrl
            }
            else
            {
                # Copy all the update files to a temp location 
                Copy-Files -SourceDirPath $updatePackageCodeDir `
                           -DestinationDirPath $tempWorkingFolder `
                           -FilesToCopy '*' `
                           -RobocopyOptions '/S /njs /ndl /np /njh'
                           
                Log-TimedMessage  'Merge web.config with customization.'
                Merge-CustomizedWebConfig -tempWorkingFolder $tempWorkingFolder -webConfigPath $webConfigPath
            }

            # Encrypt web.config connection strings before taking a backup
            aspnet_regiis -pe "connectionStrings" -app "/" -Site $webSiteId

            # Replace website files from temp working directory to actual working directory
            Replace-WebsiteFiles -webSiteName $webSiteName -newWebFilesPath $tempWorkingFolder
        }
    }
    finally
    {
        # Encrypt back web.config connection strings section.
        Log-TimedMessage 'Encrypt connectionStrings section in web.config'
        aspnet_regiis -pe "connectionStrings" -app "/" -Site $webSiteId
        
        LogConnectionString -webConfigPath $webConfigPath

        # Remove the temp working folder
        if($tempWorkingFolder -and (Test-Path -Path $tempWorkingFolder))
        {
            Log-TimedMessage ('Removing temporary working directory {0}' -f $tempWorkingFolder)
            Remove-Item $tempWorkingFolder -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    Log-TimedMessage 'Finished updating Retail Server deployment...' 
}

function Update-RetailServerAuthenticationKeys(
    [string]$scriptDir = $(throw 'scriptDir is required'),
    [string]$retailServerDeploymentPath = $(throw 'retailServerDeploymentPath is required'),
    $retailServerAuthCertThumbprint = $(throw 'retailServerAuthCertThumbprint is required'),
    [string]$retailServerUrl = $(throw 'retailServerUrl is required'))
{
    $deploymentScriptsDir = (Split-Path (Split-Path $ScriptDir -Parent) -Parent)
    $updateRetailServerAuthenticationKeysScriptPath = Join-Path $deploymentScriptsDir 'UpdateRetailServerAuthenticationKeys.ps1'

    if(-not (Test-Path $updateRetailServerAuthenticationKeysScriptPath))
    {
        throw "Cannot find script $updateRetailServerAuthenticationKeysScriptPath."
    }
    
    Invoke-Script -scriptBlock `
    {
        & $updateRetailServerAuthenticationKeysScriptPath -RetailServerDeploymentPath $retailServerDeploymentPath `
                                                          -RetailServerUrl $retailServerUrl `
                                                          -CertificateThumbprint $retailServerAuthCertThumbprint
    }
}

function Get-RetailServerAuthCertThumbPrintFromWebConfig([string]$webConfigPath = $(throw 'webConfigPath is required'))
{
    [xml]$webConfigXml = Get-Content $webConfigPath
    $retailServerAuthCertThumbprint = $webConfigXml.configuration.retailServer.authentication.CertThumbprint

    if(-not $retailServerAuthCertThumbprint)
    {
        throw "Could not find Retail Server authentication thumbprint in web.config file at: $webConfigPath"
    }

    return $retailServerAuthCertThumbprint
}

function Get-RetailServicerUrlFromWebConfig([string]$retailWebsiteName = $(throw 'retailWebsiteName is required'))
{
    # The web.config does not contain the Retail server URL so it has to be created using the commerce token issuer.
    Log-TimedMessage 'Retrieve commerce token issuer from retail server website.'
    $retailServerRootUrl = Get-WebSiteBindingUrls -websiteName $retailWebsiteName | Select-Object -First 1

    if([String]::IsNullOrWhiteSpace($retailServerRootUrl))
    {
        throw "Could not find retailServerRootUrl from retail server website."
    }

    $retailServerUrl = "$retailServerRootUrl/commerce"

    return $retailServerUrl;
}

function Retain-CustomSettings(
    [ValidateNotNullOrEmpty()]
    [xml]$sourceConfigXml = $(throw 'sourceConfigXml is required'),

    [ValidateNotNullOrEmpty()]
    [xml]$targetConfigXml = $(throw 'targetConfigXml is required'))
{
    
    Log-ActionItem 'Check if Retail Server cryptography certificate thumbprint exists in the source web.config file'
    $sourceCryptographyCertThumbprint = $sourceConfigXml.configuration.retailServer.cryptography.certificateThumbprint
        
    if($sourceCryptographyCertThumbprint)
    {
        Log-ActionResult 'Yes. Retain this value in the target web.config'
        $targetConfigXml.configuration.retailServer.cryptography.certificateThumbprint = $sourceCryptographyCertThumbprint
    }
    else
    {
        Log-ActionResult 'No. Skip this step'
    }

    Log-ActionResult 'Finished retaining Retail Server cryptography certificate thumbprint in target web.config'
    
    Log-ActionItem 'Check if Retail Server device activation allowed identity providers exists in the source web.config file'
    $sourceDeviceActivation = $sourceConfigXml.configuration.retailServer.deviceActivation.allowedIdentityProviders
        
    if($sourceDeviceActivation)
    {
        Log-ActionResult 'Yes. Retain this value in the target web.config'
        $targetConfigXml.configuration.retailServer.deviceActivation.allowedIdentityProviders = $sourceDeviceActivation
    }
    else
    {
        Log-ActionResult 'No. Skip this step'
    }
    
    Log-ActionResult 'Finished retaining Retail Server device activation allowed identity providers in target web.config'
}

function Get-NonCustomizableAppSettings()
{
    $nonCustomizableAppSettings = @(
    'AADObjectIdClaimName',
    'AADTenantIdClaimName',
    'AADTokenIssuerPrefix',
    'AADRetailServicePrincipalName',
    'AllowedOrigins',
    'FederationMetadataAddress',
    'isConnectionStringOverridden',
    'RetailServerPackageMetadata',
    'serviceUri',
    'Microsoft.AzureKeyVault.Url',
    'Microsoft.AzureKeyVault.CertificateThumbprint',
    'Microsoft.AzureKeyVault.ClientId',
    'Microsoft.AzureKeyVault.RegistryKey',
    'IsAnonymousEnabled',
    'WebSiteName',
    'CommerceTokenIssuer',
    'DataAccess.disableDBServerCertificateValidation',
    'DataAccess.Database',
    'DataAccess.SqlPwd',
    'DataAccess.DbServer',
    'DataAccess.DataSigningCertificateThumbprint',
    'DataAccess.SqlUser',
    'DataAccess.AxAdminSqlUser',
    'CertificateHandler.HandlerType',
    'DataAccess.DataEncryptionCertificateThumbprint',
    'DataAccess.AxAdminSqlPwd',
    'DataAccess.encryption')
    
    return $nonCustomizableAppSettings 
}

function Merge-WebConfig(
    [string]$tempWorkingFolder = $(throw 'tempWorkingFolder is required'),
    [string]$webConfigPath = $(throw 'webConfigPath is required'))
{
    $tempWebConfigPath = Join-Path $tempWorkingFolder (Split-Path $webConfigPath -Leaf)

    # if the target web config file doesn't exist, meaning there is no customization for this file, return and skip the merge.
    if(-not (Test-Path -Path $tempWebConfigPath))
    {
        Log-TimedMessage "$tempWebConfigPath doesn't exist, skip merging and return."
        return
    }

    # Merge the connection strings
    Log-TimedMessage 'Merging connection strings section in web.config file.'
    $websiteConnectionStringSettings = Extract-ConnectionStringsFromWebConfig -webConfigPath $webConfigPath
    Update-WebsiteConnectionStringSettings -webConfigPath $tempWebConfigPath -connectionStringsXml $websiteConnectionStringSettings
    Log-TimedMessage 'Finished merging connection strings section in web.config file.'       

    # Merge the app settings
    Log-TimedMessage 'Merging app settings section in web.config file.'
       
    [array]$nonCustomizableAppSettings = Get-NonCustomizableAppSettings
    Merge-WebConfigAppSettings -sourceWebConfigFilePath $webConfigPath `
                                -targetWebConfigFilePath $tempWebConfigPath `
                                -nonCustomizableAppSettings $nonCustomizableAppSettings

    Log-TimedMessage 'Finished merging app settings section in web.config file.'
    
    [xml]$sourceWebConfigDoc = Get-Content $webConfigPath
    [xml]$targetWebConfigDoc = Get-Content $tempWebConfigPath
     
    # Merge the environment key
    Merge-XmlNode -sourceConfigXml $sourceWebConfigDoc -targetConfigXml $targetWebConfigDoc -targetXPath '//configuration' -targetNodeName 'environment'

    # Merge the machine key
    Merge-XmlNode -sourceConfigXml $sourceWebConfigDoc -targetConfigXml $targetWebConfigDoc -targetXPath '//configuration/system.web' -targetNodeName 'machineKey'

    # Retain the Retail Server cryptography certificate thumbprint
    Retain-CustomSettings -sourceConfigXml $sourceWebConfigDoc -targetConfigXml $targetWebConfigDoc
    
    # Merge extensionComposition from web.config to tempWebConfigPath
    Merge-XmlNode -sourceConfigXml $sourceWebConfigDoc -targetConfigXml $targetWebConfigDoc -targetXPath '//configuration/retailServer' -targetNodeName 'extensionComposition'
    
    Set-ItemProperty $tempWebConfigPath -name IsReadOnly -value $false
    $targetWebConfigDoc.Save($tempWebConfigPath)
}

function Retain-RtsSettingsInCrtConfig(
    [ValidateNotNullOrEmpty()]
    [string]$sourceCrtConfigFilePath = $(throw 'sourceCrtConfigFilePath is required'),

    [ValidateNotNullOrEmpty()]
    [string]$targetCrtConfigFilePath = $(throw 'targetCrtConfigFilePath is required'))
{
    # if the target crt config file doesn't exist, meaning there is no customization for this file, return and skip the merge.
    if(-not (Test-Path -Path $targetCrtConfigFilePath))
    {
        Log-TimedMessage "$targetCrtConfigFilePath doesn't exist, skip merging and return."
        return
    }

    [xml]$sourceWebConfigFilePathDoc = Get-Content $sourceCrtConfigFilePath
    [xml]$targetCrtConfigFilePathDoc = Get-Content $targetCrtConfigFilePath
    
    Merge-XmlNode -sourceConfigXml $sourceWebConfigFilePathDoc -targetConfigXml $targetCrtConfigFilePathDoc -targetXPath '//commerceRuntime'  -targetNodeName 'realtimeService' -createIfNotExists $false
    Set-ItemProperty $targetCrtConfigFilePath -name IsReadOnly -value $false
    $targetCrtConfigFilePathDoc.Save($targetCrtConfigFilePath)
}

function Merge-CustomizedWebConfig(
    [string]$tempWorkingFolder = $(throw 'tempWorkingFolder is required'),
    [string]$webConfigPath = $(throw 'webConfigPath is required'))
{
    $tempWebConfigPath = Join-Path $tempWorkingFolder (Split-Path $webConfigPath -Leaf)
    $tempWebConfigPathStaging = Join-Path $tempWorkingFolder 'web.config.staging'

    # Merge the app settings
    Log-TimedMessage 'Merging customized app settings section in web.config file.'
    
    Copy-Item $tempWebConfigPath $tempWebConfigPathStaging
    Copy-Item $webConfigPath $tempWebConfigPath
    
    [array]$nonCustomizableAppSettings = Get-NonCustomizableAppSettings
    Merge-WebConfigAppSettings -sourceWebConfigFilePath $tempWebConfigPathStaging `
                                -targetWebConfigFilePath $tempWebConfigPath `
                                -nonCustomizableAppSettings $nonCustomizableAppSettings `
                                -isMicrosoftPackage $false
    
    [xml]$sourceWebConfigDoc = Get-Content $tempWebConfigPathStaging
    [xml]$targetWebConfigDoc = Get-Content $tempWebConfigPath

    Log-TimedMessage 'Finished merging app settings section in web.config file.'
    
    # Merge extensionComposition from staging file to tempWebConfigPath
    Merge-XmlNode -sourceConfigXml $sourceWebConfigDoc -targetConfigXml $targetWebConfigDoc -targetXPath '//configuration/retailServer'  -targetNodeName 'extensionComposition'
    
    Set-ItemProperty $tempWebConfigPath -name IsReadOnly -value $false
    $targetWebConfigDoc.Save($tempWebConfigPath)
    
    Remove-Item $tempWebConfigPathStaging -Force
}

function Merge-XmlNode(
    [xml]$sourceConfigXml = $(throw 'sourceConfigXml is required'),
    [xml]$targetConfigXml = $(throw 'targetConfigXml is required'),
    [string]$targetXPath = $(throw 'targetXPath is required'),
    [string]$targetNodeName = $(throw 'targetNodeName is required'),
    [bool]$createIfNotExists = $true)
{
    $childXPath = $targetXPath + '/' + $targetNodeName
    $sourceNode = $sourceConfigXml.SelectSingleNode($childXPath)
    $targetNode = $targetConfigXml.SelectSingleNode($childXPath)
    $parentNode = $targetConfigXml.SelectSingleNode($targetXPath)

    $importedNode = $targetConfigXml.ImportNode($sourceNode, $true)

    if(!$targetNode -and $createIfNotExists)
    {
        $parentNode.AppendChild($importedNode) >$null
    }
    else
    {
        $parentNode.ReplaceChild($importedNode, $targetNode) >$null
    }
}

try
{    
    $ScriptDir = Split-Path -parent $MyInvocation.MyCommand.Path
    . (Join-Path $ScriptDir 'Common-Configuration.ps1')
    . (Join-Path $ScriptDir 'Common-Web.ps1')
    . (Join-Path $ScriptDir 'Common-Database.ps1')
    . (Join-Path $ScriptDir 'Common-Upgrade.ps1')

    # Get website physical path.
    Log-TimedMessage ('Getting website physical path for website - {0}' -f $RetailServerWebSiteName)
    $webSitePhysicalPath = Get-WebSitePhysicalPath -webSiteName $RetailServerWebSiteName
    Log-TimedMessage ('Found website physical path - {0}' -f $webSitePhysicalPath)
    
    # Get web.config path.
    Log-TimedMessage 'Getting web.config path.'
    $webConfigPath = Join-Path $webSitePhysicalPath 'web.config'
    Log-TimedMessage ('Found web.config path - {0}' -f $webConfigPath)

    # Get the installation info manifest file.
    Log-TimedMessage 'Getting installation info XML path.'
    $installationInfoFile = Get-InstallationInfoFilePath -scriptDir $ScriptDir
    Log-TimedMessage ('Found installation info XML path - {0}' -f $installationInfoFile)

    # Get the update package root folder
    Log-TimedMessage 'Getting the update package root folder from the deployable update package.'
    $updatePackageRootDir = (Split-Path (Split-Path (Split-Path (Split-Path $ScriptDir -Parent) -Parent) -Parent) -Parent)
    $scriptsPath = Join-Path $updatePackageRootDir 'RetailServer\Scripts'
    Log-TimedMessage ('Found update package root directory - {0}' -f $updatePackageRootDir)
    
    # Upgrade Retail Server
    Upgrade-RetailServer -webSiteName $retailServerWebSiteName `
                         -AosWebsiteName $AosWebsiteName `
                         -scriptDir $scriptDir `
                         -webConfigPath $webConfigPath `
                         -webSitePhysicalPath $webSitePhysicalPath `
                         -isPackageDelta $isPackageDelta `
                         -installationInfoXmlPath $installationInfoFile

    # Register perf counters
    $registerPerfCounterScriptPath = Join-Path $scriptsPath 'Register-PerfCounters.ps1'
    $diagDllPath = Join-Path $updatePackageRootDir 'RetailServer\ETWManifest\Microsoft.Dynamics.Retail.Diagnostics.dll'
    if(Test-Path -Path $diagDllPath)
    {
        Log-TimedMessage 'Registering performance counters.'
        Invoke-Script -scriptBlock { & $registerPerfCounterScriptPath -InstrumentedAssemblyPath $diagDllPath }
        Log-TimedMessage 'Finished registering performance counters.'
    }
}
catch
{
    Log-Error ($global:error[0] | format-list * -f | Out-String)
    $ScriptLine = "{0}{1}" -f $MyInvocation.MyCommand.Path.ToString(), [System.Environment]::NewLine
    $PSBoundParameters.Keys | % { $ScriptLine += "Parameter: {0} Value: {1}{2}" -f $_.ToString(), $PSBoundParameters[$_.ToString()], [System.Environment]::NewLine}
    Write-Host ("Executed:{0}$ScriptLine{0}Exiting with error code $exitCode." -f [System.Environment]::NewLine)
    throw ($global:error[0] | format-list * -f | Out-String)
}
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBz5/tvIkcxf0IL
# 2hgXAGTrUP/Flv/Ukau8k8KYwhagSKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgkPIFCr+a
# 5KMD0fKtopzzV1OyKCaU52SLuM0wsMBZMJowbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBAlMBHHJ0AAMi2lbJc6SIiwNhRJdPLTE0Rob8/5ZLdv1EmN4qj
# 9Y/cTGpu3Ujrrsmtv9GIzJmkkla9pESkV/xRaeVo/JrnMDcJf40FVjyEXLvhXHCc
# OdlQfrSjkdZ6v5ZoSzyCGpLem5Sc/n4ztbBu5y2PjJzKb/QJX49FSLsZ/B5otvI3
# DM1TOmd17zTtv9ZKXlLEwBT42yoXHgGf63H4rypshlvHWcMwFGfjJYjnBsEhKZ54
# LmNl4DbcNnuR5X5S7r4HpToCszUXU6O1FqKRHAB6xfixyeJd3Z16yzITtNJ2gzCn
# QyE1ufRQtm8BZmPMVL9wBAH4uD2zdcvH3/5LoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIPUJLn77O2qulyi6ZVqTkMVTh2+VU3gtztdRIZ7/oFaKAgZd
# XrmPyroYEzIwMTkwOTE3MTkyMDAxLjI0MlowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJB
# RDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADXr1puwKo9zrYAAAAAANcwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNjUwWhcNMTkxMTIzMjAyNjUwWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQDdiIha4gkM4bDfHbchZGKOIuASSGISvvwK0tIA
# kL7hIbtG1r0X+Ybzt0lI3Hcy6C/ozxZIHPLtDUdLX2+E6XtGj8xHw6Q1xJWQbxts
# MvdLoszc51rkwPIIBfGzFMQB7iYhH9U1QPGGVRWEiMD3ZGdpkDkH7q8nPMgqzVjT
# dkHWynVaqdNMjst9lhKUBVHsptgAjOoNdcwX/Xz9CRxetlzi6hzLuFuZ47rnFIjq
# MPf7GnkbzdwvUXvoiMdP7PVATtW1M0l7Ny1VxcpTnUBrIlqaIl9O3pgggjoPLLfZ
# j+exulZi8K/E5ZVHJ3YIZ7LMUvQgTNPLs6eN4yJvwW5yuWC9AgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQU37inVSf/92m8M1ZjNmtNKaDqVTgwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEATAtoUsT5ALWyTHGwnNqeeoO4CCjRB7i0OLPeQcjv7JWTA9Qf
# 0OzONpepqV8vwxElyOMYNMRi8MQEVckDi1DpwqzJAh8WSImjaBAg9h0F9YwOuRtG
# DWF3r6BE72QOiJ8KtWRUFF2vPszCKQK2Zon9gu3OGivAmmBy+5LnC8kq75c7uKM4
# /Zr1LrbCinPF7GZBCGkRwQzRlLQp81N9eCmOBKpDdPjesqHGPb8MAk50HA1lme/z
# RAn6RAkF4+DWOL/rNu5fLh51PjxgQPn3gUT4Q/ah1dR9yoPN0lcNnPPx9vAJ5v2s
# mw0n1ajgw4FOvCqbDLj8qs12l6t4xqT617ltMDCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAzTZ24jTRpyU2peucTVbl/F0HEa2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErfqQwIhgPMjAxOTA5MTcy
# MzQ3NDhaGA8yMDE5MDkxODIzNDc0OFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4St+pAIBADAKAgEAAgIhtgIB/zAHAgEAAgIRYTAKAgUA4SzQJAIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAIBBgwsM+CPjl+LOl7f70rOqeGi0Yi75UEOfYMVQ
# Po5a/9Bl+Anpa+h/u+Ip1mlOuAt+NNdfFY2pKov3/DLe04DP3EWIyNCB4sumVEis
# vrQTgCXRgp3OmOnT7nyp0dpJy+p59z9wn0y1I6Qnhm/tyEI7iHx12fGtBE9nknsv
# nms7MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADXr1puwKo9zrYAAAAAANcwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgwoUpggqg6G2jrHpZ
# b1u4liofsgnNpdSUHpxlwtNJvQMwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCCljmAMJw9BHv3eSih0+yhBcs7IauKTg/VixBFGziTjODCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA169absCqPc62AAAAAADXMCIE
# IN4TLo7X2UxXfSttJz6N3RmzIQjwELkFxFxfH5QLrsQGMA0GCSqGSIb3DQEBCwUA
# BIIBAFGIuYCYKjKBhy0JZ/LyOzY2L8ndkzIPy+ureO1av664+CG843kOkfYBc65n
# cHVr2cqCTiXeWcHB7Tt2k7dyMaweJgtxlBwBStOGxz6SB/pEkw+85QldrG4CPkVm
# gMYC0AC14KFOwYi/4lXmd4/EmASpLHma74L9slMqy8PfowHNqA5pEl2bcAzS2kY/
# TUUgjfWeFnePgkbLMrmLS6O8dVDWeMgzf49jb/2zAhtyQ6m6Dc1xvro6h731F5MB
# hA87DCibiu/BqQqRfjciztJXK15T7z9gU0OpgaYxtygfr3y56uG6pMnaCkvcMa7r
# QV72uwK08X6i+IvzFyfBbmpKHGY=
# SIG # End signature block
