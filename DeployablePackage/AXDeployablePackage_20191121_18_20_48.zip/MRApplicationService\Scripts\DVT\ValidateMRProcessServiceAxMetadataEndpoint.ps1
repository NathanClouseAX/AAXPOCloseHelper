<#
.Synopsis
	DVT for checking if AX metadata endpoint is reachable. Pulls AOS server URI from AX adapter settings
#>
[CmdletBinding()]
Param
(
	# DVT log file path.
	[string]
	$Log
)

$scriptName = (Get-Item $PSCommandPath).BaseName
. "$PSScriptRoot\Helpers\ScriptSetup.ps1"
Set-LogPath -FullLogPath $Log
Write-EnvironmentDataToLog
. "$PSScriptRoot\Helpers\DVTScriptSetup.ps1"
Initialize-DVTScript
. "$PSScriptRoot\Helpers\EndpointHelpers.ps1"
. "$PSScriptRoot\Helpers\SqlHelpers.ps1"

<#
.Synopsis
	Get a given setting from the settings XML
#>
function Get-SettingsValue
{
	[CmdletBinding()]
	Param
	(
		# Adapter settings
		[ValidateNotNull()]
		$Settings,

		# Setting name
		[string]
		[ValidateNotNullOrEmpty()]
		$SettingName
	)

	Write-LogMessage -Message "Reading value for setting '$SettingName'"
	$settingValue = $Settings | Where-Object { $_.FieldDefinition.Name -eq $SettingName } | Select-Object -First 1 -Property 'Value'
	if(!$settingValue -or !$settingValue.Value)
	{
		throw "No $SettingName found in adapter settings"
	}

	return $settingValue.Value
}

<#
.Synopsis
	Gets the AX7ClientSettings object from the database whose connection string is stored in the given path
#>
function Get-AX7ClientSettings
{
	[CmdletBinding()]
	Param
	(
		# Path to connections file
		[string]
		[ValidateNotNullOrEmpty()]
		$Path
	)

	Write-LogMessage -Message 'Getting AX client settings'
	Write-LogMessage -Message "Reading connection string from '$Path' file."
	$sqlConnectionString = Get-DecryptedSqlConnectionString -Path $Path
	Write-LogMessage -Message 'Querying database for AX adapter settings'
	[xml]$adapterSettings = Invoke-SqlQuery -ConnectionString $sqlConnectionString -Query 'SELECT TOP 1 [Settings] from [Connector].[MapCategoryAdapterSettings] WHERE [AdapterId] = ''E3E10D70-FDAB-480C-952E-8397524F9236''' -ResultReader (Get-ExecuteScalarReader)
	if(!$adapterSettings)
	{
		throw "No AX adapter settings in database '$($sqlConnection.InitialCatalog)'"
	}

	$settings = $adapterSettings.SettingsCollection.ArrayOfSettingsValue.SettingsValue
	if(!$settings)
	{
		throw "No settings values found in database '$($sqlConnection.InitialCatalog)'"
	}

	$aosServer = Get-SettingsValue -Settings $settings -SettingName 'AOSServer'
	$certificateUserName = Get-SettingsValue -Settings $settings -SettingName 'CertUserName'
	$providerName = Get-SettingsValue -Settings $settings -SettingName 'ProviderName'
	$federationRealm = Get-SettingsValue -Settings $settings -SettingName 'FederationRealm'
	$certificateThumbprint = Get-SettingsValue -Settings $settings -SettingName 'CertThumbprint'
	$tokenIssuer = Get-SettingsValue -Settings $settings -SettingName 'TokenIssuer'
	$serviceName = [Microsoft.Dynamics.Performance.DataProvider.AxClient.AosServiceNames]::MetadataService
	Write-LogMessage -Message 'Creating AX7ClientSettings object'
	$clientSettings = New-Object Microsoft.Dynamics.Performance.DataProvider.AXClient.AX7ClientSettings -ArgumentList @($aosServer, $serviceName, $certificateUserName, $providerName, $federationRealm, $certificateThumbprint, $tokenIssuer)
	return $clientSettings
}

<#
.Synopsis
	Confirms we can communicate with the metadata service given valid client settings
#>
function Confirm-MetadataServiceValidInputs
{
	[CmdletBinding()]
	Param
	(
		# Client settings to connect with
		[ValidateNotNull()]
		$AX7ClientSettings
	)

	$result = New-TestResult
	$result.TestName = "Confirm-MetadataService.ValidInputs"
	$tableToTest = 'dirpartytable'
	
	$exception = $null
	$retryAction = {			
		Write-LogMessage -Message 'Validating authentication settings with metadata service'
		try
		{	
			$client = [Microsoft.Dynamics.Performance.DataProvider.AXClient.MetadataServices.AxMetadataServiceClient]::CreateClient($AX7ClientSettings)
			$metadata = $client.GetTableMetadataByName($tableToTest)
			return $true
		}
		catch
		{
			Write-LogMessage -Message ($_.ToString())
			Set-Variable -Name exception -Value $_ -Scope 2
			return $false
		}
	}

	# Retry every five seconds up to 12 times for a maximum of one minute
	$result.TestResult = Invoke-RetryLoop -RetryCount 12 -DelayInSeconds 5 -Action $retryAction
	if (!$result.TestResult)
	{
		$errorDetail = Write-ErrorDetail -ErrorThrown $exception -WriteToConsole -PassThru
		$result.AddOutput($errorDetail)
	}

	return $result
}

<#
.Synopsis
	Inserts or updates FRServiceUser record in the AX database.
#>
function InsertOrUpdate-FRServiceUser
{
	[CmdletBinding()]
	Param
	(
		# Connection String to database
		[ValidateNotNull()]
		$connectionString
	)

    $query = "update userinfo set ENABLE = 0 where ID = 'FRServiceUser'
					MERGE [dbo].[USERINFO] AS target
					USING
					(
						VALUES
						( 
							'FRServiceUser', 
							'FRServiceUser', 
							1, 
							'https://mintedtoken.dynamics.com', 
							'FRServiceUser@dynamics.com', 
							1, 
							'',
							'S-1-19-1241925437-3719476898-4060767950-17831512-2104045269-3825046075-1325424976-928167439-1769986175-660289321' 
						)
					) 
					AS source
					(
						[ID], 
						[NAME], 
						[ENABLE], 
						[NETWORKDOMAIN], 
						[NETWORKALIAS], 
						[DEFAULTPARTITION], 
						[COMPANY],
						[SID]
					)
					ON 
						target.[ID] = source.[ID]
					WHEN 
						MATCHED
							THEN 
								UPDATE 
								SET 
									target.[NAME] = source.[NAME],
									target.[ENABLE] = source.[ENABLE], 
									target.[NETWORKDOMAIN] = source.[NETWORKDOMAIN], 
									target.[NETWORKALIAS] = source.[NETWORKALIAS], 
									target.[DEFAULTPARTITION] = source.[DEFAULTPARTITION], 
									target.[COMPANY] = source.[COMPANY],
									target.[SID] = source.[SID]
					WHEN 
						NOT MATCHED
							THEN
								INSERT
								(
									[ID], 
									[NAME], 
									[ENABLE], 
									[NETWORKDOMAIN], 
									[NETWORKALIAS], 
									[DEFAULTPARTITION],
									[COMPANY],
									[SID]
								)
								VALUES
								(
									source.[ID], 
									source.[NAME], 
									source.[ENABLE], 
									source.[NETWORKDOMAIN], 
									source.[NETWORKALIAS], 
									source.[DEFAULTPARTITION], 
									source.[COMPANY],
									source.[SID] 
								);

					-- ISMICROSOFTACCOUNT was added in newer platform builds make sure it exists before attempting to set it.
					IF EXISTS
					(
						SELECT 1
						FROM sys.all_columns AS c
							 JOIN sys.tables AS t ON c.object_id = t.object_id
							 JOIN sys.schemas AS s ON t.schema_id = s.schema_id
						WHERE s.name = 'dbo'
							  AND t.name = 'USERINFO'
							  AND c.name = 'ISMICROSOFTACCOUNT'
					)
						BEGIN
							EXEC('
							UPDATE [dbo].[USERINFO]
							SET ISMICROSOFTACCOUNT = 1
							WHERE [ID] = ''FRServiceUser''
								  AND [ISMICROSOFTACCOUNT] != 1; -- only update if the ISMICROSOFTACCOUNT is not already 1.
							')
						END;"

    Invoke-SQLQuery -ConnectionStr $connectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
}

<#
.Synopsis
	Confirms the minted token user settings are correct in the AX database.
#>
function Confirm-MetadataServiceMintedTokenUser
{
	[CmdletBinding()]
	Param
	(	
		# Database name
		[string]
		[ValidateNotNullOrEmpty()]
		$DatabaseName,

		# SQL server instance name
		[string]
		[ValidateNotNullOrEmpty()]
		$ServerInstance,

		# SQL User Name
		[string]
		$UserName,

		# SQL User Password
		[string]
		$Password
	)

	$result = New-TestResult
	$result.TestName = "Confirm-MetadataService.MintedTokenUser"
	$result.TestResult = $false
	Write-LogMessage -Message 'Validating minted token user settings for communication with the metadata service.'
	
	try
	{	
		$credential = New-Object System.Management.Automation.PSCredential($UserName, ($Password | ConvertTo-SecureString))
		$connectionString = Get-ConnectionString -Server $ServerInstance -Database $DatabaseName -Credential $credential
		$query = "DECLARE @needsUpdate BIT= 0;
                    IF EXISTS
                    (
	                    SELECT 1
	                    FROM dbo.USERINFO
	                    WHERE ID = 'FRServiceUser'
                    )
	                    BEGIN
		                    -- FRServiceUser exists verifiy the fields are set as expected.
		                    SELECT @needsUpdate = 1
		                    FROM dbo.USERINFO
		                    WHERE ID = 'FRServiceUser'
				                    AND (NAME != 'FRServiceUser'
					                    OR ENABLE != 1
					                    OR NETWORKDOMAIN != 'https://mintedtoken.dynamics.com'
					                    OR NETWORKALIAS != 'FRServiceUser@dynamics.com'
					                    OR DEFAULTPARTITION != 1
										OR COMPANY != ''
					                    OR SID != 'S-1-19-1241925437-3719476898-4060767950-17831512-2104045269-3825046075-1325424976-928167439-1769986175-660289321');

		                    -- ISMICROSOFTACCOUNT was added in newer platform builds make sure it exists before verifying it's value.
		                    IF EXISTS
		                    (
			                    SELECT 1
			                    FROM sys.all_columns AS c
					                    JOIN sys.tables AS t ON c.object_id = t.object_id
					                    JOIN sys.schemas AS s ON t.schema_id = s.schema_id
			                    WHERE s.name = 'dbo'
					                    AND t.name = 'USERINFO'
					                    AND c.name = 'ISMICROSOFTACCOUNT'
		                    )
		                    BEGIN
                                EXEC [sp_executesql] 
									 N'SELECT @needsUpdate = 1
									   FROM [dbo].[USERINFO]
									   WHERE [ID] = ''FRServiceUser''
									 	    AND [ISMICROSOFTACCOUNT] != 1;', 
									 N'@needsUpdate BIT output', 
									 @needsUpdate OUTPUT;
		                    END;
	                    END;
                    ELSE
	                    BEGIN
	                    -- FRServiceUser record does not exist and needs to be added.
		                    SET @needsUpdate = 1;
	                    END;
						
                    SELECT 1 AS COLUMNANME 
                    WHERE @needsUpdate = 1;"

		$queryResult = Invoke-SQLQuery -ConnectionStr $connectionString -Query $query -ResultReader (Get-ExecuteScalarReader)
		if ($queryResult -eq 1)
		{
			$result.AddOutput("There is something wrong with the user 'FRServiceUser'. Executing InsertOrUpdate sql command.")
            InsertOrUpdate-FRServiceUser -connectionString $connectionString
        }

		$result.TestResult = $true
	}
	catch
	{
		$errorDetail = Write-ErrorDetail -ErrorThrown $_ -WriteToConsole -PassThru
		$result.AddOutput($errorDetail)
	}

	return $result
}

try
{
	$filePaths = Get-MRFilePaths
	Add-Type -Path (Join-Path -Path $filePaths.Server -ChildPath 'Connector\Microsoft.Dynamics.Performance.DataProvider.AXClient.dll')
	$clientSettings = Get-AX7ClientSettings -Path $filePaths.ServicesConnectionsConfig
	Write-LogMessage -Message 'Testing AX Metadata endpoint'
	$axMetadataEndpointAvailable = Confirm-EndpointAvailable -EndpointName "AxMetadataServiceEndpoint" -EndpointUrl "$($clientSettings.AosServer)/services/MetadataService"
	$resultsCollection.Add($axMetadataEndpointAvailable)
	
	$axDatabaseServer = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.DbServer'
	$axDatabaseName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.Database'
	$axUserName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.SqlUser'
	$axPassword = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.SqlPwd'
	$mintedTokenUser = Confirm-MetadataServiceMintedTokenUser -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserName $axUserName -Password $axPassword
	$resultsCollection.Add($mintedTokenUser)

	Write-LogMessage -Message 'Testing authentication with AX Metadata endpoint'
	$axMetadataEndpointAuthentication = Confirm-MetadataServiceValidInputs -AX7ClientSettings $clientSettings
	$resultsCollection.Add($axMetadataEndpointAuthentication)
}
catch
{ 
	Add-ExceptionFailureToTestRun -Exception $_ -TestName $scriptName -AddToRun $resultsCollection
} 

. "$PSScriptRoot\Helpers\DVTResultHandling.ps1"
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBqZUTXHaKYWLLc
# 6kZqjyDKbEtXbP1nuuHHuJFxgQw+a6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgvya6aS2T
# lJCoUix8LEg9Q0bgWVGhTq1SIdY18DqjKfEwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBOD59q1duIS9yGioW5D1E33kxvgnOa8wCz7+XckPuh9ioiGg1i
# slux1hsz4vuOdNbsk905SLZj861XqoCy0aF9jmZwUzjgzhHDvVV8Fo03dnV9H11C
# wXeQ0XzGq/kg2CF7m8HeaHyWfGflIX5POzEQiu1w7MAlq+Bwl6E7Hs+0K8qmB1pK
# W5GtzhS0V5vLQtknbJNMf9lWsZ9IEj6OQFkR6z78DIFZ+woDuFLr3Rn7ZMVgDU+o
# iH5ucinpBOxOzT+4CYLhfXKbuCuSaHvguiTEBcS8u+C8pNy3vPLhb6hMz+4i5FWY
# 3YlmNopGntR35qwlWb0H47S9AjQSytlkzYjboYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIJnnByN3WXeceXw4NhSJkois/hlCX1kMTSDuH6hMIPaiAgZd
# XsZaRHYYEzIwMTkwOTE3MTkyMDAwLjY4M1owBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjNC
# RDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADaSFUCZEiaNGYAAAAAANowDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNjUyWhcNMTkxMTIzMjAyNjUyWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0JENC00QjgwLTY5QzMxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQDHRSgt7i83GHPGTY6t76iVNqsEDDwz7yk//tti
# hHRHMjarGDnuPUq8yu9Fju16tfZA/oKKW78ZbRd56b5Ucarcs+MCH19LiEbvHQLA
# CsG8qCeaAynDGORd92jQ5GkqRgwuS5KAL7K4ExIDWc+D+Wg5iSzS+RtKw9dj+NXs
# /yWGmuYEUKhVrF7FPyS+3LRQ0+7DCO4xpmOml30GnEg38iUWaRtU3uo6VYtphtMU
# KcPeJG35snn6QyVNl7PA0Nhs2I+2W4ATxXxeaDE4/9g1DCAvvuLr3DLb4ZWCCn8c
# pKMu4drdKQ3mAisOJ41QFPTrpdK5CDYFRkpOGDC8MqWcLv8BAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUa9zI44dHDIECzixKbAU21k4/AC4wHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAS+xiwfdc8Xg0apcxdBfMGH1Vpkc1X+5DAmlIn0LckXe00GJ9
# KnSOstLpi9Odg7CudUqg/vCdleXLfCnEmkTqaygxHGWLhyD3u0J6qhVPpLqOMKJd
# J1SSTVQeeBtfuM6DBGBdlnEv9YOiU6k7R9kmPYxfW+lwJ7bSdKsafNH5a7nb4K9h
# ghLxdVpSQVbvMeUV00jHXRADn2FAr53Uf+Qdq84e3pLg+av6Im7rtywJRRVF9ULl
# 1UqudjC5XHmrgBAasFs+IugpKZSppUXy+QuEM0yl6+ct9KTso4oRk/cqbtuTX6Ju
# FM470AtX9FcPZTYESI/Qwi6Cjb3bElz3/XRSIDCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozQkQ0LTRCODAtNjlDMzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAdEzTTEotoQSpGzp52CkNu4LmhZKggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOEri3YwIhgPMjAxOTA5MTgw
# MDQyMzBaGA8yMDE5MDkxOTAwNDIzMFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4SuLdgIBADAKAgEAAgIbcwIB/zAHAgEAAgISODAKAgUA4Szc9gIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAA9ZefpnXzIojYAxAx8DP7ZFhYDGNaoxeEa7Fz+z
# Li39+2LxTBH9ZdQ+Unpvf+zT8wc9Lj1YQFKyW1DFdUYn//bBNGG37/l9Pgr3/yZn
# I0TyE9zIKre6sjYmbuGiZBFLlngcwM3nUAq9+eGBQ+qmfO1UshHKgUvZfu5K6Gqt
# e86FMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADaSFUCZEiaNGYAAAAAANowDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgK3rCYuccyMiWFUJj
# qrAKwgHEmyTlT5uFweodNWwLyPEwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCCKzbtbvNqlg5eLKt6EjGbjK5shpVYd9K2O+2sNaxUxEzCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA2khVAmRImjRmAAAAAADaMCIE
# IBFmFSaULqRWLFOFtKh1tN7EMcJFD7F8UV5Mw9jZKfM/MA0GCSqGSIb3DQEBCwUA
# BIIBALlDomJVu7xfz0bXDw7jTdkwFwmVSkAhGmdnLc/QuVZivOvuSMotpkpPaPxH
# BQ06BKwUNxEC8wz3uLMXr19VwoljFyRSvbPGj/Tex6Uc5F4G2TTxSg9evOibETXj
# +uMKOVFW1LVfl0vlQh+GmUokX/xkDRjcZz9TSYrEiXVcyzZJiox9K1p+OXq5jH6j
# jrYFC/FDa+tW41H5SKhA01yf/5a6uynoevP3OlWYBuLnRkSSWwJd/PpnKZRS+n1T
# gyjrrVRzUPWBMSu92YtoPnCLP0/4CsPGMYrlnCVs9+zjxpBQKAzeVZttX0U4zNNd
# WNvti1FzMUfc4dVrVOHov+Uvnlc=
# SIG # End signature block
