<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

function Locate-ConfigFile
{
    param(
        [string]$ScriptDirectory = $(Throw 'ScriptDirectory parameter required'),

        [string]$ConfigFileName = $(Throw 'ConfigFileName parameter required'),

        [ValidateSet("RetailServer", "HardwareStation", "AsyncClient", IgnoreCase = $false)]
        [string]$ComponentType = $(Throw 'ComponentType parameter required')
    )

    Log-TimedMessage 'Trying to locate configuration file...'

    $configFilePath = $null;

    switch -Regex ($ComponentType) 
    {
        "RetailServer|HardwareStation|AsyncClient"
        {
            $configFileFolder = Join-Path -Path (Get-Item -Path $ScriptDirectory).Parent.FullName -ChildPath 'Package'
            $configFilePath = Join-Path -Path $configFileFolder -ChildPath $ConfigFileName

            if ((Test-Path -Path $configFilePath))
            {
                Log-TimedMessage ('Found configuration file at {0}' -f $configFilePath)
            }
            else
            {
                throw 'ERROR! Missing configuration file from installation.'
            }
        }

        default 
        {
            throw 'Component not supported.'
        }
    }

    return $configFilePath
}

<#
.SYNOPSIS
Adds element to a .config file:

    <section name="commerceRuntime" type="Microsoft.Dynamics.Commerce.Runtime.Configuration.CommerceRuntimeSection, Microsoft.Dynamics.Commerce.Runtime.ConfigurationProviders, Version=6.3.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL"/>

in the XML section with XPath:
    
    '/configuration/configSections'

The above section sets AutoFlush property of the listener set to true.
#>
function Update-CommerceRuntimeConfigurationSectionClass
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),
        
        [string]$SectionName = 'commerceRuntime'
    )

    Log-TimedMessage 'Updating Commerce Runtime configuration section class...'

    $className = 'Microsoft.Dynamics.Commerce.Runtime.Configuration.CommerceRuntimeSection';
    $namespace = 'Microsoft.Dynamics.Commerce.Runtime.ConfigurationProviders';

    $commerceRuntimeSection = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = '/configuration/configSections';
        'childXpath' = ("section[@name='{0}']" -f $SectionName);
        'childName' = "section";
        'attributesHashtable' = @{
            'name' = $SectionName;
            'type' = ('{0}, {1}, Version=6.3.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35, processorArchitecture=MSIL' -f $className, $namespace);
        }
    }

    CreateOrUpdateChildXmlNodeWithAttributes @commerceRuntimeSection

    Log-TimedMessage 'Finished updating Commerce Runtime configuration section class.'
}

function SafeEnable-HardwareStationMonitoringLogging
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required')
    )

    try
    {
        Log-TimedMessage 'Enabling Hardware Station monitoring logging...'

        Enable-ServiceMonitoringLogging -MonitoringEventSourceNameFormat 'Microsoft Dynamics AX Retail Monitoring : Hardware Station {0}' `
            -MonitoringListenerName 'MonitoringEventLogTraceListener' -DefaultInstanceName 'HardwareStation' `
            -MonitoringSourceName 'RetailMonitoringTracer' -EventLogName 'Application' -ConfigXml $ConfigXml

        Log-TimedMessage 'Finished enabling Hardware Station monitoring logging.'
    }
    catch
    {
        Log-TimedError 'Enabling Hardware Station monitoring logging failed.'
        Log-Exception $_
    }
}

function SafeEnable-RetailServerMposMonitoringLogging
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required')
    )

    try 
    {
        Log-TimedMessage 'Enabling Retail Server Mpos monitoring logging...'

        Enable-ServiceMonitoringLogging -MonitoringEventSourceNameFormat 'Microsoft Dynamics AX Retail Monitoring : Retail Server {0} MPOS' `
            -MonitoringListenerName 'MposMonitoringEventLogTraceListener' -DefaultInstanceName 'RetailServer' `
            -MonitoringSourceName 'RetailMposMonitoringTracer' -EventLogName 'Retail MPOS Devices' -ConfigXml $ConfigXml

        Log-TimedMessage 'Finished enabling Retail Server Mpos monitoring logging.'
    }
    catch
    {
        Log-TimedError 'Enabling Retail Server Mpos monitoring logging failed.'
        Log-Exception $_
    }
}

function Enable-ServiceMonitoringLogging
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),
        [string]$MonitoringEventSourceNameFormat = $(Throw 'MonitoringEventSourceNameFormat parameter required'),
        
        [string]$MonitoringListenerName = $(Throw 'MonitoringListenerName parameter required'),
        [string]$MonitoringSourceName = $(Throw 'MonitoringSourceName parameter required'),
        
        [string]$DefaultInstanceName = $(Throw 'DefaultInstanceName parameter required'),
        [string]$EventLogName = 'Application'
    )

    $instanceName = SafeGet-InstanceName -ConfigXml $ConfigXml -DefaultInstanceName $DefaultInstanceName

    $monitoringEventSourceName = ($MonitoringEventSourceNameFormat -f $instanceName)

    Create-SharedEventLogTraceListener -ConfigXml $ConfigXml -ListenerName $MonitoringListenerName -EventSourceName $monitoringEventSourceName

    Create-TraceSource -ConfigXml $ConfigXml -SourceName $MonitoringSourceName -ListenerNames $MonitoringListenerName

    Update-AutoFlushList -ConfigXml $ConfigXml -ListenerName $MonitoringListenerName
    
    Create-RetailMonitoringEventSource

    Create-EventSource -LogName $EventLogName -Source $monitoringEventSourceName
}

<#
.SYNOPSIS
Derives web application name for the web service from the web.config.

.NOTES
In the case of failure it returns default value provided as a script parameter.
#>
function SafeGet-InstanceName
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),

        [string]$DefaultInstanceName = $(Throw 'DefaultInstanceName parameter required')
    )

    try
    {
        $listenerName = 'EventLogTraceListener';

        # derive the name of the web application name from the ending of the listener
        $listener = $ConfigXml.SelectSingleNode(("/configuration/system.diagnostics/sharedListeners/add[@name='{0}']" -f $listenerName))
        
        if ([bool]$listener)
        {
            $eventSourceName = $listener.GetAttribute('initializeData')
            $instanceName = ($eventSourceName -split ' ' | Select-Object -Last 1)
            if ((-not $instanceName) -and ([string]::IsNullOrEmpty($instanceName.Trim())))
            {
                throw 'instanceName has incorrect value.';
            }
        }
        else
        {
            $message = ('Could not find shared listener with name {0}.' -f $listenerName)
            throw $message;
        }
    }
    catch
    {
        $instanceName = $DefaultInstanceName

        Log-TimedError 'Deriving of the instance name failed.'
        Log-Exception $_
        Log-TimedMessage ('Using default instance name {0}.' -f $instanceName)
    }

    return $instanceName
}

<# 
.SYNOPSIS
Adds section to a .config file:

    <source name="$SourceName" switchValue="$TracingLevel">
        <listeners>
            <add name="$ListenerNames[0]" />
            <!-- ... -->
            <add name="$ListenerNames[n]" />
        </listeners>
    </source>

in the XML section with XPath:
    
    "/configuration/system.diagnostics/sources"

The above section creates trace source and attaches shared listeners to it.
#>    
function Create-TraceSource
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),
        [string]$SourceName = $(Throw 'SourceName parameter required'),
        
        [string[]]$ListenerNames,
        [string]$TracingLevel = 'Information'
    )

    $source = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = '/configuration/system.diagnostics/sources';
        'childXpath' = ("source[@name='{0}']" -f $SourceName);
        'childName' = 'source';
        'attributesHashtable' = @{
            'name' = $SourceName;
            'switchValue' = $TracingLevel;
        }
    }

    CreateOrUpdateChildXmlNodeWithAttributes @source

    $sourceListeners = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = ("/configuration/system.diagnostics/sources/source[@name='{0}']" -f $SourceName);
        'childXpath' = 'listeners';
        'childName' = 'listeners';
        'attributesHashtable' = @{
        }
    };

    CreateOrUpdateChildXmlNodeWithAttributes @sourceListeners

    $ListenerNames | Attach-SharedListener -ConfigXml $ConfigXml -SourceName $monitoringSourceName
}

<# 
.SYNOPSIS
Adds element to a .config file:

    <add name="$ListenerName" type="System.Diagnostics.EventLogTraceListener" initializeData="$EventSourceName" />

in the XML section with XPath:

    '/configuration/system.diagnostics/sharedListeners'

The above section creates a shared event log trace listener with specified name.
#>
function Create-SharedEventLogTraceListener
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),
        
        [string]$ListenerName = $(Throw 'ListenerName parameter required'),
        
        [string]$EventSourceName = $(Throw 'EventSourceName parameter required')
    )

    $sharedListener = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = '/configuration/system.diagnostics/sharedListeners';
        'childXpath' = ("add[@name='{0}']" -f $ListenerName);
        'childName' = 'add';
        'attributesHashtable' = @{
            'name' = $ListenerName;
            'type' = 'System.Diagnostics.EventLogTraceListener';
            'initializeData' = $EventSourceName;
        };
    }

    CreateOrUpdateChildXmlNodeWithAttributes @sharedListener
}

<# 
.SYNOPSIS
Adds element to a .config file:

    <add name="$ListenerName" />

in the XML section with XPath:
    
    "/configuration/system.diagnostics/sources/source[@name='$SourceName']/listeners"

The above section attaches shared listener to the trace source.
#>  
function Attach-SharedListener
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),
        
        [string]$SourceName = $(Throw 'SourceName parameter required'),
        
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [string]$ListenerName
    )

    $attachment = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = ("/configuration/system.diagnostics/sources/source[@name='{0}']/listeners" -f $SourceName);
        'childXpath' = ("add[@name='{0}']" -f $ListenerName);
        'childName' = 'add';
        'attributesHashtable' = @{
            'name' = $ListenerName
        }
    }

    CreateOrUpdateChildXmlNodeWithAttributes @attachment
}

<# 
.SYNOPSIS
Adds element to a .config file:

    <add name="$ListenerName" />

in the XML section with XPath:
    
    "/configuration/system.diagnostics/trace[@autoflush='true']/listeners"
	
The above section sets AutoFlush property of the listener set to true.
#>	
function Update-AutoFlushList
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required'),
        
        [string]$ListenerName = $(Throw 'ListenerName parameter required')
    )

    $autoFlushSwitchForListener = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = "/configuration/system.diagnostics/trace[@autoflush='true']/listeners";
        'childXpath' = ("add[@name='{0}']" -f $ListenerName);
        'childName' = 'add';
        'attributesHashtable' = @{
            'name' = $ListenerName
        }
    }
    
    CreateOrUpdateChildXmlNodeWithAttributes @autoFlushSwitchForListener
}

<#
.SYNOPSIS
	Makes sure that a certain child node exists with the correct attributes and attribute values, if it does not, creates it		

.EXAMPLE
PS C:\> $xml = [xml]@"
<a>
    <b name="c">
    </b> 
    <b name="d">
    </b>
</a>
"@
PS C:\> CreateOrUpdateChildXmlNodeWithAttributes -xmlDoc $xml -parentXPath '/a' -childXpath 'e' -childName 'e' -attributesHashtable @{}
PS C:\> $xml.OuterXml
<a><b name="c"></b><b name="d"></b><e /></a>

.EXAMPLE
PS C:\> $xml = [xml]@"
<a>
    <b name="c">
    </b> 
    <b name="d">
    </b>
</a>
"@
PS C:\> CreateOrUpdateChildXmlNodeWithAttributes -xmlDoc $xml -parentXPath "/a/b[@name='c']" -childXpath 'f' -childName 'f' -attributesHashtable @{'name'='noname'}
PS C:\> $xml.OuterXml
<a><b name="c"><f name="noname" /></b><b name="d"></b></a>

.EXAMPLE
PS C:\> $xml = [xml]@"
<a>
    <b name="c">
    </b> 
    <b name="d">
    </b>
</a>
"@
PS C:\> CreateOrUpdateChildXmlNodeWithAttributes -xmlDoc $xml -parentXPath "/a" -childXpath "b[@name='d']" -childName 'b' -attributesHashtable @{'name'='fi'}
PS C:\> $xml.OuterXml
<a><b name="c"></b><b name="fi"></b></a>
#>
function CreateOrUpdateChildXmlNodeWithAttributes
{    
    param(
        [xml]$xmlDoc = $(Throw 'xmlDoc parameter required'),

        [string]$parentXPath = $(Throw 'parentXPath parameter required'),
    
        [string]$childXpath = $(Throw 'childXpath parameter required'),
    
        [string]$childName = $(Throw 'childName parameter required'),
    
        [hashtable]$attributesHashtable,

        [switch]$UpdateOnly
    )

    $childXPath = $parentXPath + '/' + $childXpath
    $childNode = $xmlDoc.SelectSingleNode($childXPath)

    if ($childNode -eq $null)
    {
        Log-TimedMessage ('Child with XPath {0} was not found.' -f $childXPath)
        
        if ($UpdateOnly)
        {
            Log-TimedMessage 'Leaving function.'
            return;
        }
        else 
        {
            Log-TimedMessage ('Creating child node {0}.' -f $childName)
            
            $parentNode = $xmlDoc.SelectSingleNode($parentXPath)
            $childElement = $xmlDoc.CreateElement($childName)
            $childNode = $parentNode.AppendChild($childElement)
           
            Log-TimedMessage ('Finished creating child node {0}.' -f $childName)
        }
    }
    else
    {
        Log-TimedMessage ('Found element with XPath {0}.' -f $childXPath)
    }

    foreach($attributeKey in $attributesHashtable.Keys)
    {
        $attributeValueToSet = $attributesHashtable[$attributeKey]
        $existingAttributeValue = $childNode.GetAttribute($attributeKey)
        
        if ($existingAttributeValue -eq $null)
        {
            Log-TimedMessage "Creating attribute [$attributeKey] with value = $attributeValueToSet."
            $childNode.SetAttribute($attributeKey, $attributeValueToSet)
        }
        else 
        {
            if ($existingAttributeValue -ne $attributeValueToSet)
            {
                Log-TimedMessage "Setting attribute [$attributeKey] with value = $attributeValueToSet."
                $childNode.SetAttribute($attributeKey, $attributeValueToSet)
            }
            else
            {
                Log-TimedMessage "Attribute [$attributeKey] already has value = $attributeValueToSet."
            }
        }
    }
}

function CreateChildXmlNodeWithoutAttributes
{
    param(
        [xml]$xmlDoc = $(Throw 'xmlDoc parameter required'),

        [string]$parentXPath = $(Throw 'parentXPath parameter required'),
    
        [string]$childXpath = $(Throw 'childXpath parameter required'),
    
        [string]$childName = $(Throw 'childName parameter required'),

        [string]$innerText
    )

    $childXPath = $parentXPath + '/' + $childXpath
    $childNode = $xmlDoc.SelectSingleNode($childXPath)

    if ($childNode -eq $null)
    {
        Log-TimedMessage ('Child with XPath {0} was not found.' -f $childXPath)
        
        Log-TimedMessage ('Creating child node {0}.' -f $childName)
            
        $childElement = $xmlDoc.CreateElement($childName)

        if (-not ([string]::IsNullOrEmpty($innerText)))
        {
            $childElement.InnerText = $innerText
        }

        $parentNode = $xmlDoc.SelectSingleNode($parentXPath)
        [void]$parentNode.AppendChild($childElement)
           
        Log-TimedMessage ('Finished creating child node {0}.' -f $childName)
    }
}

function Update-RollingXmlWriterTraceListenerTypeName 
{
    param(
        [xml]$ConfigXml = $(Throw 'ConfigXml parameter required')
    )

    Log-TimedMessage 'Updating RollingXmlWriterTraceListener type name...'

    $rollingXmlWriterTraceListener = @{
        'xmlDoc' = $ConfigXml;
        'parentXPath' = '/configuration/system.diagnostics/sharedListeners';
        'childXpath' = ("add[@name='{0}']" -f 'RollingXmlWriterTraceListener');
        'childName' = 'add';
        'attributesHashtable' = @{
            'type' = 'Microsoft.Dynamics.Retail.Diagnostics.Sinks.RollingXmlWriterTraceListener, Microsoft.Dynamics.Retail.Diagnostics.Sinks';
        }
    }

    CreateOrUpdateChildXmlNodeWithAttributes @rollingXmlWriterTraceListener -UpdateOnly

    Log-TimedMessage 'Finished updating RollingXmlWriterTraceListener type name.'
}
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAjO1GquKTGIaxm
# gwGyELTmpquyfm01wOWQtTI1vcH2T6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg/MHagJ0C
# zcDG1PkL/ihiidGecQtDAgSxf6d5PzJCRp0wbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQB0ZWNoBx/lsAthikT+vK40BRpk7SrlDM7rSnG9I8htHRpYu2Re
# gmtIswSmBBWjpwqkeEd3EE3CO292nxmTKSYRe8hjARzTRBRrvB+B+ixmoEq0wncg
# ju9D8B3t0DmjuhhCSWnVTxVJXYFzkijcz0LsPdw8f958gKZjP1ZPGFeyAMHLH6qV
# 8+jKERhS54tur/8N0Wu7ISHzD5XfbN9eIR63yfQ3BhCtUgiWbePlDUazK0x47e6p
# lHc/XakPgAHXfX9x028r/74QJYfto2BhUXkE3QDgMn3l+zfxvfXxqF8rUkRjIYWC
# U1Nmv36iYP9AoxO0SteYFV1dortiuZIgYnCdoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIJk/4MJJybM0vRaXe6WXSyE06x5ZNF3Tu0IaBxHOMFS0AgZd
# XuYF1b8YEzIwMTkwOTE3MTkxOTU5LjgzMlowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjhF
# OUUtNEJEMC0yRUQwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADfro3F0K5CN88AAAAAAN8wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNzAxWhcNMTkxMTIzMjAyNzAxWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEU5RS00QkQwLTJFRDAxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCoqRbrXgcUOsw7KSxvnS4WD5RW4zMwO/p43DTG
# +BBGQu84PnbbBggnA1icqZmPcwR++e7Pnj26KxwEa8O1//ltsVSpC81g6NqGBHAD
# xm+Kr5UQL0aHzHu59K+QHgkCCNnh1J47etZFiPLVKTUNqAKs0AWW3c8jh0Bp4oOY
# vjsY7QUTxqqkjxvwpE0/EeAbnmsNlvFaVN5TwMK1WS7VRtNaNI2mnpwSNABtt+42
# vYs4Ly1dQI6wiep8A7/4j9+eIbSwBuyNGoujZZqXKCMEHWDyqpyxJN4dDcVOmLRY
# DlEKEYy+gMQQYzcu7iiwaLhb1B/TYqndZrbWe3JkMGWEuWQtAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUPP6QQZKLlWGG6y4YdTnlbGJjBgUwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAPmRgeKK6PayS+TNZjW3u/cGfEb6+pkPkQIEMhXsY4JvA7TW/
# NJb+oHEmP7d6H2tsyRaCpt1h5JxoSfGI3jVKBitEKBFuhkWfOGTkYK9oe/jxZv93
# M2J3P7/AwPq4FxC5hxz4EdyNME9Xt4IyOmZZ+lpCrPlfxJMuMvXQ/HJjv9Hk7dut
# nIDN85JXeOTbbQ1klNJ2jyAcwGiRRZxBhc63O3yw5l/w+bqXLrOFxDwzvKwxTwiH
# 7i3H86CUAApYcEo9zqfvcbsdpIstwn3mGafjHJtSTh7GQTjn4uaIKRl0SxBY4TvR
# TGaK3/wdznMdGX8G5kv3iRlJ5QpQohGQR20sBDCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4RTlFLTRCRDAtMkVEMDElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUACurcOgBJZhspwPuw1T/Fzl+RH4aggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErqxkwIhgPMjAxOTA5MTgw
# MjU3MjlaGA8yMDE5MDkxOTAyNTcyOVowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4SurGQIBADAKAgEAAgIeYwIB/zAHAgEAAgIRcDAKAgUA4Sz8mQIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAME7KeudnoMbegXFxAXTomWZl/oBavsQyiApHZXv
# UbS4dD2U2kWE6Xf/DSbdlO3asl4PKkpJClm9m9cfGM8PtZsPlp742xMu35cFX9UB
# BhA2AYTKx0ZZBLxEYreiyg9g6C3XBQ1mrW9p8G1swds73pc8iV2UzXVv3oQ9Jren
# zIOOMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADfro3F0K5CN88AAAAAAN8wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgQmp06R4C0Fm1KT+z
# Jm70Uu6DzsbSIJxXgj1HGT+W/NUwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCChwSnvV55dc2vKa2+LT24SDAqDtw6RUYrPC7zgmYsGLzCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA366NxdCuQjfPAAAAAADfMCIE
# IBEl2yh8IJyZCJa9aPww6B7ohgZ5GT4bl1BLrwLOD0apMA0GCSqGSIb3DQEBCwUA
# BIIBAKU7oMia9E3RbJF4tWryfsFn45fkoAtdb86U11/wHjRF3xMeRwnRUQCsTApa
# aTuiOVaZsdnkuuyatxAN+3xLUamPu+rYfU2HkOQG9xskV5bN/1EqpE40hGikbTG7
# 811Ej03Ju4tWqgrZpycJD6GJ3MyqmqhGO/5EeDZVMOufTe6w6OZ9PyGAphTezaeC
# cYjyDkpVJIKKqPM1sMpO8/reMfdu6r5mHWodPbsRG3PamfE++WprwExf5KAnLynw
# Z+VVIhyYOm/j+jITIq6YS7axz55mehzRH1w92zZd8urUeULR93OterwDvNzbtps6
# GECfC+zW7D0kys51HlowsQ0Eog0=
# SIG # End signature block
