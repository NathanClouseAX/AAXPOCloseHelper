<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

# Make script to interrupt if exception is thrown.
$ErrorActionPreference = "Stop"

$ScriptDir = split-path -parent $MyInvocation.MyCommand.Path;
. (Join-Path $ScriptDir 'Common-Configuration.ps1')
. (Join-Path $ScriptDir 'Common-Web.ps1')

function Get-FileVersion(
	[string] $filePath = $(throw 'FilePath is required'))
{
	if(-not (Test-Path -Path $filePath))
	{
		throw "$filePath doesn't exist."
	}
	return [System.Diagnostics.FileVersionInfo]::GetVersionInfo($filePath).FileVersion
}

function Compare-FileVersion(
	[string] $sourceVersion = $(throw 'sourceVersion is required'),
	[string] $targetVersion = $(throw 'targetVersion is required'))
{
	[Version] $sourceVersionValue = $sourceVersion
	[Version] $targetVersionValue = $targetVersion
	
	return $sourceVersionValue.CompareTo($targetVersionValue)
}

function Check-UpgradeEligibility(
	[string] $webSiteName = $(throw 'webSiteName is required'),
	[string] $flagFileSubPathToIdentifyCurrentVersion = $(throw 'flagFileSubPathToIdentifyCurrentVersion is required'),
	[string] $minSupportedVersion = $(throw 'minSupportedVersion is required'))
{
	$webSite = Get-WebSiteSafe -Name $webSiteName

	if(-not $webSite)
	{
		throw "Cannot find website with name: $webSiteName"
	}
	
	# check version support
	$currentVersion = Get-FileVersion -filePath (Join-Path $webSite.physicalPath $flagFileSubPathToIdentifyCurrentVersion)
	
	if((Compare-FileVersion -sourceVersion $currentVersion -targetVersion $minSupportedVersion) -lt 0)
	{
		throw "Current Version $currentVersion is lower than minimum supported version: $minSupportedVersion"
	}
	
	return $true
}

function Get-ChannelDbRegistryPath
{
    return 'HKLM:\SOFTWARE\Microsoft\Dynamics\{0}\RetailChannelDatabase\Servicing' -f (Get-ProductVersionMajorMinor)
}

function Get-ChannelDbServicingPropertyName(
    [int]$propertyIndex = '1'
)
{
    return 'UpgradeServicingData' + $propertyIndex
}

function Get-ChannelDbServicingDataFromRegistry()
{
    $result = @()
    $channelDbRegistryPath = (Get-ChannelDbRegistryPath)
    $propertyIndex = 1
    
    while($true)
    {
        $channelDbServicingPropertyName = (Get-ChannelDbServicingPropertyName -propertyIndex $propertyIndex)
        $channelDbEncryptedServicingData = Read-RegistryValue -targetRegistryKeyPath $channelDbRegistryPath -targetPropertyName $channelDbServicingPropertyName
        
        if($channelDbEncryptedServicingData)
        {
            $servicingDataAsSecureString = ConvertTo-SecureString $channelDbEncryptedServicingData
            $servicingDataAsPlainText = [System.Runtime.InteropServices.marshal]::PtrToStringAuto([System.Runtime.InteropServices.marshal]::SecureStringToBSTR($servicingDataAsSecureString))
            
            $propertyIndex += 1
            $result += $servicingDataAsPlainText
        }
        else
        {
            break;
        }
    }
    
    return $result
}

function Extract-ConnectionStringsFromWebConfig([string] $webConfigPath = $(throw 'webConfigPath is required'))
{
	[xml] $webConfigDoc = Get-Content $webConfigPath

	if($webConfigDoc.configuration.connectionStrings -and $webConfigDoc.configuration.connectionStrings.InnerXml)
	{
		return $webConfigDoc.configuration.connectionStrings.InnerXml
	}
	else
	{
		return $null
	}
}

function Create-WebSiteDBConfiguration(
[string]$connectionString = $(throw 'connectionString is required'))
{
	[hashtable]$ht = @{};

    # sample connection string for sql azure "Server=$dbServer;Database=$dbName;User ID=$dbUser;Password=$dbPassword;Trusted_Connection=False;Encrypt=True;"
    $connectionStringObject = New-Object System.Data.Common.DbConnectionStringBuilder
    $connectionStringObject.PSObject.Properties['ConnectionString'].Value = $connectionString
    
    $ht.server = $connectionStringObject['Server']
    $ht.database = $connectionStringObject['Database']
    $ht.sqlUserName = $connectionStringObject['User ID']
    $ht.sqlUserPassword = $connectionStringObject['password']
	$ht.encrypt = $connectionStringObject['encrypt']
	$ht.trustservercertificate = $connectionStringObject['trustservercertificate']
    
	return $ht
}

function Update-WebsiteConnectionStringSettings(
	[string] $webConfigPath = $(throw 'webConfigPath is required'),
	[string] $connectionStringsXml = $(throw 'connectionStringsXml is required'))
{
	[xml] $webConfigDocNew = Get-Content $webConfigPath
	$webConfigDocNew.SelectSingleNode("//configuration/connectionStrings").InnerXml = $connectionStringsXml
	$webConfigDocNew.Save($webConfigPath)
}

function Replace-WebsiteFiles(
	[string] $webSiteName = $(throw 'webSiteName is required'),
	[string] $newWebFilesPath = $(throw 'newWebFilesPath is required'))
{
    $physicalPath = Get-WebSitePhysicalPath -webSiteName $webSiteName
	
	# Stop website
	Stop-WebSite $webSiteName

    # Back-up the current working directory
	Backup-Directory -sourceFolder $physicalPath
	
	# Replace files
	Copy-Files -SourceDirPath $newWebFilesPath -DestinationDirPath $physicalPath
	
	# Start website
	Start-WebSite $webSiteName
}

function Get-AxDatabaseUserFromWebConfig(
    [xml] $webConfig = $(throw 'webConfig is required'),
    [string] $dbUserKey = $(Throw 'dbUserKey is required!'),
    [string] $dbUserPasswordKey = $(Throw 'dbUserPasswordKey is required!')
    )
{
    $DbServer = Get-WebConfigAppSetting -WebConfig $webConfig -SettingName 'DataAccess.DbServer'
    $Database = Get-WebConfigAppSetting -WebConfig $webConfig -SettingName 'DataAccess.Database'
    $encryption = Get-WebConfigAppSetting -WebConfig $webConfig -SettingName 'DataAccess.encryption'
    $disableDBServerCertificateValidation = Get-WebConfigAppSetting -WebConfig $webConfig -SettingName 'DataAccess.disableDBServerCertificateValidation'
    $dbUser = Get-WebConfigAppSetting -WebConfig $webConfig -SettingName $dbUserKey
    $dbUserPassword = Get-WebConfigAppSetting -WebConfig $webConfig -SettingName $dbUserPasswordKey
    
    if($DbServer -and $Database -and $dbUser -and $dbUserPassword)
    {
        return "Server=`"$DbServer`";Database=`"$Database`";User ID=`"$dbUser`";Password=`"$dbUserPassword`";Encrypt=$encryption;TrustServerCertificate=$disableDBServerCertificateValidation;"
    }
    else
    {
        throw "Cannot find the database credential information from web.config with key $dbUserKey and $dbUserPasswordKey"
    }
}

function Get-WebSitePhysicalPath([string]$webSiteName = $(throw 'webSiteName is required'))
{
    $webSite = Get-WebSiteSafe -Name $webSiteName
	
	if(!$webSite)
	{
		throw ("Cannot find the website with name: {0} " -f $webSiteName)
	}

    return $webSite.physicalPath
}

function Get-WebSiteId([string]$webSiteName = $(throw 'webSiteName is required'))
{
    $webSite = Get-WebSiteSafe -Name $webSiteName
	
	if(!$webSite)
	{
		throw ("Cannot find the website with name: {0} " -f $webSiteName)
	}

    return $webSite.Id
}

function Is-PackageDelta(
    [ValidateNotNullOrEmpty()]
    [string]$installationInfoFile = $(throw 'installationInfoFile is required'))
{
    [bool]$isPackageDelta = $false
    
	Log-TimedMessage 'Checking if the current package is of type delta.'

	
	$installInfoContent = [XML] (Get-Content -Path $installationInfoFile)
	$updateFilesNode = $installInfoContent.SelectSingleNode('//ServiceModelInstallationInfo/UpdateFiles')
	
	if($updateFilesNode -and $updateFilesNode.HasChildNodes)
	{
	   Log-TimedMessage 'Yes'
	   $isPackageDelta = $true 
	}
	else
	{
	    Log-TimedMessage 'No'
	}
	
	return $isPackageDelta
}

function Get-InstallationInfoFilePath([string]$scriptDir = $(throw 'scriptDir parameter is required'))
{
    $svcModelScriptsDir = (Split-Path (Split-Path $scriptDir -Parent) -Parent)
	$filePath = Join-Path $svcModelScriptsDir 'InstallationInfo.xml'
    
    if(-not(Test-Path -Path $filePath))
	{
	    throw ('Could not locate installation info file at location {0}' -f $filePath)
	}

    return $filePath
}

function Is-UpdateFileActionInclude(
    [ValidateNotNullOrEmpty()]
    [XML]$xml = $(throw 'xml parameter is required'))
{
    [bool]$isFileActionInclude = $false
    $updateAction = $xml.ServiceModelInstallationInfo.UpdateFiles.updateAction

    if([string]::IsNullOrWhiteSpace($updateAction))
    {
        throw 'File update action missing. Please specify whether you want to include or exclude update files.'
    }

    if($updateAction -eq 'include')
    {
        $isFileActionInclude = $true
    }

    return $isFileActionInclude
}

function Get-ListOfFilesToCopy(
    [bool]$isPackageDelta,
    
    [ValidateNotNullOrEmpty()]
    [string]$installationInfoXmlPath = $(throw 'installationInfoXmlPath parameter is required'),

    [ValidateNotNullOrEmpty()]
    [string]$updatePackageCodeFolder = $(throw 'updatePackageCodeFolder parameter is required'))
{
    if($isPackageDelta)
    {
        $installInfoContent = [XML] (Get-Content -Path $installationInfoXmlPath)
        [bool]$includeFiles = Is-UpdateFileActionInclude -xml $installInfoContent
        
        $filesNode = Select-Xml -XPath '//ServiceModelInstallationInfo/UpdateFiles/File' -Xml $installInfoContent

        if($includeFiles)
        {
            $listOfFilesToCopy = $filesNode | % {$_.Node.Name}
        }
        else
        {
            $filesToExclude = @()
            $filesNode | % {
                $fullPath = (Join-Path $updatePackageCodeFolder ("{0}\{1}" -f $_.Node.RelativePath, $_.Node.Name))
                $filesToExclude += $fullPath
            }

            $listOfFilesToCopy = Get-ChildItem -File -Path $updatePackageCodeFolder -Recurse | ? { $_.FullName -notin $filesToExclude } | % {$_.Name}
        }

    }
    else
    {
        $listOfFilesToCopy = Get-ChildItem -File -Path $updatePackageCodeFolder -Recurse | % {$_.Name}
    }

    return $listOfFilesToCopy
}

function Check-IfAnyFilesExistInFolder(
    [string]$folderPath = $(throw 'folderPath parameter is required')
)
{
    if(!(Test-Path -Path $folderPath))
    {
        Log-TimedMessage ("Folder {0} does not exist." -f $folderPath)
        return $false
    }

    $fileList = Get-ChildItem -File $folderPath -Recurse | Measure-Object
    if($fileList.Count -eq 0)
    {
        Log-TimedMessage ("No files exist in the {0} folder." -f $folderPath)
        return $false
    }

    return $true
}

function Check-IfCustomPublisherExistsInInstallInfoXml(
    [string]$installationInfoXml = $(throw 'installationInfoFile is required'))
{
    [xml]$content = Get-Content $installationInfoXml
    
    Log-ActionItem 'Checking if CustomPublisher node is populated in the installation info file'
    $customPublisher = $content.ServiceModelInstallationInfo.CustomPublisher

    if([string]::IsNullOrWhiteSpace($customPublisher))
    {
        Log-ActionResult 'No'
        return $false
    }
    else
    {
        Log-ActionResult ('Yes. Its value is [{0}]' -f $customPublisher)
        return $true
    }
}

function Check-IfCurrentDeploymentOfComponentIsCustomized(
    [string]$componentName = $(throw 'componentName is required'),
    [string]$updatePackageRootDir = $(throw 'installationInfoFile is required'))
{
    [bool]$isCurrentDeploymentCustomized = $false

    Log-ActionItem 'Checking whether the current deployment on the machine is customized'

    # Load the installation info assembly
    $AxInstallationInfoDllPath = Join-Path $updatePackageRootDir 'Microsoft.Dynamics.AX.AXInstallationInfo.dll'
    Add-Type -Path $AxInstallationInfoDllPath

    # Get a list of all service model installation info
    $serviceModelInfoList = [Microsoft.Dynamics.AX.AXInstallationInfo.AXInstallationInfo]::GetInstalledServiceModel()

    $currentServiceModelInfo = $serviceModelInfoList | ? {$_.Name -ieq $componentName}

    if(!([string]::IsNullOrWhiteSpace($currentServiceModelInfo)) -and (Check-IfCustomPublisherExistsInInstallInfoXml -installationInfoXml $currentServiceModelInfo.InstallationInfoFilePath))
    {
        Log-ActionResult 'Yes'
        $isCurrentDeploymentCustomized = $true
    }
    else
    {
        Log-ActionResult 'No'
    }

    return $isCurrentDeploymentCustomized
}

function Check-IfUpdatePackageIsReleasedByMicrosoft(
    [string]$installationInfoXml = $(throw 'installationInfoFile is required'))
{
    return (-not (Check-IfCustomPublisherExistsInInstallInfoXml -installationInfoXml $installationInfoXml))
}

function Rename-InstallationInfoFile(
    [string]$filePath = $(throw 'filePath is required'))
{
    $folderPath = Split-Path $filePath -Parent
    $fileName = Split-Path $filePath -Leaf

    $renamedInstallInfoFilePath = Join-Path $folderPath ('Delta_{0}_{1}' -f $(Get-Date -f yyyy-MM-dd_hh-mm-ss), $fileName)

    Log-TimedMessage ('Renaming the manifest installation info file [{0}] to [{1}]' -f $filePath, $renamedInstallInfoFilePath)
    
    Rename-Item -Path $filePath -NewName $renamedInstallInfoFilePath -Force | Out-Null
    
    Log-TimedMessage 'Done renaming the file.'

    return $renamedInstallInfoFilePath
}

function Get-LcsEnvironmentId()
{
    $monitoringInstallRegKeyPath = 'HKLM:\SOFTWARE\Microsoft\Dynamics\AX\Diagnostics\MonitoringInstall'
    Log-TimedMessage ('Trying to find LCS Environment Id from registry key - {0}' -f $monitoringInstallRegKeyPath)

    $value = Read-RegistryValue -targetRegistryKeyPath $monitoringInstallRegKeyPath -targetPropertyName 'LCSEnvironmentID'

    if($value)
    {
        Log-TimedMessage ('Found LCS Environment Id - {0}' -f $value)
    }    

    return $value
}

function CreateOrUpdate-ServicingStepSetting(
    [ValidateNotNullOrEmpty()]
    $settingsFilePath = $(throw 'settingsFilePath is required'),
    
    [ValidateNotNullOrEmpty()]
    $runbookStepName = $(throw 'runbookStepName is required'),
    
    [ValidateNotNullOrEmpty()]
    $propertyName = $(throw 'propertyName is required'),
    
    $value = $(throw 'value is required'))
{
    $settingsJson = Get-Content $settingsFilePath -Raw | ConvertFrom-Json

    if(!$settingsJson)
    {
        $settingsJson = New-Object psobject
    }

    Log-TimedMessage ('Check if step [{0}] exists in the file.' -f $runbookStepName)
    if($settingsJson.$runbookStepName -eq $null)
    {
        Log-TimedMessage ('No. Adding Step = [{0}] PropertyName = [{1}] Value = [{2}]' -f $runbookStepName, $propertyName, $value)
        $obj = New-Object psobject | Add-Member -PassThru NoteProperty -Name $propertyName -Value $value -Force
        $settingsJson | Add-Member -MemberType NoteProperty -Name $runbookStepName -Force -Value $obj
    }
    else
    {
        Log-TimedMessage ('Yes. Updating Step = [{0}] PropertyName = [{1}] Value = [{2}]' -f $runbookStepName, $propertyName, $value)
        $settingsJson.$runbookStepName | Add-Member -MemberType NoteProperty -Name $propertyName -Value $value -Force
    }
    
    Log-TimedMessage ('Saving the file {0}' -f $settingsFilePath)
    $settingsJson | ConvertTo-Json | Out-File $settingsFilePath -Force
}

function Get-DevToolsInstalled([string]$scriptDir = $(throw 'scriptDir parameter is required'))
{
    Import-Module "$scriptDir\CommonRollbackUtilities.psm1" -DisableNameChecking
    $webroot = Get-AosWebSitePhysicalPath
    $webconfig=Join-Path $webroot "web.config"
    $DevInstall=$false
    
    [System.Xml.XmlDocument] $xd=New-Object System.Xml.XmlDocument
    $xd.Load($webconfig)
    $ns=New-Object System.Xml.XmlNamespaceManager($xd.NameTable)
    $ns.AddNamespace("ns",$xd.DocumentElement.NamespaceURI)

    $key="Infrastructure.VSToolsCount"

    $VScount = $xd.SelectSingleNode("//ns:add[@key='$key']",$ns)

    if($VScount -ne $null){
        
        if($VScount.GetAttribute("value") -gt 0)
        {
            $DevInstall=$true
        }
    }
    return $DevInstall 
}


# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBWfX83mGxoTTEo
# X+dlET+9ZYZcUmIHFijM3M3a2/WWx6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgeEkR++5r
# T6QVFRDCfthMvWiSosZqFMfLhzP9PF1IZaowbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQAFXNGx1GrrjY2ylLAg4M9JSHCrEFQGenxqRftHprr2yqZGHqVH
# huVyXC6Arwk8FHLKFyWJF11wmiirevgx5s+VUw1gwGKUYXe9dTYnyAmvMJOWy8Xk
# +txCIwsSvhiuiOUgDtBu+2ZWzXxr/KxaatsfLG4ktNOaOvZqwjQg3uP2A+8Iq1x0
# XLL2ZN3DDBo9AHWrVnlPh691e6wA5EhbCTPVmMCbh0yqSdko783ZizNUxDQe4oYb
# WdzN42sgYNFywkpf3c8dczpzfZGWGcRf1KA+zUccFoLd1Ph2CaGaIfhxkiTim4V9
# ukfFOS2E5UgyZUUHVqhVEiA/dxmAxHX4vySnoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIAxPql1JXmNhGZFJB6xwzbXcWLlPlnuElNFbEo1hvV0NAgZd
# XvLwIasYEzIwMTkwOTE3MTkyMDAyLjQ5OFowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQw
# ODItNEJGRC1FRUJBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADiGDh7ZunqwdgAAAAAAOIwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNzAzWhcNMTkxMTIzMjAyNzAzWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDA4Mi00QkZELUVFQkExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCoqwO9hRdzQi1uZnyzvw9BGeWHLNNKIjEorLFy
# welhfRjXT+/EMxcAMqcVv/qmUnM6mh2wx/IZW8ZM39w4mIAHaUI5xpC7o8CrVkmj
# 9vf5VX+4xah8vb+nh/i3TotC77az0Vt+DMgr6cWcjluB9Ydz5MQgS+UWttbA6oHF
# S9ZntKLMPEE1EV5iOC8ni3Ux9wnCNgIDQ1047BQX90LDviWMgDmFq03C58sFTeg6
# 4oJoKwyZOcPsEeFax35dk/T0WW2flA7dd8MMgfXeiFEbs1fJR7AFXxfLfUtGhlT5
# pEN3NsGjoR6bKelRDPk+Q9j4fMSV9a/Ns+u1kZZhnDj9jVgtAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUiT6Q+gbD9qfnKwyS9t9r6BLS8XswHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAEUB7uyEngbiUhyrg0SNOO9OHB9AewWM3hCKw9eWsL4jEXGCH
# yDh6bxs2TlkID9h5tEa+5L01LtVa0kmkO4tYD1nYajJsOVgZ0kuW8XjIYcfVLAEn
# hPOL1LvNjXmWqRkox9/GAG+Fk/k7Yk5HKCOfawPgkwqtdPLbSMVX2XK94ne+jhEy
# B9B74ZZ8Tjlo8BsuLpemWuUaEyxv6KNq6xplYtxcKzVhns2CwTg7hLI8xt+pQkbQ
# SgtmQB32zs+cLZFB26oe/ZlCqHIz+K96sX+UzfO8n+oNbk8fifKXZwIuYh7fmbWp
# 4Fqp1UxPD6CERFoQVZRhX0HZBC1Mdjq/dGgKljCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpEMDgyLTRCRkQtRUVCQTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAckAlIXhDnr2iPWXP90Bq5F+NoguggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErD0owIhgPMjAxOTA5MTcx
# NTUyNDJaGA8yMDE5MDkxODE1NTI0MlowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4SsPSgIBADAKAgEAAgIPUgIB/zAHAgEAAgIRWDAKAgUA4SxgygIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAAgh+G2FTfcyIskalCInHIPMIjRw1ijtRQrxfZqI
# EpE6WrzkqmFuuuIlKbOCQUNOYKsmwumlwpsFEl56fRV50OuTSUDBL2XsetbBsHSB
# Hc3HW4VHJwjD3yg5Wgc9+JRSsGPVUTl6Yn9MV8E8ybnd5+YKH0bCqfTQLBmv5nsB
# cCM5MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADiGDh7ZunqwdgAAAAAAOIwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQg1fUeY1l1B7uvRTiR
# f4U9yaUj1HGvwjlsiYX0qk3njlQwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCDfAaSUpkAhrm1sFWuLVvmjL3qBzF/5w51TfH4gzjLKyzCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA4hg4e2bp6sHYAAAAAADiMCIE
# IKLGto0zXuGVFt6m5MDtS2v+g0I6jnzNNliXEmmeecIAMA0GCSqGSIb3DQEBCwUA
# BIIBAJ4qGpeCg2blV9dso9RFqEllt6eKowOBgI5uaHgi1O+177t/N3Honpt39q0H
# DzE/i4t9MBXqnm3FVlC23KB3jivxYVl+zTJ6zFlCwP3IBI7b9ua58IzMA74tgrgf
# nzfteY2SAmnDBvrZewl2agLH6NYl58gsAlQxfmWDu2sNDmjv902sKTRJR9vnKzM1
# hMzHZy7zWgmQflGYv/KcZfTSddqxyjK9kSTSZj9xu9dUpP7Dp1fna6A6KnXoObg0
# XgIQgxteX1VsfheeCmVguN1JU+K8xBd9eyJs7X50WETIuXqs74a1NyRfwZUT3bfm
# VQV5f2C8djxUNFA/Fx0KssMpNLE=
# SIG # End signature block
