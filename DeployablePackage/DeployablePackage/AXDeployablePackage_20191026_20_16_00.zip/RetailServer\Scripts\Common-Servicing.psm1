<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
. $scriptDir\Common-Web.ps1
. $scriptDir\Common-Configuration.ps1

function CheckIf-CertificateExistInTargetStore(
    [string]$certificateThumbprint = $(throw 'certificateThumbprint is required.'),
    [string]$certificateStore = 'My',
    [string]$certificateRootStore = 'LocalMachine'
)
{
    $queryForCertificateInTargetStore = Get-ChildItem -Path Cert:\$certificateRootStore\$certificateStore | Where Thumbprint -eq $certificateThumbprint
    return ($queryForCertificateInTargetStore -ne $null)
}

function Install-Certificate(
    [ValidateNotNullOrEmpty()]
    [string]$certificateFilePath = $(Throw 'certificateFilePath parameter required.'),

    [Security.SecureString]$secureCertificatePassword = $(Throw 'secureCertificatePassword parameter required.'),
    [string]$certificateStore = 'My',
    [string]$certificateRootStore = 'LocalMachine',
    
    [ValidateNotNullOrEmpty()]
    [string]$expectedThumbprint,
    [string]$logFile = $(Throw 'logFile parameter required.')
)
{
    # Check if pfx file exists.
    if (-not (Test-Path -Path $certificateFilePath))
    {
        Throw-Error ('Unable to locate certificate file {0}' -f $certificateFilePath)
    }

    try
    {
        [int]$keyStorageFlags = 0
        $keyStorageFlags = $keyStorageFlags -bor ([int]([System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable))
        $keyStorageFlags = $keyStorageFlags -bor ([int]([System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet))
        $keyStorageFlags = $keyStorageFlags -bor ([int]([System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet))

        # Check if certificate has already been installed.
        $certificateToInstall = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @($certificateFilePath, $secureCertificatePassword, $keyStorageFlags)

        Write-Log ('Check if certificate already exits in target store {0}\{1}.' -f $certificateRootStore, $certificateStore) $logFile
        $doesCertificateExistInTargetStore = CheckIf-CertificateExistInTargetStore -certificateThumbprint $certificateToInstall.Thumbprint -certificateStore $certificateStore

        # Validate that the certificate thumbprint from pfx file matches expectedThumbprint.
        if ($certificateToInstall.Thumbprint -ne $expectedThumbprint)
        {
            throw ('Certificate thumbprint from pfx file {0} did not match expected thumbprint {1}.' -f $certificateToInstall.Thumbprint, $expectedThumbprint)
        }
        
        # If certificate is not present in the store then proceed with installation.
        if (-not($doesCertificateExistInTargetStore))
        {
            Write-Log ('Installing certificate to {0}\{1}.' -f $certificateRootStore, $certificateStore) $logFile
            $X509Store = New-Object System.Security.Cryptography.X509Certificates.X509Store($certificateStore, $certificateRootStore)

            $X509Store.Open([Security.Cryptography.X509Certificates.OpenFlags]::MaxAllowed);
            $X509Store.Add($certificateToInstall);
            $X509Store.Close()
            Write-Log ('Successfully installed certificate with thumbprint {0}.' -f $certificateToInstall.Thumbprint) $logFile
        }
        else
        {
            Write-Log ('Certificate with thumbprint {0} already exists in target store. Skipping install.' -f $certificateToInstall.Thumbprint) $logFile
        }
    }
    catch
    {
        Throw-Error $_
    }
}

function Get-BackupFolderPath(
    [string]$folderToBackup = $(Throw 'folderToBackup parameter is required.')
)
{
    $currentTimeStamp = Get-Date -format "MM-dd-yyyy_HH-mm-ss"
    return (Join-Path -Path $folderToBackup -ChildPath ('Backup_{0}' -f $currentTimeStamp))
}

function ModifyExisting-ChannelDbConnectionString(
    [string]$existingConnectionString = $(throw 'existingConnectionString is required.'),
    [string]$newChannelDbUser = $(throw 'newChannelDbUser is required.'),
    [string]$newChannelDbUserPassword = $(throw 'newChannelDbUserPassword is required.'),
    [string]$newServerName = $(throw 'newServerName is required.'),
    [string]$newDatabaseName = $(throw 'newDatabaseName is required.')
)
{
    $connectionStringBuilderAsReference = New-Object System.Data.SqlClient.SqlConnectionStringBuilder -ArgumentList $existingConnectionString
    $serverNameToUse = $connectionStringBuilderAsReference.'Server'
    $databaseNameToUse = $connectionStringBuilderAsReference.'Database'

    $usePassedServerName = CheckIf-UserProvidedValidSqlServerData -sqlServerDataString $newServerName
    $usePassedDatabaseName = CheckIf-UserProvidedValidSqlServerData -sqlServerDataString $newDatabaseName

    # Use the passed data if it is valid.
    if ($usePassedServerName)
    {
        $serverNameToUse = $newServerName
    }
    if ($usePassedDatabaseName)
    {
        $databaseNameToUse = $newDatabaseName
    }

    $newConnectionString = Generate-ChannelDbConnectionString -serverName $serverNameToUse `
                                                              -databaseName $databaseNameToUse `
                                                              -channelDatabaseUser $newChannelDbUser `
                                                              -channelDatabaseUserPassword $newChannelDbUserPassword `
                                                              -encrypt $connectionStringBuilderAsReference.Encrypt `
                                                              -trustServerCertificate $connectionStringBuilderAsReference.TrustServerCertificate

    return $newConnectionString
}

function Generate-ChannelDbConnectionString(
    [string]$serverName = $(throw 'serverName is required.'),
    [string]$databaseName = $(throw 'databaseName is required.'),
    [string]$channelDatabaseUser = $(throw 'channelDatabaseUser is required.'),
    [string]$channelDatabaseUserPassword = $(throw 'channelDatabaseUserPassword is required.'),
    [string]$encrypt = 'True',
    [string]$trustServerCertificate = 'False'
)
{
    $channelDbConnectionString = 'Application Name=Retail Server;Server="{0}";Database="{1}";User ID="{2}";Password="{3}";Trusted_Connection=False;Encrypt={4};TrustServerCertificate={5};' -f $serverName, `
                                        $databaseName, `
                                        $channelDatabaseUser, `
                                        $channelDatabaseUserPassword, `
                                        $encrypt, `
                                        $trustServerCertificate
    return $channelDbConnectionString
}

function Save-ChannelDbServicingDataToRegistry(
    [string]$servicingData = $(throw 'servicingData is required.'),
    [string]$targetRegistryKeyPath = $(throw 'targetRegistryKeyPath is required.'),
    [string]$targetPropertyName =  $(throw 'targetPropertyName is required.')
)
{
    # Convert servicing data to secure text.
    $servicingDataAsSecureStringObject = ConvertTo-SecureString -AsPlainText $servicingData -Force
    $servicingDataAsEncryptedString = ConvertFrom-SecureString $servicingDataAsSecureStringObject

    # Save encrypted servicing data to the registry
    if (-not(Test-Path -Path $targetRegistryKeyPath))
    {
        New-Item -Path $targetRegistryKeyPath -ItemType Directory -Force
    }

    New-ItemProperty -Path $targetRegistryKeyPath -Name $targetPropertyName -Value $servicingDataAsEncryptedString -Force
}
##############################################################
#
#    Rotate Auth data custom deployable package functions.
#
##############################################################
function Load-RotationInfoModule(
    [string]$packageRootPath = $(Throw 'packageRootPath parameter is required.')
)
{
    $serviceTemplateFolderPath = Join-Path -Path $packageRootPath -ChildPath 'RotateConfigData'
    $pathToRotationInfoModuleDllParent = Join-Path -Path $serviceTemplateFolderPath -ChildPath (Join-Path -Path 'Scripts' -ChildPath 'RotationInfo')
    $pathToRotationInfoModuleDll = Join-Path -Path $pathToRotationInfoModuleDllParent -ChildPath 'RotationInfoModule.dll'
    
    if (-not(Test-Path -Path $pathToRotationInfoModuleDll))
    {
        throw 'Unable to locate DLL file RotationInfoModule.'
    }
    
    # Import RotationInfoModule.Dll
    Import-Module $pathToRotationInfoModuleDll
    Add-Type -Path $pathToRotationInfoModuleDll
}

function Get-RotationInfoDecryptor(
    $rotationInfo = $(Throw 'rotationInfo parameter is required.')
)
{
    $rotationInfoDecryptor = New-Object Microsoft.Dynamics.AX.Servicing.Rotation.Decryptor $rotationInfo
    return $rotationInfoDecryptor
}

function Get-RotationInfo(
    [string]$serviceModelName = $(Throw 'serviceModelName parameter required.'),
    [string]$packageRootPath = $(Throw 'packageRootPath parameter required.')
)
{
    # Locate and validate the template file.
    $serviceTemplateFolderPath = Join-Path -Path $packageRootPath -ChildPath 'RotateConfigData'
    $rotationInfo = Get-ServicingRotationInfo -Name $serviceModelName -Path $serviceTemplateFolderPath

    # Check if the rotationInfo object is null or not. If it is null potentially the user did not add it to the template.
    # If it wasn't added to the template we should not be validating the presence of encryption thumbprint.
    if ($rotationInfo -ne $null)
    {
        if ($rotationInfo.EncryptionThumbprint -eq $null)
        {
            throw ('Servicing template information for {0} has not been encrypted.' -f $serviceModelName)
        }
    }
    
    return $rotationInfo
}

function GetValueFor-CertificateThumbprintWithKey(
    [string]$key = $(Throw 'key parameter required.'),
    $rotationInfo = $(Throw 'rotationInfo parameter required.')
)
{
    $certificateThumbprintObject = $rotationInfo.CertificateThumbprints | Where {$_.Key -eq $key}
    return $certificateThumbprintObject.Value
}

function GetValueFor-KeyValuePairWithKey(
    [string]$key = $(Throw 'key parameter required.'),
    $rotationInfo = $(Throw 'rotationInfo parameter required.'),
    $rotationInfoDecryptor = $(Throw 'rotationInfoDecryptor parameter required.')
)
{
    $keyValuePairObject = $rotationInfo.KeyValues | Where {$_.Key -eq $key}
    if ($keyValuePairObject)
    {
        $rotationInfoDecryptor.Decrypt($keyValuePairObject)
        $result = $keyValuePairObject.Value
    }

    return $result
}

function CheckIf-UserProvidedValidCredentialData(
    [string]$credentialString
)
{
    $result = $true
    if ([System.String]::IsNullOrWhiteSpace($credentialString))
    {
        $result = $false
    }
    if (($credentialString -eq '[userId]') -or ($credentialString -eq '[Password]'))
    {
        $result = $false
    }
    
    return $result
}

function CheckIf-UserProvidedValidSqlServerData(
    [string]$sqlServerDataString
)
{
    $result = $true
    if ([System.String]::IsNullOrWhiteSpace($sqlServerDataString))
    {
        $result = $false
    }
    if (($sqlServerDataString -eq '[ChannelDatabaseServerName]') -or ($sqlServerDataString -eq '[ChannelDatabaseName]'))
    {
        $result = $false
    }
    if (($sqlServerDataString.Split("[").Count -ne 1) -or ($sqlServerDataString.Split("]").Count -ne 1))
    {
        $result = $false
    }

    return $result
}

function Update-RetailWebsiteSSLBinding(
    [string]$websiteName = $(Throw 'websiteName parameter required.'),
    [string]$webAppPoolUser = $(Throw 'webAppPoolUser parameter required.'),
    [string]$certificateThumbprint = $(Throw 'certificateThumbprint parameter required.'),
    [string]$logFile = $(Throw 'logFile parameter required.')
)
{
    # Check if any https bindings exist for the website. If any exist we need to update the SSL binding.
    $websiteBindings = Get-WebBindingSafe -Name $websiteName -Protocol 'https'
    if ($websiteBindings)
    {
        foreach ($websiteBinding in $websiteBindings)
        {
            $websiteBindingProperties = Get-WebBindingProperties -Binding $websiteBinding
            $httpsPort = $websiteBindingProperties.Port

            # Update the website SSL binding.
            $websiteConfig = Create-WebSiteConfigMap -httpsPort $httpsPort -certificateThumbprint $certificateThumbprint -websiteAppPoolUsername $webAppPoolUser
            Invoke-ScriptAndRedirectOutput -scriptBlock {Add-SslBinding -WebSiteConfig $websiteConfig} -logFile $logFile
        }
    }
    else
    {
        Write-Log ('Website {0} does not use https. Skipping SSL binding update.' -f $websiteName) -logFile $logFile
    }
}

function InstallCertificatesAndUpdateIIS(
    $rotationInfo = $(Throw 'rotationInfo parameter required.'),
    $rotationInfoDecryptor = $(Throw 'rotationInfoDecryptor parameter required.'),

    [string]$packageRootPath = $(Throw 'packageRootPath parameter required.'),
    [boolean]$updateWebsiteSSLBinding = $false,
    [string]$websiteName,
    [string]$webAppPoolUser,
    [string]$certRootStore = 'LocalMachine',
    [string]$logFile = $(Throw 'logFile parameter required.')
)
{
    $pathToCertsFolder = Join-Path -Path (Join-Path -Path $packageRootPath -ChildPath 'RotateConfigData') -ChildPath 'Cert'

    # Read certificate information and install certificates not previously installed.
    foreach ($certificate in $rotationInfo.Certificates)
    {
        $rotationInfoDecryptor.Decrypt($certificate)
        $secureCertificatePassword = ConvertTo-SecureString $certificate.Password -AsPlainText -Force

        $certificateFilePath = Join-Path -Path $pathToCertsFolder -ChildPath $certificate.PfxFile
        $certificateStore = $certificate.CertStore
        $certificateThumbprint = $certificate.Thumbprint

        # Check if the path to certificate is valid. If invalid, no action required.
        if (Test-Path -Path $certificateFilePath)
        {
            # Import certificate. This will only import certificates not previously installed.
            Install-Certificate -certificateFilePath $certificateFilePath `
                                -secureCertificatePassword $secureCertificatePassword `
                                -certificateStore $certificateStore `
                                -expectedThumbprint $certificateThumbprint `
                                -logFile $logFile

            # Update the website binding, if specified.
            if ($updateWebsiteSSLBinding)
            {
                # Check if any https bindings exist for the website. If any exist we need to update the SSL binding.
                Update-RetailWebsiteSSLBinding -websiteName $websiteName `
                                               -webAppPoolUser $webAppPoolUser `
                                               -certificateThumbprint $certificateThumbprint `
                                               -logFile $logFile
            }
            else
            {
                # If we aren't updating the SSL binding, we still need to update permissions for the certificate.
                GrantPermission-UserToSSLCert -certThumbprint $certificateThumbprint -certRootStore $certRootStore -certStore $certificateStore -appPoolUserName $webAppPoolUser
            }
        }
        else
        {
            $logMessage = 'No valid certificates located. Skipping certificate installation.'
            if ($updateWebsiteSSLBinding)
            {
                $logMessage = 'No valid SSL certificates located. Skipping certificate installation and website SSL binding update.'
            }

            Write-Log $logMessage -logFile $logFile
        }
    }
}

function Get-RobocopyOptions(
    [switch]$includeEmptySubFolders
)
{
    # No job headers, summary and progress. No directory listing and 360 retries with 5 sec waits.
    $robocopyOptions = "/NJS /NP /NJH /NDL /R:360 /W:5"
    
    if ($includeEmptySubFolders)
    {
        $robocopyOptions += " /E"
    }
    
    return $robocopyOptions
}

function Encrypt-WebConfigSection(
    [string]$webConfigSection = $(throw 'webConfigSection is required.'),
    $websiteId = $(throw 'websiteId is required.'),
    [string]$targetWebApplicationPath = '/',
    [string]$logFile = $(throw 'logFile is required.')
)
{
    Write-Log 'Encrypting target web.config .' $logFile
    $global:LASTEXITCODE = 0

    aspnet_regiis -pe $webConfigSection -app $targetWebApplicationPath -Site $websiteId | Tee-Object -FilePath $logFile -Append
    $capturedExitCode = $global:LASTEXITCODE

    if($capturedExitCode -eq 0)
    {
        Write-Log 'Web.config encryption completed successfully.' $logFile
    }
    else
    {
        throw "Web.config encryption failed with encryption exit code: $capturedExitCode"
    }
}

function Decrypt-WebConfigSection(
    [string]$webConfigSection = $(throw 'webConfigSection is required.'),
    $websiteId = $(throw 'websiteId is required.'),
    [string]$targetWebApplicationPath = '/',
    [string]$logFile = $(throw 'logFile is required.')
)
{
    Write-Log 'Decrypting web.config' $logFile
    $global:LASTEXITCODE = 0

    aspnet_regiis -pd $webConfigSection -app $targetWebApplicationPath -Site $websiteId | Tee-Object -FilePath $logFile -Append
    $capturedExitCode = $global:LASTEXITCODE

    if($capturedExitCode -eq 0)
    {
        Write-Log 'Web.config decryption completed successfully.' $logFile
    }
    else
    {
        throw "Web.config decryption failed with decryption exit code: $capturedExitCode"
    }
}

Export-ModuleMember -Function CheckIf-CertificateExistInTargetStore
Export-ModuleMember -Function CheckIf-UserProvidedValidCredentialData
Export-ModuleMember -Function CheckIf-UserProvidedValidSqlServerData
Export-ModuleMember -Function Copy-Files
Export-ModuleMember -Function Decrypt-WebConfigSection
Export-ModuleMember -Function Encrypt-WebConfigSection
Export-ModuleMember -Function Generate-ChannelDbConnectionString
Export-ModuleMember -Function Get-BackupFolderPath
Export-ModuleMember -Function Get-RobocopyOptions
Export-ModuleMember -Function Get-RotationInfo
Export-ModuleMember -Function Get-RotationInfoDecryptor
Export-ModuleMember -Function GetValueFor-CertificateThumbprintWithKey
Export-ModuleMember -Function GetValueFor-KeyValuePairWithKey
Export-ModuleMember -Function Install-Certificate
Export-ModuleMember -Function InstallCertificatesAndUpdateIIS
Export-ModuleMember -Function Invoke-ScriptAndRedirectOutput
Export-ModuleMember -Function Load-RotationInfoModule
Export-ModuleMember -Function Log-TimedMessage
Export-ModuleMember -Function ModifyExisting-ChannelDbConnectionString
Export-ModuleMember -Function Save-ChannelDbServicingDataToRegistry
Export-ModuleMember -Function Update-RetailWebsiteSSLBinding
Export-ModuleMember -Function Write-Log
# SIG # Begin signature block
# MIIjnwYJKoZIhvcNAQcCoIIjkDCCI4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD2VLOGoeF+QXdd
# cp5lHtpWNLW9PKkibMhbCr2/M7YnsKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdDCCFXACAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgVjNXLLgW
# WJud+Xu/SpqjPVe3tQmOnKf2SwqjdxH1N3wwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAHqiLIEY
# zkIGZ+QjcSsFh/o6nfu11LURDYoVp3PAOX5ip3K+62wTuoEO8i1CRncePS/RYNTA
# /041Mr+U09cvi03GFnqkPAqbJdobdKeLFxAUtPlT7oyLca3MjImLg3JO4GltDSNI
# jikV/hNw3qBHqxHD9VTA/GPx2+ZZNFF4TPIwECHIPKcpTEaBat0ihWY2TUSXQpCJ
# OIWWnG49zJtDo44l2D0aoUimfqa9+16n7aUBUGcLqwc/W3sSU1eefNxZEAWmgfwx
# nxNCOmpn8rSmXItPKA1HxiFdTCWUr6Jl5NuByPq8dE7yEkmr+HdYC0MaKAyozozx
# SxABqb0ebxb6fBihghLkMIIS4AYKKwYBBAGCNwMDATGCEtAwghLMBgkqhkiG9w0B
# BwKgghK9MIISuQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUAYLKoZIhvcNAQkQAQSg
# ggE/BIIBOzCCATcCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQggb0C
# v2AgjWS/yEcnSHUDyY2yG2htd8874xQzo6PeXnkCBl1gildCThgSMjAxOTA4Mjcw
# NzIzMzYuMDZaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjwwggTxMIID2aAD
# AgECAhMzAAAA2aqWClHLm0vmAAAAAADZMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjY1MloXDTE5MTEyMzIw
# MjY1MlowgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAri6L0qOzc9ejG5LAsST1gZ8Ci8hU6n3tKzY/9im1DB3gtkgNNfWS6vzk9shx
# 71bw7/ACaNT6n28qJpeTLvhZ8u2HuVfO0fPkQd5OpsYEg6p7n7N8NhECpWU/hxHr
# 8aspFIDFSIqstIriZB+XVsJMoQ9OhNMrf0HijU+orHd70OtbjfOtwpycRnQhwQ7U
# Vem6GDIdxaZBjTYppNxhDFd11L6nlFs+CaThCw95C+GItT0Zo0kWdeimzOVfAoOU
# 2+K+zG/HxuBUJeSIza6EIOeDYKbg+KPb6NSOXdsJl3goOY6SXOAzZH9Gm6GHA6er
# NQ3Jv1fqYUw9EIPkmRinS63EfQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFFDrnUZm
# p9yfHafON2hkd6UUG449MB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAJ5oN6za
# 7MTTpAxYUC9hSlE1yJx940lEmJ/XPj3fidCS6EMrvxnBEJIYqmShwg02XT/4vpsG
# N9b4JjQFnYXP+UrOTD09Mwli7KvRQvUP4oCSU9AqZ6PMnIMF4s1ZCui824oUQ7GF
# FtNej33d1QMRDO24v27A2O/OV+BA4q8fdZsSNvQZkwPKwfeQVH2GtxhFPRmJf/eF
# SBbcXcdvFE2kcD53Z9NvP0Sntpuwm2TNDYE5fz9YHUtXTYEQTH9wuEdxEyKy/cgM
# X7RAGA1RVbA+COcUkQwBYqgubNnpYpp30yHJdEoBIfnSzVEZD7iWsQ0Vg8d0VJOk
# eqaq+zQMvJemgYIwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLOMIICNwIBATCB+KGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAL/8St6JpAyHqmttBvN/
# n0u6SS2hoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDhDv1OMCIYDzIwMTkwODI3MDg1MjMwWhgPMjAxOTA4Mjgw
# ODUyMzBaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOEO/U4CAQAwCgIBAAICG+4C
# Af8wBwIBAAICEX8wCgIFAOEQTs4CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQCgZruPAhl5h/Ip+nwL62ivxx24BHPPrdIU3LzchW/9G/kf/3d0mQwElXxPUhEz
# FGE/fVGC96ud2sOG4dU+dQ40V3+wNw8krgYBBREfN2K+PreHis/Xj0a4YKb1LzzJ
# Xdyndh1+fuHma53f9HZ2ZlJAP/oxfljvmq+NJcBrsAdddzGCAw0wggMJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA2aqWClHLm0vmAAAA
# AADZMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIMLxmQumCcfVzObRwz/MUjvbk2hkqwcNirvKuSUf
# OI7nMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg0iyJ8h8orY9BN7/KlKbL
# E+gS8CIKCOeTRYhoLQ7ak3EwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAANmqlgpRy5tL5gAAAAAA2TAiBCCYBgGioIJo6QIhksn4ghhi
# wnAln1AUrzdV6bU/gH8//DANBgkqhkiG9w0BAQsFAASCAQA9KIkkXUdoyhQSRK8h
# 8A2Xz2iXgoeqxSMQw/HND2/KSp1WgVU3j5sz5J7uGIMeSC69XkW/8ArEPuwaZM10
# PQos60Xe/WHxYi/PUTl/7eOMC1Kwom4+p2tK6oRyQXEqo6s2yFrukNKtzV/BAjlt
# 15l7D0TtHi0d8Zb/yvrauKPOMQCiwcRzMXbEtQQDIsvjLvH4tWhQ1m7O9XfbrrLF
# yCT2AamhjA7AsHKWeOCeqRoX7mWiS8KZHDEZkQt0FV6287wzM/XrT07zYNnchCWx
# G4d9axzyOd3NLRKIzR+T14kKww8g82mU+1Y0/x6Y7JXC9saXYnfqTB7DARvP8VbX
# pgz+
# SIG # End signature block
