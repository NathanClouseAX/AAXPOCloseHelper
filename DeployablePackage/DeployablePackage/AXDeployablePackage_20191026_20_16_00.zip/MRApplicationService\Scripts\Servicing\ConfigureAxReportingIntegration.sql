-----------------------------
PRINT 'Grant permissions to ReportingIntegrationUser role'
------------------------------
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'ReportingIntegrationUser' and [type] = 'R')
BEGIN
	CREATE ROLE [ReportingIntegrationUser] AUTHORIZATION [dbo]
END

IF SCHEMA_ID('ReportingIntegration') IS NULL EXECUTE('CREATE SCHEMA [ReportingIntegration] AUTHORIZATION [dbo]')
GRANT CREATE TABLE TO [ReportingIntegrationUser]
GRANT CREATE VIEW TO [ReportingIntegrationUser]
GRANT ALTER        ON SCHEMA::[ReportingIntegration] TO [ReportingIntegrationUser]
GRANT DELETE       ON SCHEMA::[ReportingIntegration] TO [ReportingIntegrationUser]
GRANT INSERT       ON SCHEMA::[ReportingIntegration] TO [ReportingIntegrationUser]
GRANT SELECT       ON SCHEMA::[ReportingIntegration] TO [ReportingIntegrationUser]
GRANT UPDATE       ON SCHEMA::[ReportingIntegration] TO [ReportingIntegrationUser]
GRANT DELETE       ON SCHEMA::[dbo] TO [ReportingIntegrationUser]
GRANT INSERT       ON SCHEMA::[dbo] TO [ReportingIntegrationUser]
GRANT SELECT       ON SCHEMA::[dbo] TO [ReportingIntegrationUser]
GRANT UPDATE       ON SCHEMA::[dbo] TO [ReportingIntegrationUser]
GRANT ALTER        ON SCHEMA::[dbo] TO [ReportingIntegrationUser]
GRANT REFERENCES   ON SCHEMA::[dbo] TO [ReportingIntegrationUser]
GRANT VIEW CHANGE TRACKING ON SCHEMA::[dbo] TO [ReportingIntegrationUser]

-----------------------------
PRINT 'Add axmrruntimeuser user to ReportingIntegrationUser role'
------------------------------
ALTER ROLE[ReportingIntegrationUser] ADD MEMBER [axmrruntimeuser]