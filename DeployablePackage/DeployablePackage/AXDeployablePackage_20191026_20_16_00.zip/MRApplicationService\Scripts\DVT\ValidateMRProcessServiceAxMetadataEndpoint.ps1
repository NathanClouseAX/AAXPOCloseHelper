<#
.Synopsis
	DVT for checking if AX metadata endpoint is reachable. Pulls AOS server URI from AX adapter settings
#>
[CmdletBinding()]
Param
(
	# DVT log file path.
	[string]
	$Log
)

$scriptName = (Get-Item $PSCommandPath).BaseName
. "$PSScriptRoot\Helpers\ScriptSetup.ps1"
Set-LogPath -FullLogPath $Log
Write-EnvironmentDataToLog
. "$PSScriptRoot\Helpers\DVTScriptSetup.ps1"
Initialize-DVTScript
. "$PSScriptRoot\Helpers\EndpointHelpers.ps1"
. "$PSScriptRoot\Helpers\SqlHelpers.ps1"

<#
.Synopsis
	Get a given setting from the settings XML
#>
function Get-SettingsValue
{
	[CmdletBinding()]
	Param
	(
		# Adapter settings
		[ValidateNotNull()]
		$Settings,

		# Setting name
		[string]
		[ValidateNotNullOrEmpty()]
		$SettingName
	)

	Write-LogMessage -Message "Reading value for setting '$SettingName'"
	$settingValue = $Settings | Where-Object { $_.FieldDefinition.Name -eq $SettingName } | Select-Object -First 1 -Property 'Value'
	if(!$settingValue -or !$settingValue.Value)
	{
		throw "No $SettingName found in adapter settings"
	}

	return $settingValue.Value
}

<#
.Synopsis
	Gets the AX7ClientSettings object from the database whose connection string is stored in the given path
#>
function Get-AX7ClientSettings
{
	[CmdletBinding()]
	Param
	(
		# Path to connections file
		[string]
		[ValidateNotNullOrEmpty()]
		$Path
	)

	Write-LogMessage -Message 'Getting AX client settings'
	Write-LogMessage -Message "Reading connection string from '$Path' file."
	$sqlConnectionString = Get-DecryptedSqlConnectionString -Path $Path
	Write-LogMessage -Message 'Querying database for AX adapter settings'
	[xml]$adapterSettings = Invoke-SqlQuery -ConnectionString $sqlConnectionString -Query 'SELECT TOP 1 [Settings] from [Connector].[MapCategoryAdapterSettings] WHERE [AdapterId] = ''E3E10D70-FDAB-480C-952E-8397524F9236''' -ResultReader (Get-ExecuteScalarReader)
	if(!$adapterSettings)
	{
		throw "No AX adapter settings in database '$($sqlConnection.InitialCatalog)'"
	}

	$settings = $adapterSettings.SettingsCollection.ArrayOfSettingsValue.SettingsValue
	if(!$settings)
	{
		throw "No settings values found in database '$($sqlConnection.InitialCatalog)'"
	}

	$aosServer = Get-SettingsValue -Settings $settings -SettingName 'AOSServer'
	$certificateUserName = Get-SettingsValue -Settings $settings -SettingName 'CertUserName'
	$providerName = Get-SettingsValue -Settings $settings -SettingName 'ProviderName'
	$federationRealm = Get-SettingsValue -Settings $settings -SettingName 'FederationRealm'
	$certificateThumbprint = Get-SettingsValue -Settings $settings -SettingName 'CertThumbprint'
	$tokenIssuer = Get-SettingsValue -Settings $settings -SettingName 'TokenIssuer'
	$serviceName = [Microsoft.Dynamics.Performance.DataProvider.AxClient.AosServiceNames]::MetadataService
	Write-LogMessage -Message 'Creating AX7ClientSettings object'
	$clientSettings = New-Object Microsoft.Dynamics.Performance.DataProvider.AXClient.AX7ClientSettings -ArgumentList @($aosServer, $serviceName, $certificateUserName, $providerName, $federationRealm, $certificateThumbprint, $tokenIssuer)
	return $clientSettings
}

<#
.Synopsis
	Confirms we can communicate with the metadata service given valid client settings
#>
function Confirm-MetadataServiceValidInputs
{
	[CmdletBinding()]
	Param
	(
		# Client settings to connect with
		[ValidateNotNull()]
		$AX7ClientSettings
	)

	$result = New-TestResult
	$result.TestName = "Confirm-MetadataService.ValidInputs"
	$tableToTest = 'dirpartytable'
	
	$exception = $null
	$retryAction = {			
		Write-LogMessage -Message 'Validating authentication settings with metadata service'
		try
		{	
			$client = [Microsoft.Dynamics.Performance.DataProvider.AXClient.MetadataServices.AxMetadataServiceClient]::CreateClient($AX7ClientSettings)
			$metadata = $client.GetTableMetadataByName($tableToTest)
			return $true
		}
		catch
		{
			Write-LogMessage -Message ($_.ToString())
			Set-Variable -Name exception -Value $_ -Scope 2
			return $false
		}
	}

	# Retry every five seconds up to 12 times for a maximum of one minute
	$result.TestResult = Invoke-RetryLoop -RetryCount 12 -DelayInSeconds 5 -Action $retryAction
	if (!$result.TestResult)
	{
		$errorDetail = Write-ErrorDetail -ErrorThrown $exception -WriteToConsole -PassThru
		$result.AddOutput($errorDetail)
	}

	return $result
}

<#
.Synopsis
	Inserts or updates FRServiceUser record in the AX database.
#>
function InsertOrUpdate-FRServiceUser
{
	[CmdletBinding()]
	Param
	(
		# Connection String to database
		[ValidateNotNull()]
		$connectionString
	)

    $query = "update userinfo set ENABLE = 0 where ID = 'FRServiceUser'
					MERGE [dbo].[USERINFO] AS target
					USING
					(
						VALUES
						( 
							'FRServiceUser', 
							'FRServiceUser', 
							1, 
							'https://mintedtoken.dynamics.com', 
							'FRServiceUser@dynamics.com', 
							1, 
							'',
							'S-1-19-1241925437-3719476898-4060767950-17831512-2104045269-3825046075-1325424976-928167439-1769986175-660289321' 
						)
					) 
					AS source
					(
						[ID], 
						[NAME], 
						[ENABLE], 
						[NETWORKDOMAIN], 
						[NETWORKALIAS], 
						[DEFAULTPARTITION], 
						[COMPANY],
						[SID]
					)
					ON 
						target.[ID] = source.[ID]
					WHEN 
						MATCHED
							THEN 
								UPDATE 
								SET 
									target.[NAME] = source.[NAME],
									target.[ENABLE] = source.[ENABLE], 
									target.[NETWORKDOMAIN] = source.[NETWORKDOMAIN], 
									target.[NETWORKALIAS] = source.[NETWORKALIAS], 
									target.[DEFAULTPARTITION] = source.[DEFAULTPARTITION], 
									target.[COMPANY] = source.[COMPANY],
									target.[SID] = source.[SID]
					WHEN 
						NOT MATCHED
							THEN
								INSERT
								(
									[ID], 
									[NAME], 
									[ENABLE], 
									[NETWORKDOMAIN], 
									[NETWORKALIAS], 
									[DEFAULTPARTITION],
									[COMPANY],
									[SID]
								)
								VALUES
								(
									source.[ID], 
									source.[NAME], 
									source.[ENABLE], 
									source.[NETWORKDOMAIN], 
									source.[NETWORKALIAS], 
									source.[DEFAULTPARTITION], 
									source.[COMPANY],
									source.[SID] 
								);

					-- ISMICROSOFTACCOUNT was added in newer platform builds make sure it exists before attempting to set it.
					IF EXISTS
					(
						SELECT 1
						FROM sys.all_columns AS c
							 JOIN sys.tables AS t ON c.object_id = t.object_id
							 JOIN sys.schemas AS s ON t.schema_id = s.schema_id
						WHERE s.name = 'dbo'
							  AND t.name = 'USERINFO'
							  AND c.name = 'ISMICROSOFTACCOUNT'
					)
						BEGIN
							EXEC('
							UPDATE [dbo].[USERINFO]
							SET ISMICROSOFTACCOUNT = 1
							WHERE [ID] = ''FRServiceUser''
								  AND [ISMICROSOFTACCOUNT] != 1; -- only update if the ISMICROSOFTACCOUNT is not already 1.
							')
						END;"

    Invoke-SQLQuery -ConnectionStr $connectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
}

<#
.Synopsis
	Confirms the minted token user settings are correct in the AX database.
#>
function Confirm-MetadataServiceMintedTokenUser
{
	[CmdletBinding()]
	Param
	(	
		# Database name
		[string]
		[ValidateNotNullOrEmpty()]
		$DatabaseName,

		# SQL server instance name
		[string]
		[ValidateNotNullOrEmpty()]
		$ServerInstance,

		# SQL User Name
		[string]
		$UserName,

		# SQL User Password
		[string]
		$Password
	)

	$result = New-TestResult
	$result.TestName = "Confirm-MetadataService.MintedTokenUser"
	$result.TestResult = $false
	Write-LogMessage -Message 'Validating minted token user settings for communication with the metadata service.'
	
	try
	{	
		$credential = New-Object System.Management.Automation.PSCredential($UserName, ($Password | ConvertTo-SecureString))
		$connectionString = Get-ConnectionString -Server $ServerInstance -Database $DatabaseName -Credential $credential
		$query = "DECLARE @needsUpdate BIT= 0;
                    IF EXISTS
                    (
	                    SELECT 1
	                    FROM dbo.USERINFO
	                    WHERE ID = 'FRServiceUser'
                    )
	                    BEGIN
		                    -- FRServiceUser exists verifiy the fields are set as expected.
		                    SELECT @needsUpdate = 1
		                    FROM dbo.USERINFO
		                    WHERE ID = 'FRServiceUser'
				                    AND (NAME != 'FRServiceUser'
					                    OR ENABLE != 1
					                    OR NETWORKDOMAIN != 'https://mintedtoken.dynamics.com'
					                    OR NETWORKALIAS != 'FRServiceUser@dynamics.com'
					                    OR DEFAULTPARTITION != 1
										OR COMPANY != ''
					                    OR SID != 'S-1-19-1241925437-3719476898-4060767950-17831512-2104045269-3825046075-1325424976-928167439-1769986175-660289321');

		                    -- ISMICROSOFTACCOUNT was added in newer platform builds make sure it exists before verifying it's value.
		                    IF EXISTS
		                    (
			                    SELECT 1
			                    FROM sys.all_columns AS c
					                    JOIN sys.tables AS t ON c.object_id = t.object_id
					                    JOIN sys.schemas AS s ON t.schema_id = s.schema_id
			                    WHERE s.name = 'dbo'
					                    AND t.name = 'USERINFO'
					                    AND c.name = 'ISMICROSOFTACCOUNT'
		                    )
		                    BEGIN
                                EXEC [sp_executesql] 
									 N'SELECT @needsUpdate = 1
									   FROM [dbo].[USERINFO]
									   WHERE [ID] = ''FRServiceUser''
									 	    AND [ISMICROSOFTACCOUNT] != 1;', 
									 N'@needsUpdate BIT output', 
									 @needsUpdate OUTPUT;
		                    END;
	                    END;
                    ELSE
	                    BEGIN
	                    -- FRServiceUser record does not exist and needs to be added.
		                    SET @needsUpdate = 1;
	                    END;
						
                    SELECT 1 AS COLUMNANME 
                    WHERE @needsUpdate = 1;"

		$queryResult = Invoke-SQLQuery -ConnectionStr $connectionString -Query $query -ResultReader (Get-ExecuteScalarReader)
		if ($queryResult -eq 1)
		{
			$result.AddOutput("There is something wrong with the user 'FRServiceUser'. Executing InsertOrUpdate sql command.")
            InsertOrUpdate-FRServiceUser -connectionString $connectionString
        }

		$result.TestResult = $true
	}
	catch
	{
		$errorDetail = Write-ErrorDetail -ErrorThrown $_ -WriteToConsole -PassThru
		$result.AddOutput($errorDetail)
	}

	return $result
}

try
{
	$filePaths = Get-MRFilePaths
	Add-Type -Path (Join-Path -Path $filePaths.Server -ChildPath 'Connector\Microsoft.Dynamics.Performance.DataProvider.AXClient.dll')
	$clientSettings = Get-AX7ClientSettings -Path $filePaths.ServicesConnectionsConfig
	Write-LogMessage -Message 'Testing AX Metadata endpoint'
	$axMetadataEndpointAvailable = Confirm-EndpointAvailable -EndpointName "AxMetadataServiceEndpoint" -EndpointUrl "$($clientSettings.AosServer)/services/MetadataService"
	$resultsCollection.Add($axMetadataEndpointAvailable)
	
	$axDatabaseServer = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.DbServer'
	$axDatabaseName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.Database'
	$axUserName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.SqlUser'
	$axPassword = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.AX.DataAccess.SqlPwd'
	$mintedTokenUser = Confirm-MetadataServiceMintedTokenUser -DatabaseName $axDatabaseName -ServerInstance $axDatabaseServer -UserName $axUserName -Password $axPassword
	$resultsCollection.Add($mintedTokenUser)

	Write-LogMessage -Message 'Testing authentication with AX Metadata endpoint'
	$axMetadataEndpointAuthentication = Confirm-MetadataServiceValidInputs -AX7ClientSettings $clientSettings
	$resultsCollection.Add($axMetadataEndpointAuthentication)
}
catch
{ 
	Add-ExceptionFailureToTestRun -Exception $_ -TestName $scriptName -AddToRun $resultsCollection
} 

. "$PSScriptRoot\Helpers\DVTResultHandling.ps1"
# SIG # Begin signature block
# MIIjnwYJKoZIhvcNAQcCoIIjkDCCI4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBqZUTXHaKYWLLc
# 6kZqjyDKbEtXbP1nuuHHuJFxgQw+a6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdDCCFXACAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgvya6aS2T
# lJCoUix8LEg9Q0bgWVGhTq1SIdY18DqjKfEwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAD5hi0jp
# lnfPhqjDUitv+djOEwC+kCagjBfOmucLqatVXoVxPUr0HhnGo1MvkY9wjUaVc7Bl
# NB8Ur71pTG55tfS7E+VmLg6H0vBqVgYdKzHyFmquVAOZTS+rnhvK8aM8CnxRSW5a
# j1p2P/w5mC7qFqG/sWtkiXlaYvVYZgQz7KTM4gs+Dr/mvY3kAwHh42hEWW1D95Dr
# q0Z3lKyTpETILUlos12bS0CpTj5DcgL7R2v9DXie5EiPZva5R2Z9Plm17WSzN1vL
# D+GtdvpTCEvlkBnrSCJkTdiw5NrNQK2G6SKLS7/YFi/bPQ5Mm9gic4xPztn4QlOo
# 4VsyQuk5f92e5F2hghLkMIIS4AYKKwYBBAGCNwMDATGCEtAwghLMBgkqhkiG9w0B
# BwKgghK9MIISuQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUAYLKoZIhvcNAQkQAQSg
# ggE/BIIBOzCCATcCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgDurF
# sMSOjUMElBJFTbWDFHRqeXkdl4PJ+Pehc29rVkYCBl1gK6EMfBgSMjAxOTA4Mjcw
# NzI0NDYuNjVaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowODQyLTRCRTYtQzI5QTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjwwggTxMIID2aAD
# AgECAhMzAAAA2BrkzD96EfrhAAAAAADYMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjY1MVoXDTE5MTEyMzIw
# MjY1MVowgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAlB4w5Ida9bBouPMwkk1SUi11Q+YxVF4kgK7imoaAQHlxBYN17XS/eyXsE9rx
# Ji3hhD0nXOZ6K5evnumaIVY//PMCkfsNJfwFxG24NoDPIO12e1KBgQWI930yWzS5
# PQaACOENPgsgi7CRFDcb1wSZF9CoXl69yKbaQ2aGoAZZP091GhR5kznxumHHuc0S
# eSx0MrxNDvUZyQyTDeQ6Eef8zGV+wNhRdAx13+AvwFkED2B0DldX5jbn8QZUsA+B
# hWzrtUfHS/kszVM3u+x6U6oPuni01ErBzXla+GCs6zfNb5gsemiLuYrlsHFFscMe
# 04G6hq9nXYP1ePVvIrvVLDL1QwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFJ+2Vkse
# 7hTV34p2epqDGueQ42bkMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAA5ScHbe
# yD8gtTS3uwGc3vDaOzJ3fOA+UjB38YkaS3jmF8/m4GfiP2/AZ+mwoNl6Eu1Cm39G
# nqLlKrv03JA7Dguvn5KNLltS6TkTlKQr3PVkxr9FV4/6CQLl2USU0d6nmRzoImGd
# KgsiUoTsiCJiSm+N2IM+LdJPyQNKuRPs9lvw9pyg1Vfs05yvEp0TkOeVinqCavaQ
# XCY3dZ3+x72HdTJchYRdzsHQjxazPxbbHCzuhilQYr16XtNyvSNirKICYdu7Ail3
# dO0zdYalDlTOeLFSW2aHz5yRMIoPjToWEkYo4UuE/30WtVXC0Nq8ITTMkHPVPvkP
# lt/iNivGg5tJTrEwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLOMIICNwIBATCB+KGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046MDg0Mi00QkU2LUMyOUExJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAGUxwd0RXh2Q7I0ookkV
# CFlgKyKBoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDhD0dYMCIYDzIwMTkwODI3MTQwODI0WhgPMjAxOTA4Mjgx
# NDA4MjRaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOEPR1gCAQAwCgIBAAICJs4C
# Af8wBwIBAAICEW0wCgIFAOEQmNgCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQAqA7ebCMI5nOIIwh32yvGUH2GS3wyi1gZdllKe3zL+fDjIcb/LtmfTemVrwCAD
# AAmuxf2ks3UB2UnMmCBaUMde0N13p0joMHRM8mdVsbJw7OTOCDvXyHRnzdYgTjkz
# OgTCB9UCKR95+ZoBEHJjkB7MF7wVBVQpPdS/T0ni2VOWWjGCAw0wggMJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA2BrkzD96EfrhAAAA
# AADYMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIE4ub9OcyLv9M6ylgiBxzASAeW80Ezxt0zQVuK6R
# OIg5MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgczudx3hc6PN2Kf/vhJWq
# PSlA0W8KBP8ga8wTn0Eu2C0wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAANga5Mw/ehH64QAAAAAA2DAiBCB8JDSvFmeLP1Ff6OzGFYr1
# XfMpNoMfk5HMNCC82AUFUjANBgkqhkiG9w0BAQsFAASCAQAjQt/P6PBUB/04rwIt
# 4T/UTwib6g1bWSUPUTG+v7LHS9/S4z34U7s640zcmayDDpOshfbaT0OBGX+lJCJy
# ZUIJwK4+xN/szQWaAeWn6fWFYBGGruySGn9ZG4KiU4Q01cHVP2QSGf+Ibs3r67Id
# Xd0NaeJrArLKWasfrghlMnpKfwUcwa8zIKaQ7Zf4tDsZmGxYapGsR+uwkCtVMTnv
# Yb+a9VoVXtk4WzlR34Oor13fjuLTiMTDkl5yV0bdjyqmAOM0f5EcumvaGCA5wPu8
# wjkUTOYgtmsgRJT0CCw8/HDXnduvBlncuhExyxXtWB/ZWoHNGgoGwwcIArOCkEkS
# wU8/
# SIG # End signature block
