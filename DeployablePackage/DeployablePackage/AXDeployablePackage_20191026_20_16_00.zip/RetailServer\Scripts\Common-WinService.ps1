<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

# Make script to interrupt if exception is thrown.
$ErrorActionPreference = "Stop"

$ScriptDir = split-path -parent $MyInvocation.MyCommand.Path;
. "$ScriptDir\Common-Configuration.ps1"

function Get-WindowsServiceConfigFromXmlNode($node)
{
    [hashtable]$ht = @{}
    $ht.Name = Get-XmlAttributeValue $node "Name"
    $ht.DisplayName = Get-XmlAttributeValue $node "DisplayName"

    $ht.LogOnUser = Get-XmlAttributeValue $node "ServiceUser"
    $ht.ExecutionFileName = Get-XmlAttributeValue $node "ServiceExecutableFileName"

    $ht.SourcePath = Get-XmlAttributeValue $node "SourcePath"
    $ht.PhysicalPath = Get-XmlAttributeValue $node "PhysicalPath"

    return $ht;
}

function Check-CurrentUserIsAdmin 
{
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()  
    $principal = new-object System.Security.Principal.WindowsPrincipal($identity)  
    $admin = [System.Security.Principal.WindowsBuiltInRole]::Administrator  
    $principal.IsInRole($admin)  
} 

function ConvertFrom-SecureToPlain(
    [System.Security.SecureString] $SecureString = $(Throw 'SecureString parameter required'))
{
    $strPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
    $plainTextString = [Runtime.InteropServices.Marshal]::PtrToStringAuto($strPointer) 
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($strPointer)
    $plainTextString    
}

function Grant-UserLogonAsServiceRights(
    [string]$userAccount = $(Throw 'userAccount parameter required'))
{
    # In case if User account is in form ".\account", convert it to "ComputerName\account". Otherwise call to .dll method fails
    if($userAccount -like ".\*")
    {
        $userAccount = $env:COMPUTERNAME + "\" + ($userAccount.split("\\")[1])
    }

    try
    {
        # Use script scope of MyInvocation because $MyInvocation.MyCommand.Path is not defined in function.
        $ScriptDir = split-path -parent $script:MyInvocation.MyCommand.Path;
        $dllPath = Join-Path $ScriptDir 'Microsoft.Dynamics.Retail.Deployment.UserAccountRightsManager.dll'
        Log-ActionItem "Trying to load [$dllPath]"

        # Using LoadFile rather than LoadFrom as it has no dependencies on Fusion.
        [System.Reflection.Assembly]::LoadFile($dllPath)
        Log-ActionResult "Complete"
    }
    catch
    {
        Log-ActionResult 'Failed'
        Log-Error $_
        Throw-Error "Failed To Load [$dllPath]"
    }

    try
    {
        Log-ActionItem "Granting log on as service rights to user account [$userAccount]"

        # Works fine if user already has service logon rights.
        $userManagerObject = New-Object -TypeName Microsoft.Dynamics.Retail.Deployment.UserAccountRightsManager.UserManager
        $userManagerObject.AddLogOnAsServiceRightToAccount($userAccount)
        Log-ActionResult 'Success'
    }
    catch
    {
        Log-ActionResult 'Failed'
        Throw-Error "Failed to grant log on as service permission to [$userAccount]"
    }
}

function Install-WindowsService(
    $WinServiceConfig = $(Throw 'WinServiceConfig parameter required'),
    [System.Management.Automation.PSCredential[]]$Credentials = $(Throw 'Credentials parameter required')
)
{
    $OriginalUserName = $WinServiceConfig.LogOnUser; Validate-NotNull $OriginalUserName "UserName"
    $UserName = Convert-UserNameToADFormat $OriginalUserName
    $ServiceBinarySourceFolder = $WinServiceConfig.SourcePath; Validate-NotNull $ServiceBinarySourceFolder "ServiceBinarySourceFolder"
    $ServiceExeName = $WinServiceConfig.ExecutionFileName; Validate-NotNull $ServiceExeName "ServiceExeName"
    $ServiceName = $WinServiceConfig.Name; Validate-NotNull $ServiceName "ServiceName"
    $DisplayName = $WinServiceConfig.DisplayName; Validate-NotNull $DisplayName "DisplayName"
    $ServiceInstallFolder = $WinServiceConfig.PhysicalPath; Validate-NotNull $ServiceInstallFolder "ServiceInstallFolder"

    Grant-UserLogonAsServiceRights $UserName

    Write-Host "------------------------------------------"
    Write-Host " Installing Windows Service [$ServiceName]"
    Write-Host "------------------------------------------"

    $ExePath = Join-Path -Path $ServiceInstallFolder -ChildPath $ServiceExeName 
    
    Log-ActionItem "Looking up credential for user with name [$OriginalUserName]"
    $foundCredential = $Credentials | Where {$_.Username -like $OriginalUserName}

    $targetCredentials = $null
    $Password = $null
    if ($foundCredential -ne $null)
    {
        $targetCredentials = New-Object System.Management.Automation.PSCredential -ArgumentList $UserName, $foundCredential.Password
        Log-ActionResult "Complete"

        Log-ActionItem "Decrypting password for [$UserName]"
        $Password = $targetCredentials.GetNetworkCredential().Password
        Log-ActionResult "Complete"
    }
        
    Log-ActionItem "Check if service [$ServiceName] already exists"
    if (Get-Service $ServiceName -ErrorAction SilentlyContinue)
    {
        Log-ActionResult "Yes"
        
        Stop-WindowsService $ServiceName
        Copy-WinServiceBinaries $ServiceInstallFolder $ServiceBinarySourceFolder

        Log-ActionItem "Getting details for $ServiceName"
        $service = Get-WmiObject Win32_Service -filter "name='$ServiceName'"
        $currentServiceUser = $service.StartName
        $currentServiceUser = Convert-UserNameToADFormat $currentServiceUser
        Log-ActionResult "configured user: $currentServiceUser"
        
        Log-ActionItem "Change service attributes"
        if ($foundCredential -eq $null)
        {
            if ($currentServiceUser.ToLower() -eq $UserName.ToLower())
            {
                $Password = $null
                Log-ActionItem "Service $ServiceName is currently configured to be run as user $currentServiceUser (same as the one configured for this installation). No password was provided for that user, no service user changes will occurr."
            }
            else
            {
                Throw-Error "Service $ServiceName is configured to run as $currentServiceUser but this installation was requested to change it to $UserName. No password was provided for $UserName. Installation cannot proceed. Please retry providing the password for the user $UserName"
            }
        }
        
        $service.Change($DisplayName,$ExePath,$null,$null,$null,$null,$UserName,$Password,$null,$null,$null)
        Log-ActionResult "Complete"
    }
    else 
    {
        if ($foundCredential -eq $null)
        {
            Throw-Error "Service $ServiceName does not exist and was configured to run as user $OriginalUserName. We were about to create it but no credentials were provided for user with name $OriginalUserName. The script cannot continue."
        }
    
        Log-ActionResult "No"
        Copy-WinServiceBinaries "$ServiceInstallFolder" "$ServiceBinarySourceFolder"

        # Creating windows service using all provided parameters
        Log-ActionItem "Installing service"        
        New-Service -name $ServiceName -binaryPathName $ExePath -displayName $DisplayName -startupType Automatic -description $DisplayName -credential $targetCredentials  
        Log-ActionResult "Complete"
    } 

    Write-Host "------------------------------------------"
    Write-Host "Successfully installed windows service [$ServiceName]"
    Write-Host "------------------------------------------"      
}

function Copy-WinServiceBinaries(
    [string]$ServiceInstallFolder = $(Throw 'ServiceInstallFolder parameter required'),
    [string]$ServiceBinarySourceFolder = $(Throw 'ServiceBinarySourceFolder parameter required')
)
{
   Log-ActionItem "Check if service install folder and binary source folder are the same."
   if(-not (Test-IfPathsEqual $ServiceBinarySourceFolder $ServiceInstallFolder))
   {
        Log-ActionResult "No"
        Log-ActionItem "Check if service path $ServiceInstallFolder exists"
        if (!(Test-Path $ServiceInstallFolder -PathType Container))
        {
            Log-ActionResult "No"
            Log-ActionItem "Create service path $ServiceInstallFolder"
            New-Item "$ServiceInstallFolder" -type directory -force | out-null
            Log-ActionResult "Complete"
        }
        else
        {
           Log-ActionResult "Yes" 
        }

        # Create a copy of the binaries and the config file 
        $serviceBinaryAllFiles = Join-Path -Path $ServiceBinarySourceFolder -ChildPath "\*"
        $copyServiceBinaries = {
                    Log-ActionItem "Copy files from [$ServiceBinarySourceFolder] to [$ServiceInstallFolder]."
                    Copy-Item "$serviceBinaryAllFiles" "$ServiceInstallFolder" -Recurse -Force
                    Log-ActionResult "Copied successfully."
        }

        try
        {
            Perform-RetryOnDelegate $copyServiceBinaries
        }
        catch
        {
            Throw-Error "Failed to copy files from [$ServiceBinarySourceFolder] to [$ServiceInstallFolder]."
        }  
    }
    else
    {
        Log-ActionResult "Yes"
    }

    Log-ActionResult "Complete"
}

function Start-WindowsService(
    [string]$ServiceName = $(Throw 'ServiceName parameter required')
)
{  
    if (Get-Service $ServiceName -ErrorAction SilentlyContinue)
    {
        Log-ActionItem "Start service $ServiceName"
        #Set windows service start mode to Automatic(Delayed)
        & "$env:SystemRoot\System32\sc.exe" config $ServiceName start= 'delayed-auto'
        Start-Service $serviceName        
        # The service will not immediately start.  We need to query its state and only if we get a valid state continue.
        # If it does not start for 60 seconds, fail the script.
        [string]$serviceState = $null
        $loopBeginTime = [Datetime]::Now
        do
        {
            try
            {
                $scService = Get-Service -Name $ServiceName
                $serviceState = $scService.Status
            } 
            catch
            {
                if(([Datetime]::Now) -gt ($loopBeginTime + [Timespan]::FromSeconds(60)))
                {
                    Throw-Error "Service [$ServiceName] could not be started in a timely manner."
                }
                Log-ActionItem "Service [$ServiceName] is not ready for use. Sleeping..."
                Start-Sleep -Second 1 
            }
        }
        until($serviceState -eq "Running")
        
        Log-ActionResult "Service started"  
    }  
}

function Stop-WindowsService(
    [string]$ServiceName = $(Throw 'ServiceName parameter required')
)
{  
    if (Get-Service $ServiceName -ErrorAction SilentlyContinue)
    {
        Log-ActionItem "Stop service $ServiceName"        
        Stop-Service -Name $serviceName -Force #Stop service, ignore dependencies    
        # The service will not immediately stop.  We need to query its state and only if we get a valid state continue.
        # If it does not stop for 60 seconds, fail the script.
        [string]$serviceState = $null
        $loopBeginTime = [Datetime]::Now
        do
        {
            try
            {
                $scService = Get-Service -Name $ServiceName
                $serviceState = $scService.Status
            } 
            catch
            {
                if(([Datetime]::Now) -gt ($loopBeginTime + [Timespan]::FromSeconds(60)))
                {
                    Throw-Error "Service [$ServiceName] could not be stopped in a timely manner."
                }
                Log-ActionItem "Service [$ServiceName] is not ready for use. Sleeping..."
                Start-Sleep -Second 1 
            }
        }
        until($serviceState -eq "Stopped")
        Log-ActionResult "Service stopped"  
    }     
}

function Uninstall-WindowsService(
    $WinServiceConfig = $(Throw 'WinServiceConfig parameter required'))
{
    $ServiceName = $WinServiceConfig.Name; Validate-NotNull $ServiceName "ServiceName"
    Write-Host "------------------------------------------"
    Write-Host " Uninstalling Windows Service [$ServiceName]"
    Write-Host "------------------------------------------"

    try
    {
        Remove-WindowsServiceSafe -ServiceName $ServiceName
        Remove-WinServiceBinaries -WinServiceConfig $WinServiceConfig
    }
    catch
    {
        Log-Exception $_
        Throw-Error "Failed to uninstall windows service [$ServiceName]"
    }
    Write-Host "------------------------------------------"
    Write-Host "Successfully uninstalled windows service [$ServiceName]"
    Write-Host "------------------------------------------"
}

function Remove-WinServiceBinaries(
    $WinServiceConfig = $(Throw 'WinServiceConfig parameter required'))
{
    $ServiceInstallFolder = $WinServiceConfig.PhysicalPath; Validate-NotNull $ServiceInstallFolder "ServiceInstallFolder"
    $ServiceBinarySourceFolder = $WinServiceConfig.SourcePath; Validate-NotNull $ServiceBinarySourceFolder "ServiceBinarySourceFolder"

    Log-ActionItem "Check if service install folder and binary source folder are the same. Do not delete the folder if paths are same."
    if(-not (Test-IfPathsEqual $ServiceBinarySourceFolder $ServiceInstallFolder))
    {
        Log-ActionResult "No"
        
        Log-Step "Remove service binaries"
        # Delete service binaries
        Log-ActionItem "Delete service binaries from [$ServiceInstallFolder]"
        Log-ActionItem "Checking if [$ServiceInstallFolder] exists."
        if(Test-Path $ServiceInstallFolder)
        {
            Log-ActionResult "Yes"

            # Remove binaries from service folders. 
            $deleteServiceBinaries = {
                        Log-ActionItem "Delete files from [$ServiceInstallFolder]."
                        Remove-Item -Path "$ServiceInstallFolder" -Recurse -Force
                        Log-ActionResult "Deleted successfully."
            }
            
            try
            {
                Perform-RetryOnDelegate $deleteServiceBinaries
            }
            catch
            {
                Throw-Error "Failed to delete files from [$ServiceInstallFolder]."
            }
        }
        else
        {
            Log-ActionResult "No"
        }
    }
    else
    {
        Log-ActionResult "Yes"
    } 

    Log-ActionResult "Complete"
}

function Remove-WindowsServiceSafe(
    $ServiceName = $(Throw 'ServiceName parameter required')
)
{
    Log-ActionItem "Check if service [$ServiceName] already exists"

    # Verify if the service already exists, and if yes remove it 
    if (Get-Service $ServiceName -ErrorAction SilentlyContinue)
    {
        Log-ActionResult "Yes"

        # Using WMI to remove Windows service because PowerShell does not have CmdLet for this
        Log-ActionItem "Delete the service $ServiceName"
        Stop-WindowsService -ServiceName $ServiceName

        $serviceToRemove = Get-WmiObject -Class Win32_Service -Filter "name='$ServiceName'"
        $serviceToRemove.Delete()
        Log-ActionResult "Service removed"
    }
    else
    {
        Log-ActionResult "Service does not exist on the system"
    }
}

function Enable-WindowsServiceMonitoringDiscovery(
    $WinServiceConfig = $(Throw 'WinServiceConfig parameter required'),

    [string]$RetailComponentRegistryKey = $(Throw 'RetailComponentRegistryKey parameter required'))
{
    $ServiceName = $WinServiceConfig.Name; Validate-NotNull $ServiceName "ServiceName"

    Log-Step "Enable discovery of Windows Service [$ServiceName] for monitoring purposes"
    try 
    {    
        $WinServiceKeyName = Join-Path $RetailComponentRegistryKey $ServiceName
        # always overwrite
        Log-ActionItem "Save parameters of the Windows Service [$ServiceName] in registry path [$WinServiceKeyName]"
        [void](New-Item $WinServiceKeyName -Force)
        New-ItemPropertyNotNull -Path $WinServiceKeyName -Name "UserName" -PropertyType "String" -Value $WinServiceConfig.LogOnUser
        New-ItemPropertyNotNull -Path $WinServiceKeyName -Name "ServiceName" -PropertyType "String" -Value $ServiceName
        New-ItemPropertyNotNull -Path $WinServiceKeyName -Name "DisplayName" -PropertyType "String" -Value $WinServiceConfig.DisplayName
        New-ItemPropertyNotNull -Path $WinServiceKeyName -Name "ExeName" -PropertyType "String" -Value $WinServiceConfig.ExecutionFileName
        New-ItemPropertyNotNull -Path $WinServiceKeyName -Name "ServiceInstallFolder" -PropertyType "String" -Value $WinServiceConfig.PhysicalPath     

        Log-ActionResult "Complete"    
    }
    catch
    {
        Log-Exception $_
        Write-Warning -Message "Failed: Enabling discovery of Windows Service [$ServiceName] for monitoring purposes"
    }
}

function Disable-WindowsServiceMonitoringDiscovery(
    $WinServiceConfig = $(Throw 'WinServiceConfig parameter required'),

    [string]$RetailComponentRegistryKey = $(Throw 'RetailComponentRegistryKey parameter required'))
{
    $ServiceName = $WinServiceConfig.Name; Validate-NotNull $ServiceName "ServiceName"
    Log-Step "Disable discovery of Windows Service [$ServiceName] for monitoring purposes"

    try
    {
        $WinServiceKeyName = Join-Path $RetailComponentRegistryKey $ServiceName
        Log-ActionItem "Delete registry entry [$WinServiceKeyName]"
        if (Test-Path $WinServiceKeyName)
        {
            Remove-Item -Path $WinServiceKeyName -Recurse -Force
        }
        Log-ActionResult "Complete"
    }
    catch
    {
        Log-Exception $_
        Write-Warning -Message "Failed: Disable discovery of Windows Service [$ServiceName] for monitoring purposes"
    }
}
# SIG # Begin signature block
# MIIjoAYJKoZIhvcNAQcCoIIjkTCCI40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCClRBfADj2RB/zr
# hWdZjQ+NP1GJZasHqGz6flZZdo4SLaCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdTCCFXECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgxAZMeMnx
# G0b8Be7RMMWt4iWFlAZuGhGp4L8m96ivKbUwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAFKBVucV
# SFAqUs9ONXBh6ZbmOiBvggMmfUrckDZtMf3Ja9POpXXJ0wXXib9Q60LY2Mz7eH0T
# GK3OT8U+vvFBT61KuEYTd53tWHM+7vRNT+eVqnrIWW3OmGSzqiSSAytNTu7okxfU
# Gul74tza3lOCg+SinqZ/+wvXvaSdDmu8TOm5lz0Kxh/xhtAdo1DORG+tlZCcPYxa
# OrJ3D1fzr9TmN+sjfg+SliklnrR9DGzdANvWLNci7NJ6JACyVlH53gG0DXYTuGRi
# atLT0+rojUx0eifUKuWdBPfrScyoEshgv1kaiBUurUQPm3QXft/g5+F8qcNJjq4W
# LpwTGwPxJlruSIChghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0B
# BwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQg02xr
# Fc1FICsVrFzng8kWB3d/GuciftmYevj8vKmaHNsCBl1exgAdCRgTMjAxOTA4Mjcw
# NzI0MjcuMzI2WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0JENC00QjgwLTY5QzMxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAANpIVQJkSJo0ZgAAAAAA2jANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTJaFw0xOTExMjMy
# MDI2NTJaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMdFKC3uLzcYc8ZNjq3vqJU2qwQMPDPvKT/+22KEdEcyNqsYOe49SrzK70WO
# 7Xq19kD+gopbvxltF3npvlRxqtyz4wIfX0uIRu8dAsAKwbyoJ5oDKcMY5F33aNDk
# aSpGDC5LkoAvsrgTEgNZz4P5aDmJLNL5G0rD12P41ez/JYaa5gRQqFWsXsU/JL7c
# tFDT7sMI7jGmY6aXfQacSDfyJRZpG1Te6jpVi2mG0xQpw94kbfmyefpDJU2Xs8DQ
# 2GzYj7ZbgBPFfF5oMTj/2DUMIC++4uvcMtvhlYIKfxykoy7h2t0pDeYCKw4njVAU
# 9Oul0rkINgVGSk4YMLwypZwu/wECAwEAAaOCARswggEXMB0GA1UdDgQWBBRr3Mjj
# h0cMgQLOLEpsBTbWTj8ALjAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQBL7GLB
# 91zxeDRqlzF0F8wYfVWmRzVf7kMCaUifQtyRd7TQYn0qdI6y0umL052DsK51SqD+
# 8J2V5ct8KcSaROprKDEcZYuHIPe7QnqqFU+kuo4wol0nVJJNVB54G1+4zoMEYF2W
# cS/1g6JTqTtH2SY9jF9b6XAnttJ0qxp80flrudvgr2GCEvF1WlJBVu8x5RXTSMdd
# EAOfYUCvndR/5B2rzh7ekuD5q/oibuu3LAlFFUX1QuXVSq52MLlceauAEBqwWz4i
# 6CkplKmlRfL5C4QzTKXr5y30pOyjihGT9ypu25Nfom4UzjvQC1f0Vw9lNgRIj9DC
# LoKNvdsSXPf9dFIgMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQB0TNNMSi2hBKkbOnnY
# KQ27guaFkqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q8zNjAiGA8yMDE5MDgyNzEyNDIzMFoYDzIwMTkwODI4
# MTI0MjMwWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhDzM2AgEAMAoCAQACAibS
# AgH/MAcCAQACAhFtMAoCBQDhEIS2AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAOGD2xW6mZOJcGwVEJJmyRafI1CA3C8ESmNRdDTS2WS/9ZaYzhSq6MeseAsYr
# AvRpTSHn1iW55UagrYUwEjiSjCv8ATslzfreFxLg5tnzKPaMTsinlReEPXhXUAOs
# bos1BnI9nOo00cDgWN2OoinXvlkt88iqc41hGZV6J/IIyqcxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANpIVQJkSJo0ZgAA
# AAAA2jANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCBvAW0LKn3fiE9uL4eDCEsYBwcnSlbGc6LvbUcH
# jEdxpjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIIrNu1u82qWDl4sq3oSM
# ZuMrmyGlVh30rY77aw1rFTETMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAADaSFUCZEiaNGYAAAAAANowIgQgXrvqQ5Vzb9OmZ5wD4rOW
# mFEL61RiGCkM4JmfDxPhvDEwDQYJKoZIhvcNAQELBQAEggEAmK8g9ZwiCuZEQ1OW
# 5m0kOhA0QZmjAcF0Mt0SNl/Z0S4Xrkejg/O+3/Lep1K1duy6R01AE0kOQzyq/X56
# NS6jjVjkaShwWI1U7sptPD3wIiVA55z0gy0SEmAmaikS0EKHRfC2pTdiqzTe4LSt
# G13tfLb1LvmlXntfab8s5b2u6lOlQflPiFHSR+8s4z3SGrN04J7FfjJz4hyVe+MP
# lNcroaV4wZUniPd/suW0R/LQAw7C5tcRrMrZoy2w68Dit4g5V4Gnm8xNIqf9b6yO
# KbVOi5+zZD1P1nZ5OhG20knDCDW1Neorip3VW1aiB+q0x6Myzbmz3NF0bIi7/DvH
# pEpC9w==
# SIG # End signature block
