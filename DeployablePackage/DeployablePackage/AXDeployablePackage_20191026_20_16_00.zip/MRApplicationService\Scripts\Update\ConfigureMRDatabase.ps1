<#
.Synopsis
Runs the required steps to configure the MR database for a new environment
#>
[CmdletBinding()]
Param
(
	# Updated name for the AOS database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAosDatabaseName,

	# Updated server name for the AOS database server
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAosDatabaseServerName,

	# Updated name for the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRDatabaseName,

	# Updated server name for the MR database server
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRDatabaseServerName = $NewAosDatabaseServerName,

	# New user name for the admin user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxAdminUserName = 'axdeployuser',

	# New password for the admin user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxAdminUserPassword,

	# New user name for the lower-privileged user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxMRRuntimeUserName = 'axmrruntimeuser',

	# New password for the lower-privileged user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxMRRuntimeUserPassword,

	# New user name for the admin user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRAdminUserName = 'mradminuser',

	# New password for the admin user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRAdminUserPassword,

	# New user name for the lower-privileged user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRRuntimeUserName = 'mrruntimeuser',

	# New password for the lower-privileged user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRRuntimeUserPassword,

	# Include this switch to default the FQDN of database server to Azure
	[switch]
	$AzureDatabase,

	# Include this switch to skip the pause warnings
	[switch]
	$NoPause,

	# Path to log file
	[string]
	[ValidateNotNullOrEmpty()]
	$LogFilePath = (Join-Path -Path $PSScriptRoot -ChildPath "MR_ConfigureDatabase_$(Get-Date -Format yyyyMMdd-HHmmss).log"),

	# SQL command timeout, override this to cause a shorter timeout
	[int]
	[ValidateRange(0,[int]::MaxValue)]
	$SqlTimeoutSeconds = 6600
)

#############################
# Validation of parameters
#############################

# Using checks here to avoid automation getting stuck for madatory parameters
if(!$NewAosDatabaseName) { throw 'Parameter $NewAosDatabaseName must not be null or empty.' }
if(!$NewAosDatabaseServerName) { throw 'Parameter $NewAosDatabaseServerName must not be null or empty.' }
if(!$NewMRDatabaseName) { throw 'Parameter $NewMRDatabaseName must not be null or empty.' }
if(!$NewAxAdminUserPassword) { throw 'Parameter $NewAxAdminUserPassword must not be null or empty.' }
if(!$NewAxMRRuntimeUserPassword) { throw 'Parameter $NewAxMRRuntimeUserPassword must not be null or empty.' }
if(!$NewMRAdminUserPassword) { throw 'Parameter $NewMRAdminUserPassword must not be null or empty.' }
if(!$NewMRRuntimeUserPassword) { throw 'Parameter $NewMRRuntimeUserPassword must not be null or empty.' }

$azureDatabaseDomain = '.database.windows.net'
if(!$AzureDatabase -and ($NewAosDatabaseServerName -notlike "*$azureDatabaseDomain"))
{
	if(!$NoPause)
	{
		Write-Warning "The database server $NewAosDatabaseServerName does not appear to be an Azure server."
		Write-Host "Is this correct (y/n)?"
		$response = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
		if($response.Character -ne 'y')
		{
			Write-Warning "Updating the database server with the Azure FQDN."
			$AzureDatabase = $true
		}
	}
}

# Update the database server to fqdn
if($AzureDatabase)
{
	if ($NewAosDatabaseServerName -notlike "*$azureDatabaseDomain")
	{
		$NewAosDatabaseServerName = $NewAosDatabaseServerName + $azureDatabaseDomain
	}

	if ($NewMRDatabaseServerName -notlike "*$azureDatabaseDomain")
	{
		$NewMRDatabaseServerName = $NewMRDatabaseServerName + $azureDatabaseDomain
	}
}
#############################
# Determine the current folder, $PSScriptRoot and $PSCommandPath do not give the same results when executed in the runbook
$script:currentFolder = (Get-ChildItem -Path (Split-Path -Path $PSScriptRoot -Parent) -Recurse -Filter ConfigureMRDatabase.ps1 | Select-Object -First 1).Directory.FullName
$commonUpgradeFunctionsPath = Join-Path -Path $script:currentFolder -ChildPath "CommonMRUpgradeFunctions.ps1"
$commonUpgradeFunctionsPath = Resolve-Path -Path $commonUpgradeFunctionsPath
. "$commonUpgradeFunctionsPath"

<#
Use the DataProtectionManager to encrypt a value then encode to Base64.
Only used for Adpater Settings.
#>
function Protect-AdapterSettingValue
{
	[CmdletBinding()]
	[OutputType([string])]
	Param
	(
		[ValidateNotNull()]
		[pscustomobject]
		$InstallPaths,

		# Value to encrypt and encode
		[string]
		[ValidateNotNullOrEmpty()]
		$Value
	)

	$keyVaultPath = Join-Path -Path $InstallPaths.Services -ChildPath 'Microsoft.CE.VaultSDK.dll'
	if(Test-Path -Path $keyVaultPath)
	{
		Add-Type -Path $keyVaultPath
	}

	Add-Type -Path (Join-Path -Path $InstallPaths.Connector -ChildPath 'Microsoft.Dynamics.Integration.DataAccessLayer.dll')
	$bindingFlags = [System.Reflection.BindingFlags] "NonPublic,Static"
	$privateMethod = [Microsoft.Dynamics.Integration.DataAccessLayer.DataProtectionManager].GetMethod("Encrypt", $bindingFlags)
	$encryptedValue = $privateMethod.Invoke($null, $Value)
	$encodedValue = [System.Convert]::ToBase64String($encryptedValue)
	return $encodedValue
}

function Update-AdapterSettings
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString,

		# Settings xml
		[xml]
		[ValidateNotNullOrEmpty()]
		$Settings
	)

	Write-MRStepMessage "Updating AX and Data Mart adapter settings"
	$installPaths = Get-MRFilePaths
	$defaultValues = Get-MRDefaultValues
	$protectedAxSqlPassword = (Protect-AdapterSettingValue -InstallPaths $installPaths -Value $defaultValues.AXSqlUserPassword)

	$frsite = '/FinancialReporting'
	$aosurl = Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'DefaultBaseAddress'
	$aosurl = $aosurl -ireplace $frsite,''

	$query = ''
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'AOSServer' -Value $aosurl
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'DatabaseServer' -Value $defaultValues.AosSqlServerName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'Database' -Value $defaultValues.AXDatabaseName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'UserName' -Value $defaultValues.AXSqlUserName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'Password' -Value $protectedAxSqlPassword
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'SqlUserName' -Value $defaultValues.AXSqlUserName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'SqlPassword' -Value $protectedAxSqlPassword
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'CertUserName' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'CertUserName')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'ProviderName' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'ProviderName')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'FederationRealm' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'FederationRealm')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'CertThumbprint' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'CertThumbprint')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'TokenIssuer' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'TokenIssuer')

	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'Server' -Value $defaultValues.MRSqlServerName
	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'Database' -Value $defaultValues.MRDatabaseName
	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'UserName' -Value $defaultValues.MRSqlUserName
	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'Password' -Value (Protect-AdapterSettingValue -InstallPaths $installPaths -Value $defaultValues.MRSqlUserPassword)

	$query += Get-UpdateAdapterQuery -AdapterId '492252C3-A2E5-48B1-84DD-277402F97930' -FieldName 'AOSServer' -Value $aosurl

	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
	Write-MRInfoMessage "Completed updating AX and Data Mart adapter settings" -Success
}

<#
	.Synopsis
	Publishes AX database settings.
#>

function Update-MRCompanySettings
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString
	)

	Write-MRStepMessage "Updating MR adapter setting and company connections"
	$installPaths = Get-MRFilePaths
	$defaultValues = Get-MRDefaultValues
	$selectQuery = 'SELECT ID, GLEntityConnectionInformation FROM [Reporting].[ControlCompany]'
	$updateQuery = Get-UpdateAdapterQuery -AdapterId '492252C3-A2E5-48B1-84DD-277402F97930' -FieldName 'DataMartConnectionString' -Value (Protect-AdapterSettingValue -InstallPaths $installPaths -Value $ConnectionString)
	$resultReader = {
		Param
		(
			[System.Data.SqlClient.SqlCommand]
			$SqlCmd
		)

		[System.Data.SqlClient.SqlDataReader]$reader = $null
		$reader = $SqlCmd.ExecuteReader()
		while($reader.Read())
		{
			[xml]$data = $reader[1]
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='SQL Server']").FirstChild.'#text' = $defaultValues.MRSqlServerName
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='DDM Database']").FirstChild.'#text' = $defaultValues.MRDatabaseName
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='SQL User']").FirstChild.'#text' = $defaultValues.MRSqlUserName
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='SQL Password']").FirstChild.'#text' = (Protect-String -InstallPaths $installPaths -Value $defaultValues.MRSqlUserPassword)
			Set-Variable -Name updateQuery -Value ($updateQuery += "UPDATE Reporting.ControlCompany SET GLEntityConnectionInformation = '$($data.OuterXml)' WHERE ID = '$($reader[0])'") -Scope 1
		}
	}

	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $selectQuery -ResultReader $resultReader
	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $updateQuery -ResultReader (Get-ExecuteNonQueryReader)
	Write-MRInfoMessage "Completed MR adapter setting and company connections" -Success
}

function Update-ChangeTracking
{
    Write-MRStepMessage 'Adding AX database change tracking (Add-AXDatabaseChangeTracking)'
    $addAXDatabaseChangeTrackingParams = Get-AddAXDatabaseChangeTrackingParams
    if((Get-Command Add-AXDatabaseChangeTracking).Parameters.Keys.Contains('SkipVirtualTableResolution'))
	{
		$addAXDatabaseChangeTrackingParams += @{'SkipVirtualTableResolution' = $true}
	}

    $installedVersion = Get-BinaryVersion
    if ($installedVersion -ge [version]'7.2')
    {
        Add-AXDatabaseChangeTracking @addAXDatabaseChangeTrackingParams
        Write-MRInfoMessage 'Completed update to change tracking' -Success

        Write-MRStepMessage 'Adding reporting database change tracking (Add-MRDatabaseChangeTracking)'
        $addMRDatabaseChangeTrackingParams = Get-AddMRDatabaseChangeTrackingParams
        Add-MRDatabaseChangeTracking @addMRDatabaseChangeTrackingParams
        Write-MRInfoMessage 'Completed update to change tracking' -Success
    }
}

function Update-IntegrationSource
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString
	)

	$loggerTaskGuid = [System.Guid]::NewGuid().ToString()
	$loggerTaskMessage = 'Update integration source.'
	Log-Event -EventType Start -message $loggerTaskMessage -guid $loggerTaskGuid

	Write-MRStepMessage 'Updating integration source'
	try
	{
		# Find the expected integration source from adapter settings that points to the current environment
		$adapterQuery = "SELECT TOP 1 Settings FROM [Connector].[MapCategoryAdapterSettings] WHERE AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'"
		[xml]$adapterSettingXml = Invoke-SqlQuery -ConnectionString $ConnectionString -Query $adapterQuery -ResultReader (Get-ExecuteScalarReader)
		$matchingfieldDefinition = $adapterSettingXml.settingsCollection.ArrayOfSettingsValue.SettingsValue | Where-Object {$_.fieldDefinition.Name -match "AOSServer"}
		$expectedIntegrationSource = $matchingfieldDefinition.Value

		Write-MRStepMessage "Expected integration source is: '$expectedIntegrationSource'."

		# Log all existing integration sources in MR database
		$existingIntegrationSourceQuery = 'SELECT Name FROM [Reporting].[ControlIntegrationSource]'
		$resultReader = {
			Param
			(
				[System.Data.SqlClient.SqlCommand]
				$SqlCmd
			)

			[System.Data.SqlClient.SqlDataReader]$reader = $null
			$reader = $SqlCmd.ExecuteReader()
			while($reader.Read())
			{
				[string]$data = $reader[0]

				if($data -ne $expectedIntegrationSource)
				{
					Write-MRStepMessage "Unexpected integration sources '$data' is found. The related integration source data will be deleted from MR database."
				}
				else
				{
					Write-MRStepMessage "Expected integration sources '$data' is found in MR database."
				}
			}
		}
		Invoke-SqlQuery -ConnectionString $ConnectionString -Query $existingIntegrationSourceQuery -ResultReader $resultReader

		# Remove unexpected integration sources from MR database
		$query = @"
DECLARE @badSourceId int
DECLARE @goodSourceID int
DECLARE @name NVARCHAR(255)
DECLARE @expectedIntegrationSource NVARCHAR(255) = '$expectedIntegrationSource'

SELECT @goodSourceID = (SELECT TOP 1 ID FROM Reporting.ControlIntegrationSource WHERE Name = @expectedIntegrationSource)
IF(@goodSourceID IS NULL)
BEGIN
	INSERT INTO Reporting.ControlIntegrationSource VALUES (@expectedIntegrationSource,':0')
	SELECT @goodSourceID = (SELECT TOP 1 ID FROM Reporting.ControlIntegrationSource WHERE Name = @expectedIntegrationSource)
    
    UPDATE [Connector].[Map] SET [ReaderToken] = NULL, [LastQuerySuccess] = '1900-01-01'
		FROM [Scheduling].[Task] WITH (NOLOCK)
		INNER JOIN [Scheduling].[TaskType] WITH (NOLOCK) ON [Task].[TypeId] = [TaskType].[Id]
		INNER JOIN [Connector].[Map] WITH (NOLOCK) ON [Task].[Id] = [Map].[MapId]
		WHERE Task.Name like '%Organization Hierarchies to Tree' and TaskType.Name like '%Map Task%'

	UPDATE [Scheduling].[Trigger] SET [Trigger].[RunImmediately] = 1 
		FROM [Scheduling].[Task] WITH (NOLOCK)
		INNER JOIN [Scheduling].[TaskType] WITH (NOLOCK) ON [Task].[TypeId] = [TaskType].[Id]
		INNER JOIN [Scheduling].[Trigger] WITH (NOLOCK) ON [Task].[TriggerId] = [Scheduling].[Trigger].[Id]
		WHERE Task.Name like '%Organization Hierarchies to Tree' and TaskType.Name like '%Map Task%'
END

DECLARE integrationSourceCursor CURSOR LOCAL FAST_FORWARD FOR
SELECT ID, Name
FROM Reporting.ControlIntegrationSource	WHERE ID != @goodSourceID
OPEN integrationSourceCursor
FETCH NEXT FROM integrationSourceCursor INTO @badSourceId, @name
WHILE (@@FETCH_STATUS = 0)
BEGIN
	-- Re-associate trees that are in use
	DECLARE @treeId uniqueidentifier
	DECLARE @oldIntegrationKey uniqueidentifier
	DECLARE @folderName NVARCHAR(255)
	DECLARE fixOldTreesCursor CURSOR LOCAL FAST_FORWARD FOR
	SELECT ctm.ID, cfi.IntegrationKey, cfi.Name FROM Reporting.ControlTreeMaster ctm 
		join Reporting.ControlFolder cf ON ctm.FolderID = cf.ID
		join Reporting.ControlReport cr ON cr.ReportingTreeID = ctm.ID
		left join Reporting.ControlFolderIntegration cfi on cfi.FolderID = cf.ID
		WHERE cf.FolderType = 3 and cf.SpecificationSetID is NULL and cfi.SourceID = @badSourceId
	OPEN fixOldTreesCursor
	FETCH NEXT FROM fixOldTreesCursor INTO @treeId, @oldIntegrationKey, @folderName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		DECLARE @newTreeId uniqueidentifier 
		SET @newTreeId = (SELECT top 1 ctm.ID FROM Reporting.ControlTreeMaster ctm 
			join Reporting.ControlFolder cf ON ctm.FolderID = cf.ID	
			join Reporting.ControlTreeIntegration ti on ctm.ID = ti.TreeID
			join Reporting.ControlFolderIntegration cfi on cfi.FolderID = cf.ID
			WHERE cf.FolderType = 3 and cf.SpecificationSetID is NULL and cfi.SourceID = @goodSourceID and cfi.Name = @folderName
			ORDER BY ti.EffectiveDate ASC)
		IF @newTreeId IS NULL
		BEGIN
			-- since it's null just update to the new source
			print 'No matching tree was found.'
			BEGIN TRY	
				BEGIN TRAN UpdateIntegrationSource	
					UPDATE Reporting.ControlTreeIntegration SET SourceID = @goodSourceID WHERE IntegrationKey = @oldIntegrationKey and TreeID = @treeId						
					UPDATE Reporting.ControlFolderIntegration SET SourceID = @goodSourceID from Reporting.ControlFolderIntegration 
						INNER JOIN Reporting.ControlTreeMaster ON [ControlFolderIntegration].FolderID = [ControlTreeMaster].FolderID 
						WHERE IntegrationKey = @oldIntegrationKey and ControlTreeMaster.ID = @treeId				
				COMMIT TRAN UpdateIntegrationSource 
			END TRY
			BEGIN CATCH
				IF (@@TRANCOUNT > 0)
				BEGIN
				  print 'Failed to correct the integration source for the existing integrated tree, all changes reversed.'--
				  ROLLBACK TRANSACTION UpdateIntegrationSource				  
				END 
				-- remove the tree reference from report definition
				UPDATE Reporting.ControlReport SET ReportingTreeID = NULL, StartingUnitID = NULL WHERE ReportingTreeID = @treeId				
			END CATCH
		END
		ELSE
		BEGIN
			-- we have a new tree to use, update the tree reference from report definition instead
			print 'Found matching tree.'
			UPDATE Reporting.ControlReport SET ReportingTreeID = @newTreeId, StartingUnitID = NULL WHERE ReportingTreeID = @treeId
		END
		FETCH NEXT FROM fixOldTreesCursor INTO @treeId, @oldIntegrationKey, @folderName
	END
	CLOSE fixOldTreesCursor
	DEALLOCATE fixOldTreesCursor

	-- Clear the reset of the references from the old integration source
	Delete from [Reporting].[SecurityUserIntegration] where SourceID = @badSourceId 
	Delete from [Reporting].[ControlCompanyIntegration] where SourceID = @badSourceId 
	Delete from [Reporting].[SecurityCompanyPermissionIntegration] where SourceID = @badSourceId 
	Delete from [Reporting].[SecurityCompanyPermissionStaging] where SourceID = @badSourceId 
	Delete from [Reporting].[ControlTreeIntegration] where SourceID = @badSourceId
	Delete from [Reporting].[ControlConfiguredIntegration] where SourceID = @badSourceId
	Delete from [Reporting].[ControlTreeMaster] where FolderID in (select FolderID from Reporting.ControlFolderIntegration where SourceID = @badSourceId) 
	Delete from [Reporting].[ControlFolder] where ID in (select FolderID from Reporting.ControlFolderIntegration where SourceID = @badSourceId)
	Delete from [Reporting].[ControlFolderIntegration] where SourceID = @badSourceId
FETCH NEXT FROM integrationSourceCursor INTO @badSourceId, @name
END
CLOSE integrationSourceCursor
DEALLOCATE integrationSourceCursor

Delete from [Reporting].[ControlIntegrationSource] where ID != @goodSourceID
"@
		Invoke-SqlQuery -ConnectionString $ConnectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
		Write-MRInfoMessage 'Completed updating integration source' -Success
	}
	finally
	{
		Log-Event -EventType Stop -message $loggerTaskMessage -guid $loggerTaskGuid
	}
}

function Get-MRFilePaths
{
	$registryView = [Microsoft.Win32.RegistryView]::Default
	if([Environment]::Is64BitOperatingSystem)
	{
		# If OS is x64, always force x64 registry
		$registryView = [Microsoft.Win32.RegistryView]::Registry64
	}

	$baseKey = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $registryView)
	$mrServerRegKey = $baseKey.OpenSubKey('Software\Microsoft\Dynamics\ManagementReporter\21\Server')
	[string]$mrInstallLocation = $null
	if(!$mrServerRegKey)
	{
		# See if the MSI is installed and pull the InstallLocation from that, fail-safe if the registry gets messed up
		$product = Get-MRServerInstallProduct
		if(!$product)
		{
			throw 'MR server is not installed'
		}
		else
		{
			$mrInstallLocation = $product.InstallLocation
		}
	}
	else
	{
		$mrInstallLocation = $mrServerRegKey.GetValue('InstallLocation')
	}

	$paths = [pscustomobject]@{
		Server    = ''
		ClickOnce = ''
		Connector = ''
		Console = ''
		InstallLocation = ''
		MRDeploy  = ''
		ApplicationService = ''
		ApplicationServiceConnectionsConfig = ''
		ApplicationServiceSettingsConfig = ''
		ServicesConnectionsConfig = ''
		ServicesSettingsConfig = ''
		Services = ''
	}

	$paths.InstallLocation = $mrInstallLocation
	$paths.Server = Join-Path -Path $paths.InstallLocation -ChildPath 'Server'
	$paths.Services = Join-Path -Path $paths.Server -ChildPath 'Services'
	$paths.ApplicationService = Join-Path -Path $paths.Server -ChildPath 'ApplicationService'
	$paths.ClickOnce = Join-Path -Path $paths.Server -ChildPath 'ClickOnceClient'
	$paths.Connector = Join-Path -Path $paths.Server -ChildPath 'Connector'
	$paths.Console = Join-Path -Path $paths.Server -ChildPath 'Console'
	$paths.MRDeploy = Join-Path -Path $paths.Server -ChildPath 'MRDeploy'
	$paths.ApplicationServiceConnectionsConfig = Join-Path -Path $paths.ApplicationService -ChildPath 'bin\MRServiceHost.connections.config'
	$paths.ApplicationServiceSettingsConfig = Join-Path -Path $paths.ApplicationService -ChildPath 'bin\MRServiceHost.settings.config'
	$paths.ServicesConnectionsConfig = Join-Path -Path $paths.Services -ChildPath 'MRServiceHost.connections.config'
	$paths.ServicesSettingsConfig = Join-Path -Path $paths.Services -ChildPath 'MRServiceHost.settings.config'
	return $paths
}

filter Out-Log
{
	if($LogFilePath)
	{
		$fileOutput = $null
		# Teeing to a variable to prevent 'The process cannot access the file _ because it is used by another process'
		$_ | Tee-Object -Variable fileOutput | Out-Host

		if($fileOutput)
		{
			$retryOutFile = 5
			while($retryOutFile -gt 0)
			{
				try
				{
					$retryOutFile--
					$fileOutput | Out-File -FilePath $LogFilePath -Append -Force -NoClobber
					$retryOutFile = 0
				}
				catch
				{
					if($retryOutFile -eq 0)
					{
						# Write warning on last retry
						$errorMessage = $_ | Out-String
						Write-Warning $errorMessage
					}
				}
			}
		}
	}
	else
	{
		$_ | Out-Host
	}
}

function Update-DefaultValues
{
	[CmdletBinding()]
	Param
	(
		# Settings xml
		[xml]
		[ValidateNotNullOrEmpty()]
		$Settings
	)

	Set-MRDefaultValues -Settings @{
		'MRSqlServerName'=$NewMRDatabaseServerName;
		'MRDatabaseName'=$NewMRDatabaseName;
		'MRSqlUserName'=$NewMRAdminUserName;
		'MRSqlUserPassword'=$NewMRAdminUserPassword;
		'MRSqlRuntimeUserName'=$NewMRRuntimeUserName;
		'MRSqlRuntimeUserPassword'=$NewMRRuntimeUserPassword;
		'AXDatabaseName'=$NewAosDatabaseName;
		'AosSqlServerName'=$NewAosDatabaseServerName;
		'AXSqlUserName'=$NewAxAdminUserName;
		'AXSqlUserPassword'=$NewAxAdminUserPassword;
		'AXSqlRuntimeUserName'=$NewAxMRRuntimeUserName;
		'AXSqlRuntimeUserPassword'=$NewAxMRRuntimeUserPassword;
		'SqlTimeoutSeconds'=$SqlTimeoutSeconds;
		'SSDTTimeoutSeconds'=$SqlTimeoutSeconds;
	}

	Write-MRInfoMessage -Message 'Fetching data encryption and data signing certificate thumbprints.'
	$encryptionThumbprint = Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'DataEncryptionCertificateThumbprint'
	$signingThumbprint = Get-DataSigningCertificateThumbprint -SettingsXml $Settings -DataEncryptionCertificateThumbprint $encryptionThumbprint
	Set-MRDefaultValues -Settings @{'DataEncryptionCertThumbprint'=$encryptionThumbprint}
	Set-MRDefaultValues -SettingName 'DataSigningCertThumbprint' -SettingValue $signingThumbprint -WarnInsteadOfError
}

function Start-Execution
{
	Write-Host "Logging can be found at $LogFilePath"
	$taskGuid = [System.Guid]::NewGuid().ToString()
	$taskMessage = 'Configure MR Database'
	Log-Event -EventType Start -message $taskMessage -guid $taskGuid

	try
	{
		$installPaths = Get-MRFilePaths
        $connectionsConfigFilePath = Get-ConnectionConfigPath -InstallPaths $installPaths
		$modulePath = $installPaths.MRDeploy
		Import-Module $modulePath

		$settingsConfigFilePath = $null
		if(!(Test-Path -Path $installPaths.ApplicationServiceConnectionsConfig))
		{
			throw 'Script can only be run on the MRApplicationService box, typically AOS.'
		}

		$settingsConfigFilePath = $installPaths.ApplicationServiceSettingsConfig

		Write-MRInfoMessage -Message 'Load settings config and update default values'
		[xml]$settingscontents = Get-Content $settingsConfigFilePath -Raw
		Update-DefaultValues -Settings $settingsContents
		$defaultValues = Get-MRDefaultValues

		Write-MRStepMessage 'Load the current connection settings'
		[System.Data.SqlClient.SqlConnectionStringBuilder] $mrDatabaseConnection = Get-DecryptedConnectionString -InstallPaths $installPaths -ConnectionsConfigFilePath $connectionsConfigFilePath
		Set-MRDefaultValues -SettingName 'MRSqlTrustServerCertConnection' -SettingValue ([string]($mrDatabaseConnection.TrustServerCertificate))
		Set-MRDefaultValues -SettingName 'MRSqlEncryptConnection' -SettingValue $mrDatabaseConnection.Encrypt
		if (-not $mrDatabaseConnection.IntegratedSecurity)
		{
			$mrDatabaseConnection."User ID" = $defaultValues.MRSqlUserName
			$mrDatabaseConnection."Password" = $defaultValues.MRSqlUserPassword
		}

		Write-MRStepMessage 'Update the connection settings in the database'
		Update-DeploymentConfig
		Update-AdapterSettings -ConnectionString $mrDatabaseConnection.ConnectionString -Settings $settingsContents
		Update-MRCompanySettings -ConnectionString $mrDatabaseConnection.ConnectionString
		Write-SchemaUserPrivileges
		$securePassword = ConvertTo-SecureString $NewMRAdminUserPassword -AsPlainText -Force
		$mrCredentials = New-Object System.Management.Automation.PSCredential -ArgumentList $NewMRAdminUserName, $securePassword
		$signingThumbprint = $null
		if ((Get-MRDefaultValueNames) -contains 'DataSigningCertThumbprint')
		{
			$signingThumbprint = $defaultValues.DataSigningCertThumbprint
		}
		else
		{
			$signingThumbprint = $defaultValues.DataEncryptionCertThumbprint
		}

		Update-ChangeTracking
		Update-UserRoles -ConnectionString $mrDatabaseConnection.ConnectionString -DataEncryptionCertificateThumbprint $defaultValues.DataEncryptionCertThumbprint -DataSigningCertificateThumbprint $signingThumbprint
		Update-IntegrationSource -ConnectionString $mrDatabaseConnection.ConnectionString
		Reset-ReportDefinitionMaps -ServerInstance $NewMRDatabaseServerName -DatabaseName $NewMRDatabaseName -Credential $mrCredentials -DataEncryptionCertificateThumbprint $defaultValues.DataEncryptionCertThumbprint -DataSigningCertificateThumbprint $signingThumbprint
	}
	catch
	{
		Write-LogMessage -Message "An error ocurred while running the script, check the event logs."
		Write-ErrorDetail -ErrorThrown $_
		throw
	}
	finally
	{
		Log-Event -EventType Stop -message $taskMessage -guid $taskGuid
		Write-MRInfoMessage 'Configure MR Database Script End'
		Remove-Module 'MRDeploy'
	}
}

Set-StrictMode -Version 3
Start-Execution *>&1 | Out-Log
# SIG # Begin signature block
# MIIjnAYJKoZIhvcNAQcCoIIjjTCCI4kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBlxB44cTXsZ+ge
# 6GJK1XQP0j5xDCqT0V2McX2grBx/G6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVcTCCFW0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgQLFutyVj
# nE6xe5H+hvc6RHkKlTrTLOBwsxHpn+KX4wcwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAHCBVJjr
# hMOSoDNavq1MjsUIxbwQ0DTBG9bk3HN+f2HpG+qSk0HtG7SmcrSda5QWbh7nejdv
# yU2gW5EttQCYdj/5olnxEnsW+aes25JxvaMHxnfVxDnlRmXK32+1dP3Jt7gtlPZE
# 2BAkcwszz8xJ7xd2GxZwt/F3qNmhIChuRFx/wVWCqRil/y7TYM2c1IuTQiH4Q2CA
# E3AFew6g70Ltfkg+FaBGoy1zkmZltdNrbvZ5ZHneFoSf9cqLxtZxe/O0yxg3gA2d
# mxMcH3HTcryJCOy2hW511eIJ+V121b5hvJPyFAitfvmd5+m9txJngMhS31jiNDGn
# gWxm8OigZMCfu+uhghLhMIIS3QYKKwYBBAGCNwMDATGCEs0wghLJBgkqhkiG9w0B
# BwKgghK6MIIStgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUAYLKoZIhvcNAQkQAQSg
# ggE/BIIBOzCCATcCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQg2mdW
# ZAPgesWaWPsGTJU8xMBgUmU/XxeJRdxROTviEhoCBl1exl4mMxgSMjAxOTA4Mjcw
# NzIzMzUuNjFaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoxNzlFLTRCQjAtODI0NjElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjkwggTxMIID2aAD
# AgECAhMzAAAA26pt4yJ/NAAlAAAAAADbMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjY1M1oXDTE5MTEyMzIw
# MjY1M1owgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjE3OUUtNEJCMC04MjQ2MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAp6GakAyYJItLNm7N/TusT1Rc/lMKotEQMM6qIDDelrmRJgp1EDCdCa8DDiUU
# DZxN8IuMUv3OdLf4n7wJYbaLKccQiKtWCQOvqcbXwfbyu8bt2N2hE6odY2ZjzLM/
# dgX6SIi/lGruB9dgJixv7TIbfvGBboN9IscE3ygmrQZndzvknhKIZWIgX/e2iVQ/
# az0j5SllIaw5HaVFDLEGFNN1q++uIpRGy1HPc8D/8/+sLTyPkak1/N+31KrlOMpQ
# +Re9P65EYeit1jqx1rEKouO+gRhijY0MosJcQ8LebwsFIrtZXQJNLCPcCok0L+x6
# Gzb6LdkXb2RzMfWK07MlL6pNCwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFLK63x2A
# XHOmzbbt5ByMrd4qQwNIMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBABVCwpqd
# vRlgfiJHiSTpgZXVXm5XY1Gb+kfsl5NZMUxYaSAVAf0AmRTkT64R8uCOt1Ayr83J
# wThAirRxvQdWdg4o8aeK8UOGZp1kfVoFBZB/8OW+LIcaEgP19qqe084C2bnWMAa+
# ejsfjEbN3tLOay8D2GDD3Ot2yIK2THWzm4I9xUV0QAWL6hL00uTY0ULm608rokc4
# 0uQU0OkEFiy/k93UPYPJjUk+BKGyENGv9TFXhtwz4QcYwpdGZ67AwB0RiT7dreoy
# ikxG32xkisijcfrDbdDstERmqVy4GsxfFPyk5eVSpR9YWL+Pe+vyGg/wQnMcllGu
# Sr9wmTpaVGQ9IYswggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLLMIICNAIBATCB+KGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046MTc5RS00QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAFulKU6vGKz4cDwkT2pE
# W61vx9swoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDhDzOLMCIYDzIwMTkwODI3MTI0MzU1WhgPMjAxOTA4Mjgx
# MjQzNTVaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOEPM4sCAQAwBwIBAAICAv8w
# BwIBAAICEXQwCgIFAOEQhQsCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGE
# WQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBj
# 6bhln7Oy5ri2g2GOqNHeLJEWr3BGeEcCTin7598n2ShuniWb4UsY0fOT/4UtfkRu
# WepSfbhNpJn+vNxEUyKXSups3Vuhj+bf/vZaLcVMR3HsWMSlyneIqpSSfcn9JFFu
# GtdqKPtPKqRTNGVyi2UkxQT54u4FkoLd/4foDPiaYDGCAw0wggMJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA26pt4yJ/NAAlAAAAAADb
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEILnIZM1TCaR6xhNntJmAqo6+O6VCwwHAqKkyYrjNmpZ1
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgAlMdsdOYAS0itWojJWOwi31H
# tuIgt/yw+vLrnSGM/qowgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAANuqbeMifzQAJQAAAAAA2zAiBCAOI5oByZOQeiDlzcU7OwO3Kwpc
# 9PtqmR9U+q1xWsLEqDANBgkqhkiG9w0BAQsFAASCAQAthWRtaNn/1faRtkItXZuT
# OOWd04bTHt4gAYXkV9z6PpGItsHfDWvl2+5uwvtrNyB56W5D21OnFkKFkLZy5h/W
# u7+BCMp5w9LbGRyh3F2vBPRSNvwgDdsdimdWcuOLD1NijSKhm+c0izA2Zna2BlSw
# ++ft6kFvuIxivTwbOTpxbCdC/k2neWGS/+o0WLnKbiO/oEGO78sWQ87LOmd82XBD
# IHxAEbew+u+5ntKLeS/BJ8zo4Twet1su6OSwWEkhoRgPfyYN3V4R7xBhxd5sRE/K
# 8+Mi6vZexRsEehC95pc2KTN7xxCKsP8BIwBU7KKpPpmuj6MH7SKoK7aEP9cXTiTo
# SIG # End signature block
