<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

# Log function
function Log-TimedMessage(
    [string]$logMessage,
    [string]$log)
{
    $timeStamp = Get-TimeStamp
    $logMessage = '[{0}] {1}' -f $timeStamp, $logMessage
    Write-Host $logMessage

    if ($log)
    {
        $logMessage | Out-File -FilePath $log -Append -Force
    }
}

function Log-TimedError(
    [string]$message,
    [string]$log)
{
    Log-TimedMessage -logMessage '############### Error occurred: ###############' -log $log
    Log-TimedMessage -logMessage $message -log $log
}

function Log-Parameter(
    [string]$parameterName, 
    [string]$parameterValue, 
    [string]$log)
{
    $message = 'Parameter Name: {0} Parameter Value: {1}' -f $parameterName, $parameterValue
    Log-TimedMessage -logMessage $message -log $log
}

function Log-Exception(
    $exception,
    [string]$log)
{
    $message = ($exception | fl * -Force | Out-String -Width 4096)
    # If passed object is a string, just log the string.
    if ($exception -is [string])
    {
        $message = $exception
    }

    Log-TimedError -message $message -log $log
}

# Timestamp for logging
function Get-TimeStamp
{
    [string]$timeStamp = [System.DateTime]::Now.ToString("yyyy-MM-dd HH:mm:ss")
    return $timeStamp
}

# Handle DVt Error
function Handle-DvtError(
    $errorObject,
    [string]$log)
{
    Log-Exception -exception $errorObject -log $log
    Throw $errorObject
}

# Convert the raw base64 to a useful string
function Convert-Base64ToString(
    [string]$base64String)
{
    Log-TimedMessage -logMessage 'Converting Base64 string to string' -log $log
    [string]$rawString = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($base64String))
    
    return $rawString
}

# Retrieve values from XML based on XPath
function Get-ServiceModelParameterValue (
   [xml]$serviceModelXml,
   [string]$xPath,
   [string]$paramName)
{
    return (Select-Xml $serviceModelXml -XPath $xPath | Where { $_.Node.Name -eq $paramName }).Node.Value
}

# Make sure the Directory path exists
function New-DirectoryIfNotExists(
    [ValidateNotNullOrEmpty()]
    [string]$dirPath)
{
    if (-not (Test-Path -Path $dirPath))
    {
        New-Item -Path $dirPath -Type Directory -Force | Out-Null
    }
}

function Get-PathLeafNoFileExtenstion(
    [string]$path)
{
    return ([IO.Path]::GetFileNameWithoutExtension($path))
}

# Create DVT local directory
function CreateDirectoryAndCopy-ScriptsToDVTLocalDir(
    [string]$dvtScript,
    [array]$dvtHelperScripts,
    [string]$log)
{
    if (!$env:SERVICEDRIVE)
    {
        $env:SERVICEDRIVE = $env:TEMP
    }

    # Create DVT local directory
    $dvtLocalBinChildPath = Get-PathLeafNoFileExtenstion -path $dvtScript
    $dvtLocalBin = (Join-Path -Path $env:SERVICEDRIVE -ChildPath "DynamicsDiagnostics\$dvtLocalBinChildPath\Input")
    New-DirectoryIfNotExists -DirPath $dvtLocalBin

    # Copy DVT scripts to local directory
    $logMessage = 'Copy DVT Script {0} to local DVT bin {1}' -f $dvtScript, $dvtLocalBin
    Log-TimedMessage -logMessage $logMessage -log $log
    Copy-Item -Path $dvtScript -Destination $dvtLocalBin -Recurse -Force | Out-Null

    # Copy DVT helper scripts to local directory
    foreach ($dvtHelperScript in $dvtHelperScripts)
    {
        $logMessage = 'Copy DVT helper Scripts {0} to local DVT bin {1}' -f $dvtHelperScript, $dvtLocalBin
        Log-TimedMessage -logMessage $logMessage -log $log
        Copy-Item -Path $dvtHelperScript -Destination $dvtLocalBin -Recurse -Force | Out-Null
    }

    return $dvtLocalBin
}

# Add column values to the rows for the XML template
function Add-ColumnToDvtTestResultsXml(
    [string]$columnName,
    [xml]$dvtOutputXmlTemplate,
    [System.Xml.XmlLinkedNode]$row,
    [string]$log)
{
    $column = $dvtOutputXmlTemplate.CreateElement('string')
    $column.InnerText = $columnName
    [void]$row.AppendChild($column)
    Log-TimedMessage -logMessage ('Adding column value: {0}' -f $columnName) -log $log | Out-Null
}

# Append XML Rows to Template
function Append-RowToTestResultsXml(
    [string]$testName,
    [string]$testType,
    [string]$testResult,
    [string]$rawResult,
    [string]$timeStamp,
    [xml]$dvtOutputXmlTemplate,
    [string]$log)
{
    Log-TimedMessage -logMessage 'Getting existing rows from XML Template' -log $log
    $rows = $dvtOutputXmlTemplate.SelectSingleNode('CollectionResult/TabularResults/TabularData/Rows')
    Log-TimedMessage -logMessage 'Creating new row' -log $log
    $row = $dvtOutputXmlTemplate.CreateElement('ArrayOfStrings')

    Add-ColumnToDvtTestResultsXml -columnName $testName -dvtOutputXmlTemplate $dvtOutputXmlTemplate -row $row -log $log
    Add-ColumnToDvtTestResultsXml -columnName $testType -dvtOutputXmlTemplate $dvtOutputXmlTemplate -row $row -log $log
    Add-ColumnToDvtTestResultsXml -columnName $testResult -dvtOutputXmlTemplate $dvtOutputXmlTemplate -row $row -log $log
    Add-ColumnToDvtTestResultsXml -columnName $rawResult -dvtOutputXmlTemplate $dvtOutputXmlTemplate -row $row -log $log
    Add-ColumnToDvtTestResultsXml -columnName $timeStamp -dvtOutputXmlTemplate $dvtOutputXmlTemplate -row $row -log $log

    $rows.AppendChild($row)
    $dvtOutputXmlTemplate.CollectionResult.TabularResults.TabularData.AppendChild($rows)
    $dvtOutputXmlTemplate.Save($dvtOutputXmlTemplate)
    Log-TimedMessage -logMessage 'Saved rows to XML Template' -log $log
}

function Check-IsDemoDataLoaded(
    [string]$axDbName = $(throw 'AxDB name is required'),
    [string]$axDbServer = $(throw 'AxDB Server is required'),
    [string]$aosDatabaseUser = $(throw 'AOS Database Username is required'),
    [string]$aosDatabasePass = $(throw 'AOS Database Password is required'),
    [string]$logFile)
{
    [string]$query = "select RECID from DataArea where DataArea.id = 'USRT'"
    [bool]$isDemoDataPresent = $false

    try
    {
        $queryResult = Invoke-Sqlcmd -Query $query -Database $axDbName -ServerInstance $axDbServer -Username $aosDatabaseUser -Password $aosDatabasePass
        $logMessage = ('Sql query result : {0} using Query: {1}, Database Name: {2}, Server Instance: {3}, Username: ****** and Password: ******' `
                    -f $queryResult.RECID, $query, $axDbName, $axDbServer)
        Log-TimedMessage -logMessage $logMessage -log $logFile

        if($queryResult.RECID)
        {
            $isDemoDataPresent = $true
        }
    }
    catch
    {
        Log-Exception -exception $_ -log $logFile
    }	

    return $isDemoDataPresent
}

function Download-ServiceHealthCheckEndpointXML(
    [string]$healthCheckUrl = $(throw 'Endpoint Url is required'),
    [int]$retryHealthCheckAttempts = 1,
    [string]$logFile)
{
    [bool]$healthCheckSuccessful = $false
    [int]$retryHealthCheckAttemptsCounter = 1

    while(($retryHealthCheckAttemptsCounter -le $retryHealthCheckAttempts) -and ($healthCheckSuccessful -eq $false))
    {
        try
        {
            [xml]$healthCheckData = (New-Object System.Net.WebClient).DownloadString($healthCheckUrl)
            $healthCheckSuccessful = $true
            $result = $healthCheckData.SelectNodes("//TestResult/Success")
            Log-TimedMessage -logMessage ('Downloaded Health Check Data: {0}' -f $healthCheckData.InnerXml) -log $logFile
        }
        catch [System.Net.WebException]
        {
            $logExceptionMessage = 'On retry attempt {0} out of {1}, failed to download the XML from the Url: {2}. The exception reported is {3}' `
                                -f $retryHealthCheckAttemptsCounter, $retryHealthCheckAttempts, $healthCheckUrl, $_
            Log-Exception -exception $logExceptionMessage -log $logFile
        }
        $retryHealthCheckAttemptsCounter++
    }

    if(!$healthCheckSuccessful)
    {
        Log-Exception -exception ('Failed to donwload the XML from the health Check Url after retrying {0} times.' -f $retryHealthCheckAttempts) -log $logFile
    }

    return $result
}

function Validate-RetailHealthCheckDVTResult(
    [bool]$isDemoDataPresent = $(throw 'Is Demo data present information is required'),
    [array]$result = $(throw 'Xml Nodes for the test results is required')
)
{
    [bool]$dvtResult = $false

    if($isDemoDataPresent)
    {
        if(($result[0].InnerText -eq 'True') -and ($result[1].InnerText -eq 'True'))
        {
            $dvtResult = $true
        }
    }
    else
    {
        if($result[0].InnerText -eq 'True')
        {
            $dvtResult = $true
        }
    }

    $logMessage = 'DVT execution result {0}' -f $dvtResult
    Log-TimedMessage -logMessage $logMessage -log $logFile

    return $dvtResult
}

function Create-HealthCheckUrl(
    [string]$retailServerUrl = $(throw 'Retail Server Url is required'),
    [bool]$isDemoDataPresent = $(throw 'Demo Data information is required')
)
{
    [string]$server = $retailServerUrl.Replace('/Commerce','')
    [string]$pathWithDemoData = '/healthcheck?testname=ping&resultformat=xml'
    [string]$pathWithoutDemoData ='/healthcheck?testname=ping&resultformat=xml&co=y'

    if($isDemoDataPresent)
        {
            $appendPath = $pathWithDemoData
        }
        else
        {
            $appendPath = $pathWithoutDemoData
        }

    $healthCheckUrl = '{0}{1}' -f $server, $appendPath

    return $healthCheckUrl
}

# Validate Retail Server EndPoint with and without Demo data
function Validate-RetailHQPostDeployment(
    [string]$retailServerUrl = $(throw 'Retail Server Url is required'),
    [string]$axDbName = $(throw 'AxDB name is required'),
    [string]$axDbServer = $(throw 'AxDB Server is required'),
    [string]$aosDatabaseUser = $(throw 'AOS Database Username is required'),
    [string]$aosDatabasePass = $(throw 'AOS Database Password is required'),
    [string]$logFile)
{
    [int]$maxRetryHealthCheckAttempts = 3
    [bool]$isDvtSuccessful = $false
    $returnResult = 'No Result'

    try
    {   
        $isDemoDataPresent = Check-IsDemoDataLoaded -axDbName $axDbName `
                                                    -axDbServer $axDbServer `
                                                    -aosDatabaseUser $aosDatabaseUser `
                                                    -aosDatabasePass $aosDatabasePass `
                                                    -logFile $logFile
        
        $healthCheckUrl = Create-HealthCheckUrl -retailServerUrl $retailServerUrl -isDemoDataPresent $isDemoDataPresent
        Log-TimedMessage -logMessage ('Health Check Url:  {0}' -f $healthCheckUrl) -log $logFile

        $result = Download-ServiceHealthCheckEndpointXML -healthCheckUrl $healthCheckUrl -retryHealthCheckAttempts $maxRetryHealthCheckAttempts -logFile $logFile
        $isDvtSuccessful = Validate-RetailHealthCheckDVTResult -isDemoDataPresent $isDemoDataPresent -result $result

        if($isDemoDataPresent)
        {
            $returnResult = '{0}  {1}' -f $result[0].InnerText, $result[1].InnerText
        }
        else
        {
            $returnResult = $result[0].InnerText
        }
    }
    catch
    {
        Log-Exception -exception $_ -log $logFile
    }

    if($isDvtSuccessful)
    {
        $returnProperties = @{
            Result=1
            RawResults= $returnResult
        }
    }
    else
    {
        $returnProperties = @{
            Result=0
            RawResults= $returnResult
        }
    }

    $timeStamp = Get-TimeStamp
    $returnProperties.Add("TimeStamp", $timeStamp)
    $resultObject = New-Object PsObject -Property $returnProperties

    return $resultObject
}

# Validation Helper Functions
# Validate appPool is started
function Validate-AppPool(
    [string]$appPoolName,
    [ValidateSet("Started","Stopped")]
    [string]$expectedState,
    [string]$logFile)
{
    [bool]$IsAppPoolInExpectedState = $false

    try
    {
        Log-TimedMessage -logMessage ('Validating AppPool: {0} is {1}' -f $appPoolName, $expectedState) -log $logFile
        Import-Module WebAdministration
        $thisAppPool = Get-WebAppPoolState -Name $appPoolName
        $rawResult = ('AppPoolName: {0}; Status: {1}' -f $thisAppPool.ItemXPath, $thisAppPool.Value)
        $IsAppPoolInExpectedState = $thisAppPool.Value.ToString() -eq $expectedState
        $logMessage = ('AppPool: {0} is {1}' -f $appPoolName, $thisAppPool.Value)
        Log-TimedMessage -logMessage $logMessage -log $logFile
    }
    catch
    {
        Log-Exception -exception $_ -log $logFile
    }

    if ($IsAppPoolInExpectedState)
    {
        $returnProperties = @{
            Result=1;
            RawResults=$rawResult;
        }
    }
    else
    {
        $returnProperties = @{
            Result=0;
            RawResults=$rawResult;
        }
    }

    $timeStamp = Get-TimeStamp
    $returnProperties.Add("TimeStamp", $timeStamp)
    $resultObject = New-Object PsObject -Property $returnProperties
    return $resultObject
}

# Execute DVT Script
function Execute-DVTScript(
    [string]$dvtLocalScript,
    [string]$log,
    [string]$xmlInputPath)
{
    if (Test-Path -Path $dvtLocalScript)
    {
        Log-TimedMessage -logMessage ('Executing DVT Script: {0}' -f $dvtLocalScript) -log $log
        $commandArgs = @{
            "InputXML" = $xmlInputPath;
            "Log" = $log
        }

        $output = & $dvtLocalScript @commandArgs *>&1
        Log-TimedMessage -logMessage $output -log $log
    }
    else
    {
        Throw "$dvtLocalScript was not found."
    }
}

function Run-ServiceModelDVT(
    [string]$serviceModelXml,
    [string]$config,
    [string]$serviceModelDirName,
    [string]$dvtScript,
    [array]$dvtHelperScripts,
    [string]$log)
{
    if (-not($config) -and -not($serviceModelXml)) 
    {
        Throw 'Atleast one of config or serviceModelXml parameters required.'
    }

    Log-TimedMessage -logMessage 'Running DVT Process.' -log $log

    # Create DVT local directory
    [string]$dvtLocalBin = CreateDirectoryAndCopy-ScriptsToDVTLocalDir -dvtScript $dvtScript -dvthelperScripts $dvtHelperScripts -log $log

    # Parse service model parameters and create input XML for on demand DVT
    Log-TimedMessage -logMessage 'Parsing service model parameters, and creating input XML' -log $log

    # Parameters from Service Model
    if ($config)
    {
        Log-TimedMessage -logMessage 'Parsing service model params as JSON' -log $log
        Log-Parameter -parameterName 'Input Config string' -parameterValue $config -log $log

        [string]$jsonString = Convert-Base64ToString -base64String $config
        $dvtParams = $jsonString | ConvertFrom-Json
        $serviceName = $dvtParams.ExpectedDVTServiceName
        $appPoolName = $dvtParams.ExpectedDVTAppPoolName
        $appPoolState = $dvtParams.ExpectedDVTAppPoolState
    }
    elseif ($serviceModelXml)
    {
        Log-TimedMessage -logMessage 'Parsing service model params as XML' -log $log

        [xml]$paramXML = Get-Content $serviceModelXml
        $serviceName = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'ExpectedDVTServiceName'
        $appPoolName = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'ExpectedDVTAppPoolName'
        $appPoolState = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'ExpectedDVTAppPoolState'
    }
    else
    {
        Throw ('Unable to parse settings from service model. Config: {0}' -f $config)
    }

    Log-TimedMessage -logMessage ('Parameters: {0} {1} {2}' -f $serviceName, $appPoolName, $appPoolState) -log $log
    [string]$dvtOutputRoot = (Split-Path -Path $dvtLocalBin -Parent)
    [string]$DVTOutputBin = (Join-Path -Path $dvtOutputRoot -ChildPath 'Output')

# DVT input XML Template
[xml]$xmlTemplate = @"
<?xml version="1.0"?>
<DVTParameters xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
<ServiceName>$serviceName</ServiceName>
<AppPoolName>$appPoolName</AppPoolName>
<AppPoolState>$appPoolState</AppPoolState>
<OutputPath>$DVTOutputBin</OutputPath>
</DVTParameters>
"@

    # Calculate Input XML Path
    $xmlInputChildPath =  Get-PathLeafNoFileExtenstion -path $dvtScript
    $xmlInputPath = (Join-Path -Path $dvtLocalBin -ChildPath ('{0}.xml' -f $xmlInputChildPath))
    Log-TimedMessage -logMessage ('Executing DVT XML at: {0}' -f $xmlInputPath) -log $log
    $xmlTemplate.InnerXml | Out-File -FilePath $xmlInputPath -Force -Encoding utf8
    $dvtLocalScript = (Join-Path -Path $dvtLocalBin -ChildPath (Split-Path -Path $dvtScript -Leaf))

    # Execute DVT Script
    Execute-DVTScript -dvtLocalScript $dvtLocalScript -log $log -xmlInputPath $xmlInputPath
}

function Run-ServiceModelRetailHQConfigurationDVT(
    [string]$serviceModelXml,
    [string]$config,
    [string]$serviceModelDirName,
    [string]$dvtScript,
    [array]$dvtHelperScripts,
    [string]$log)
{
    if(-not($config) -and -not($serviceModelXml)) 
    {
        Throw 'Atleast one of config or serviceModelXml parameters required'
    }

    Log-TimedMessage -logMessage 'Running DVT Process' -log $log

    # Create DVT local directory
    [string]$dvtLocalBin = CreateDirectoryAndCopy-ScriptsToDVTLocalDir -dvtScript $dvtScript -dvthelperScripts $dvtHelperScripts -log $log

    # Parse service model parameters and create input XML for on demand DVT
    Log-TimedMessage -logMessage 'Parsing service model parameters, and creating input XML' -log $log
       
    # Parameters from Service Model
    if($config)
    {
        Log-TimedMessage -logMessage 'Parsing service model params as JSON' -log $log
        Log-Parameter -parameterName 'Input Config string' -parameterValue $config -log $log

        [string]$jsonString = Convert-Base64ToString -base64String $config
        $dvtParams = $jsonString | ConvertFrom-Json
        [string]$retailServerUrl = $dvtParams.RetailServerUrl
        [string]$AosDatabaseName = $dvtParams.AosDatabaseName
        [string]$AosDatabaseServer = $dvtParams.AosDatabaseServer
        [string]$aosDatabaseUser = $dvtParams.AosDatabaseUser
        [string]$aosDatabasePass = $dvtParams.AosDatabasePass
    }
    elseif($serviceModelXml)
    {
        Log-TimedMessage -logMessage 'Parsing service model params as XML' -log $log

        [xml]$paramXML = Get-Content $serviceModelXml
        [string]$retailServerUrl = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'RetailServerUrl'
        [string]$AosDatabaseName = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'AosDatabaseName'
        [string]$AosDatabaseServer = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'AosDatabaseServer'
        [string]$aosDatabaseUser = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'AosDatabaseUser'
        [string]$aosDatabasePass = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'AosDatabasePass'
    }
    else
    {
        Throw ('Unable to parse settings from service model. Config: {0}' -f $config)
    }

    Log-TimedMessage -logMessage ('Parameters: Retail Server Url: {0} , Database Name: {1} , Server Name: {2}' -f $retailServerUrl, $axDbName, $axDbServer) -log $log
    [string]$dvtOutputRoot = (Split-Path -Path $dvtLocalBin -Parent)
    [string]$DVTOutputBin = (Join-Path -Path $dvtOutputRoot -ChildPath "output")

# DVT input XML Template
[xml]$xmlTemplate = @"
<?xml version="1.0"?>
<DVTParameters xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
<RetailServerUrl>$retailServerUrl</RetailServerUrl>
<AxDbName>$AosDatabaseName</AxDbName>
<AxDbServer>$AosDatabaseServer</AxDbServer>
<AosDatabaseUser>$aosDatabaseUser</AosDatabaseUser>
<AosDatabasePass>$aosDatabasePass</AosDatabasePass>
<OutputPath>$DVTOutputBin</OutputPath>
</DVTParameters>
"@

    # Calculate Input XML Path
    $xmlInputChildPath =  Get-PathLeafNoFileExtenstion -path $dvtScript
    $xmlInputPath = (Join-Path -Path $dvtLocalBin -ChildPath ('{0}.xml' -f $xmlInputChildPath))
    Log-TimedMessage -logMessage ('Executing DVT XML at: {0}' -f $xmlInputPath) -log $log
    $xmlTemplate.InnerXml | Out-File -FilePath $xmlInputPath -Force -Encoding utf8
    $dvtLocalScript = (Join-Path -Path $dvtLocalBin -ChildPath (Split-Path -Path $dvtScript -Leaf))

    # Execute DVT Script
    Execute-DVTScript -dvtLocalScript $dvtLocalScript -log $log -xmlInputPath $xmlInputPath
}

function Run-NonWebServiceBasedServiceModelDVT(
    [string]$serviceModelXml,
    [string]$config,
    [string]$serviceModelDirName,
    [string]$dvtScript,
    [array]$dvtHelperScripts,
    [string]$log)
{
    if (-not($config) -and -not($serviceModelXml)) 
    {
        Throw 'Atleast one of config or serviceModelXml parameters required.'
    }

    Log-TimedMessage -logMessage 'Running DVT Process.' -log $log

    # Create DVT local directory
    [string]$dvtLocalBin = CreateDirectoryAndCopy-ScriptsToDVTLocalDir -dvtScript $dvtScript -dvthelperScripts $dvtHelperScripts -log $log

    # Parse service model parameters and create input XML for on demand DVT
    Log-TimedMessage -logMessage 'Parsing service model parameters, and creating input XML' -log $log

    # Parameters from Service Model
    if ($config)
    {
        Log-TimedMessage -logMessage 'Parsing service model params as encoded JSON.' -log $log
        Log-Parameter -parameterName 'Input Config string' -parameterValue $config -log $log
        
        $decodedConfig = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($config))
        $settings = ConvertFrom-Json $decodedConfig
        $aosWebsiteName = $settings.AOSWebsiteName
    }
    elseif ($serviceModelXml)
    {
        Log-TimedMessage -logMessage 'Parsing service model params as XML' -log $log

        [xml]$paramXML = Get-Content $serviceModelXml
        $aosWebsiteName = Get-ServiceModelParameterValue -ServiceModelXml $paramXML -XPath '//Configuration/Setting' -ParamName 'AOSWebsiteName'
    }
    else
    {
        Throw ('Unable to parse settings from service model. Config: {0}' -f $config)
    }

    Log-Parameter -parameterName 'AOS Website Name' -parameterValue $aosWebsiteName -log $log
    [string]$dvtOutputRoot = (Split-Path -Path $dvtLocalBin -Parent)
    [string]$DVTOutputBin = (Join-Path -Path $dvtOutputRoot -ChildPath 'Output')

# DVT input XML Template
[xml]$xmlTemplate = @"
<?xml version="1.0"?>
<DVTParameters xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
<ServiceName>$serviceName</ServiceName>
<AOSWebsiteName>$aosWebsiteName</AOSWebsiteName>
<OutputPath>$DVTOutputBin</OutputPath>
</DVTParameters>
"@

    # Calculate Input XML Path
    $xmlInputChildPath =  Get-PathLeafNoFileExtenstion -path $dvtScript
    $xmlInputPath = (Join-Path -Path $dvtLocalBin -ChildPath ('{0}.xml' -f $xmlInputChildPath))
    Log-TimedMessage -logMessage ('Executing DVT XML at: {0}' -f $xmlInputPath) -log $log
    $xmlTemplate.InnerXml | Out-File -FilePath $xmlInputPath -Force -Encoding utf8
    $dvtLocalScript = (Join-Path -Path $dvtLocalBin -ChildPath (Split-Path -Path $dvtScript -Leaf))

    # Execute DVT Script
    Execute-DVTScript -dvtLocalScript $dvtLocalScript -log $log -xmlInputPath $xmlInputPath
}

function Create-TestResultXML(
    [string]$testName,
    [System.Object]$TestResult,
    [string]$xmlFilePath,
    [string]$logFile)
{
    # Diagnostics Collector XML Template
[xml]$dvtOutputXmlTemplate = @"
<?xml version="1.0"?>
<CollectionResult xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <CollectorName>$collectorName</CollectorName>
    <CollectorType>$collectorType</CollectorType>
    <ErrorMessages />
    <TabularResults>
    <TabularData>
        <TargetName>$targetName</TargetName>
        <Columns>
        <string>TestName</string>
        <string>TestType</string>
        <string>PassResult</string>
        <string>RawResult</string>
        <string>TimeStamp</string>
        </Columns>
        <Rows>
        </Rows>
    </TabularData>
    </TabularResults>
</CollectionResult>
"@
    $logMessage = 'Append-RowToTestResultsXml -TestName {0} -TestType DVT -TestResult {1} -RawResult {2} -TimeStamp {3}' -f $testName, $testResult.Result, $testResult.RawResults, $testResult.TimeStamp
    Log-TimedMessage -logMessage $logMessage -log $logFile 

    Append-RowToTestResultsXml -TestName $testName `
                               -TestType 'DVT' `
                               -TestResult $testResult.Result `
                               -RawResult $testResult.RawResults `
                               -TimeStamp $testResult.TimeStamp `
                               -dvtOutputXmlTemplate $dvtOutputXmlTemplate `
                               -log $logFile | Out-Null

    #Writing XML results
    Log-TimedMessage -logMessage ('Writing DVT results to {0}' -f $xmlFilePath) -log $logFile
    $dvtOutputXmlTemplate.InnerXml | Out-File -FilePath $xmlFilePath -Force -Encoding utf8
}

function Report-TestResults(
    [string]$testName,
    [System.Object]$TestResult,
    [string]$xmlFilePath,
    [string]$logFile)
{
    Create-TestResultXML -testName $testName -TestResult $testResult -xmlFilePath $xmlFilePath -logFile $logFile
    [bool]$dvtResult = $testResult.Result

    if ($dvtResult)
    {
        $exitProperties = @{'ExitCode'= 0}
        $exitObject = New-Object PsObject -Property $exitProperties
        Log-TimedMessage -logMessage ('Service Model {0} DVT script completed, ExitCode: {1}' -f $serviceModelName, $exitObject.ExitCode) -log $logFile
        return $exitObject
    }
    else
    {
        $exitProperties = @{
            'ExitCode'= 1;
            'Message'= ('Service Model {0} DVT Validation failed, see log: {1} for further details, and {2} for test results' -f $serviceModelName, $logFile, $xmlFilePath)
        }
        $exitObject = New-Object PsObject -Property $exitProperties
        Log-TimedMessage -logMessage ('Service Model {0} DVT Script Completed, ExitCode: {1}' -f $serviceModelName, ($exitObject.ExitCode)) -log $logFile
        throw $exitObject
    }
}

function Execute-ServiceModelPostDeploymentValidation(
    [string]$serviceModelName,
    [string]$retailServerUrl = $(throw 'Retail Server Url is required'),
    [string]$axDbName = $(throw 'AxDB name is required'),
    [string]$axDbServer = $(throw 'AxDB Server is required'),
    [string]$aosDatabaseUser = $(throw 'AOS Database Username is required'),
    [string]$aosDatabasePass = $(throw 'AOS Database Password is required'),
    [string]$logFile,
    [string]$xmlFilePath = $(throw 'XML file path is required'))
{
    # Post Deployment Retail Server EndPoint Validation
    $testName = $serviceModelName + '.PostDeploymentRetailServer-EndPointValidation'

    $retailHQPostDeploymentValidationResult = Validate-RetailHQPostDeployment -retailServerUrl $retailServerUrl `
        -axDbName $axDbName `
        -axDbServer $axDbServer `
        -aosDatabaseUser $aosDatabaseUser `
        -aosDatabasePass $aosDatabasePass `
        -logFile $logFile

    # Reports the test results in an xml and returns the results object
    Report-TestResults -testName $testName -TestResult $retailHQPostDeploymentValidationResult -xmlFilePath $xmlFilePath -logFile $logFile
}

function Execute-ServiceModelAppPoolDVT(
    [string]$serviceModelName,
    [string]$appPoolName,
    [string]$appPoolState,
    [string]$logFile,
    [string]$xmlFilePath)
{
    # IIS AppPool Validation
    $testName = $serviceModelName + '.Validate-AppPool'

    $logMessage = 'Validate-AppPool -AppPoolName {0} -expectedState {1}' -f $appPoolName, $appPoolState
    Log-TimedMessage -logMessage $logMessage -log $logFile 

    $appPoolResult = Validate-AppPool -AppPoolName $appPoolName -expectedState $appPoolState -logFile $logFile

    # Reports the test results in an xml and returns the results object
    Report-TestResults -testName $testName -TestResult $appPoolResult -xmlFilePath $xmlFilePath -logFile $logFile
}

function Validate-RegistryEntry(
    [string]$registryPath,
    [string]$registryKey,
    
    [string]$expectedRegistryValue,
    [switch]$ensureRegistryValueIsValidPath,

    [string]$logFile)
{
    [bool]$isValidationSuccessful = $false

    try
    {
        Log-TimedMessage -logMessage ('Validating existence of registry Key: {0}' -f $registryPath) -log $logFile
        
        # Check if registry path is valid.
        $isValidationSuccessful = Test-Path -Path $registryPath
        $rawResult = 'Registry path = {0} ;' -f $registryPath
        
        if ($isValidationSuccessful)
        {
            # Get the registry key value.
            $actualRegistryValue = (Get-ItemProperty -Path $registryPath -Name $registryKey -ErrorAction SilentlyContinue).$registryKey
            
            Log-TimedMessage -logMessage ('Actual registry value is {0}.' -f $actualRegistryValue) -log $logFile
            $rawResult += 'Actual registry value = {0} ;' -f $actualRegistryValue
            
            # If the registry key value is null, then validation fails.
            if (-not($actualRegistryValue))
            {
                $isValidationSuccessful = $false
            }
            else
            {
                # Validate the registry value if expected to be a valid path.
                if ($ensureRegistryValueIsValidPath)
                {
                    $isValidationSuccessful = Test-Path -Path $actualRegistryValue
                    $rawResult += 'Ensuring registry value is a valid path = {0} ;' -f $isValidationSuccessful
                    
                    Log-TimedMessage -logMessage ('Validation result of registry value {0} as valid path is {1}' -f $actualRegistryValue, $isValidationSuccessful) -log $logFile
                    
                }
                
                # Validate the registry value if expected registry value is not NULL.
                if ($expectedRegistryValue)
                {
                    $isValidationSuccessful = $expectedRegistryValue -eq $actualRegistryValue
                    $rawResult += 'Expected registry value = {0}; Expected registry value validation result = {1}' -f $expectedRegistryValue, $isValidationSuccessful
                    
                    Log-TimedMessage -logMessage ('Validation result for comparison of registry value {0} to expected value {1} is {2}' -f $actualRegistryValue, $expectedRegistryValue, $isValidationSuccessful) -log $logFile
                }
            }
        }
        else
        {
            Log-TimedMessage -logMessage ('Registry path {0} is invalid.' -f $registryPath) -log $logFile
        }
    }
    catch
    {
        Log-Exception -exception $_ -log $logFile
    }

    if ($isValidationSuccessful)
    {
        $returnProperties = @{
            Result=1;
            RawResults=$rawResult;
            TimeStamp= Get-TimeStamp
        }
    }
    else
    {
        $returnProperties = @{
            Result=0;
            RawResults=$rawResult;
            TimeStamp= Get-TimeStamp
        }
    }
    
    $resultObject = New-Object PsObject -Property $returnProperties
    return $resultObject
}

function Execute-RegistryValidationDVT(
    [string]$registryPath,
    [string]$registryKey,
    
    [string]$expectedRegistryValue,
    [switch]$ensureRegistryValueIsValidPath,
    
    [string]$serviceModelName,
    [string]$logFile,
    [string]$xmlFilePath)
{
    $testName = '{0}.Validate-RegistryEntry' -f $serviceModelName
    
    $logMessage = 'Validate-RegistryEntry -registryPath {0} -registryKey {1} -expectedRegistryValue {2} -logFile {3} -xmlFilePath {4}' -f $registryPath, $registryKey, $expectedRegistryValue, $logFile, $xmlFilePath

    if ($ensureRegistryValueIsValidPath)
    {
        $logMessage += '-ensureRegistryValueIsValidPath'
    }
    
    Log-TimedMessage -logMessage $logMessage -log $logFile 

    if ($ensureRegistryValueIsValidPath)
    {
        $testExecutionResults = Validate-RegistryEntry -registryPath $registryPath `
                                                       -registryKey $registryKey `
                                                       -expectedRegistryValue $expectedRegistryValue `
                                                       -ensureRegistryValueIsValidPath `
                                                       -logFile $logFile
    }
    else
    {
        $testExecutionResults = Validate-RegistryEntry -registryPath $registryPath `
                                                       -registryKey $registryKey `
                                                       -expectedRegistryValue $expectedRegistryValue `
                                                       -logFile $logFile
    }

    # Reports the test results in an xml and returns the results object
    Report-TestResults -testName $testName -TestResult $testExecutionResults -xmlFilePath $xmlFilePath -logFile $logFile
}

Export-ModuleMember -Function Append-RowToTestResultsXml
Export-ModuleMember -Function Convert-Base64ToString
Export-ModuleMember -Function CreateDirectoryAndCopy-ScriptsToDVTLocalDir
Export-ModuleMember -Function Execute-DVTScript
Export-ModuleMember -Function Execute-RegistryValidationDVT
Export-ModuleMember -Function Execute-ServiceModelAppPoolDVT
Export-ModuleMember -Function Execute-ServiceModelPostDeploymentValidation
Export-ModuleMember -Function Get-ServiceModelParameterValue 
Export-ModuleMember -Function Get-TimeStamp
Export-ModuleMember -Function Handle-DvtError
Export-ModuleMember -Function Log-Exception
Export-ModuleMember -Function Log-TimedMessage
Export-ModuleMember -Function New-DirectoryIfNotExists
Export-ModuleMember -Function Run-NonWebServiceBasedServiceModelDVT
Export-ModuleMember -Function Run-ServiceModelDVT
Export-ModuleMember -Function Run-ServiceModelRetailHQConfigurationDVT
Export-ModuleMember -Function Validate-AppPool



# SIG # Begin signature block
# MIIjoAYJKoZIhvcNAQcCoIIjkTCCI40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBcRLKcdp6uHrwB
# 8Y6yqniZcKPOPjLjq4MrNOee0mQM6qCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdTCCFXECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgKs0Yeulc
# Bat5vEJAj8ua0CimFaVQfKDPj00sqqusj/EwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAAZydla3
# cq9bpi1RqP1LV6PB+Nzr/XVUnN2zEvPfnA3xl/h4o/HaA3b8LdwOT921duVCMXQP
# YykYsCR5BsUu0k+MWwBwifaDFiBMNMOVnQq14KchaZ8DgyI82XBWQwDc443oJRif
# Xqbiwfnyqq2CGiL8sZW6nR2v1ruAWTAGhpteAe2VXz8FPa7S+01dDC7bh4RjABUr
# ruYdyrugEuaTdp0OKPKgQXM3SlA2LS+Ttto5suSzKpstOo8kWI372mmlMqAbDmAh
# BX6wU3wBZqPq0mXnDfg7OPBmEzZZAXXu5qvW9TKYZbFITpV+bJ+DpjVTuHLgTMDE
# 4VQmIURH58C4sKKhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0B
# BwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgwA5O
# EKfrBFbTwQJh3X1vb00AneIgDziBo1anBzi0EPgCBl1gildCfBgTMjAxOTA4Mjcw
# NzIzMzcuNDI2WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAANmqlgpRy5tL5gAAAAAA2TANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTJaFw0xOTExMjMy
# MDI2NTJaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAK4ui9Kjs3PXoxuSwLEk9YGfAovIVOp97Ss2P/YptQwd4LZIDTX1kur85PbI
# ce9W8O/wAmjU+p9vKiaXky74WfLth7lXztHz5EHeTqbGBIOqe5+zfDYRAqVlP4cR
# 6/GrKRSAxUiKrLSK4mQfl1bCTKEPToTTK39B4o1PqKx3e9DrW43zrcKcnEZ0IcEO
# 1FXpuhgyHcWmQY02KaTcYQxXddS+p5RbPgmk4QsPeQvhiLU9GaNJFnXopszlXwKD
# lNvivsxvx8bgVCXkiM2uhCDng2Cm4Pij2+jUjl3bCZd4KDmOklzgM2R/RpuhhwOn
# qzUNyb9X6mFMPRCD5JkYp0utxH0CAwEAAaOCARswggEXMB0GA1UdDgQWBBRQ651G
# Zqfcnx2nzjdoZHelFBuOPTAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQCeaDes
# 2uzE06QMWFAvYUpRNcicfeNJRJif1z4934nQkuhDK78ZwRCSGKpkocINNl0/+L6b
# BjfW+CY0BZ2Fz/lKzkw9PTMJYuyr0UL1D+KAklPQKmejzJyDBeLNWQrovNuKFEOx
# hRbTXo993dUDEQztuL9uwNjvzlfgQOKvH3WbEjb0GZMDysH3kFR9hrcYRT0ZiX/3
# hUgW3F3HbxRNpHA+d2fTbz9Ep7absJtkzQ2BOX8/WB1LV02BEEx/cLhHcRMisv3I
# DF+0QBgNUVWwPgjnFJEMAWKoLmzZ6WKad9MhyXRKASH50s1RGQ+4lrENFYPHdFST
# pHqmqvs0DLyXpoGCMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC//EreiaQMh6prbQbz
# f59LukktoaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q79TjAiGA8yMDE5MDgyNzA4NTIzMFoYDzIwMTkwODI4
# MDg1MjMwWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhDv1OAgEAMAoCAQACAhvu
# AgH/MAcCAQACAhF/MAoCBQDhEE7OAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAoGa7jwIZeYfyKfp8C+tor8cduARzz63SFNy83IVv/Rv5H/93dJkMBJV8T1IR
# MxRhP31RgverndrDhuHVPnUONFd/sDcPJK4GAQURHzdivj63h4rP149GuGCm9S88
# yV3cp3Ydfn7h5mud3/R2dmZSQD/6MX5Y75qvjSXAa7AHXXcxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANmqlgpRy5tL5gAA
# AAAA2TANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCBEBFXlRAA/G+8ebI64Z0vASrOzg4VGJ9h6TlId
# OEV/GzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINIsifIfKK2PQTe/ypSm
# yxPoEvAiCgjnk0WIaC0O2pNxMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAADZqpYKUcubS+YAAAAAANkwIgQgmAYBoqCCaOkCIZLJ+IIY
# YsJwJZ9QFK83Vem1P4B/P/wwDQYJKoZIhvcNAQELBQAEggEAmHh1mTGKsUWQbs/2
# bl5xYP7SrugX+JaiiBKS/5y6WzghLCLqb08ohJ1rZLaJmPXpndLSWAc88QkDbjtb
# FgP3zKg/qIpT3KRgZkjAHa9ySPX/5k15qeifWN9/zdGnoq0KbeT2Kq1XN2uYLCx7
# MsdtaTFJVsy677QiPpMc++qdClJkEL+Kf7T8Mj3dFY4stslPNQsZS9RblSl3s7f6
# E4hHyS45tEfNez5+1UrXrFtPbMdqipAUm091qQ9vA495KLmzDMHqT49oMZEqCJ8Z
# I+q9nZne0njfDFQUDARhz+/g0nk5li7xWp4B/VQdRanTn4MnVfbRWIDh29k66i4W
# enPKKQ==
# SIG # End signature block
