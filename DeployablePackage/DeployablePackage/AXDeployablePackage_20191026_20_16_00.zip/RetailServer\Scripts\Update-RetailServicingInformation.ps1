﻿<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$RetailChannelDbServerName,
    [Parameter(Mandatory=$true)]
    [string]$RetailChannelDbName,
    
    [PSCredential]$AxDeployUserCredential = (Get-Credential -UserName "axdeployuser" -Message "Enter credentials for axdeployuser"),
    
    [PSCredential]$AxDeployextUserCredential = (Get-Credential -UserName "axdeployextuser" -Message "Enter credentials for axdeployextuser"),
    
    [ValidateNotNullOrEmpty()]
    [string]$AosWebsiteName = 'AOSService',
    [ValidateNotNullOrEmpty()]
    [string]$RetailServerWebsiteName = 'RetailServer',
    [ValidateNotNullOrEmpty()]
    [string]$RetailCloudPosWebsiteName = 'RetailCloudPos',
    [ValidateNotNullOrEmpty()]
    [string]$RetailStorefrontWebsiteName = 'RetailStorefront'
)

Import-Module WebAdministration

$AXConfigEncryptorPath = "bin\Microsoft.Dynamics.AX.Framework.ConfigEncryptor.exe"

function Set-UseDatabaseCredentialInWebConfigForUpgrade
{
    $targetRegistryKeyPath = "HKLM:\SOFTWARE\Microsoft\Dynamics\7.0\RetailChannelDatabase"
    if(-not (Test-Path -Path $targetRegistryKeyPath))
    {
        New-Item -Path $targetRegistryKeyPath -ItemType Directory -Force | Out-Null
    }
    New-ItemProperty -Path $targetRegistryKeyPath -Name 'UseDatabaseCredentialInWebConfigForUpgrade' -Value 'true' -Force | Out-Null
}

function Invoke-AxConfigEncryptorUtility(
    [ValidateNotNullOrEmpty()]
    [string]$AxEncryptionToolPath,
    [ValidateNotNullOrEmpty()]
    [string]$WebConfigPath,
    [ValidateNotNullOrEmpty()]
    [ValidateSet("Encrypt","Decrypt")]
    [string]$Operation
    )
{
    if(-not (Test-Path $AxEncryptionToolPath))
    {
        throw "$AxEncryptionToolPath is not found."
    }
    if(-not (Test-Path $WebConfigPath))
    {
        throw "$WebConfigPath is not found."
    }
    $Global:LASTEXITCODE = 0
    switch($Operation)
    {
        'Encrypt' { & $AxEncryptionToolPath -encrypt $webConfigPath }
        'Decrypt' { & $AxEncryptionToolPath -decrypt $webConfigPath }
    }
    $exitCode = $Global:LASTEXITCODE

    if($exitCode -eq 0)
    {
        Write-Host "$AxEncryptionToolPath completed successfully."
    }
    else
    {
        Write-Warning "$AxEncryptionToolPath failed with exit code: $exitCode"
    }
}

function Update-ChannelDatabaseServicingInformation(
    [ValidateNotNullOrEmpty()]
    [string]$WebConfigPath,
    [ValidateNotNullOrEmpty()]
    [string]$AosWebsiteName,
    [ValidateNotNullOrEmpty()]
    [string]$DbServer,
    [ValidateNotNullOrEmpty()]
    [string]$DbName,
    [ValidateNotNullOrEmpty()]
    [string]$DeployUser,
    [ValidateNotNullOrEmpty()]
    [string]$DeployUserPassword,
    [ValidateNotNullOrEmpty()]
    [string]$DeployExtUser,
    [ValidateNotNullOrEmpty()]
    [string]$DeployExtUserPassword)
{
    [xml]$targetConfigXml = Get-Content $webConfigPath
    $DataEncryptionCertificateThumbprint = $targetConfigXml.configuration.retailServer.cryptography.certificateThumbprint
    
    if($DataEncryptionCertificateThumbprint -eq $null)
    {
        throw 'cannot find data encryption certificate thumbprint from configuration.retailServer.cryptography.certificateThumbprint in RetailServer web.config.'
    }
    
    $appSettings = @{
        'DataAccess.DataEncryptionCertificateThumbprint' = $DataEncryptionCertificateThumbprint
        'DataAccess.DataSigningCertificateThumbprint' = $DataEncryptionCertificateThumbprint
        'CertificateHandler.HandlerType' = 'Microsoft.Dynamics.AX.Configuration.CertificateHandler.LocalStoreCertificateHandler'
        'DataAccess.encryption' = 'true'
        'DataAccess.disableDBServerCertificateValidation' = 'false'
        'DataAccess.Database' = $dbName
        'DataAccess.DbServer' = $dbServer
        'DataAccess.SqlUser' = $deployExtUser
        'DataAccess.SqlPwd' = $deployExtUserPassword
        'DataAccess.AxAdminSqlUser' = $deployUser
        'DataAccess.AxAdminSqlPwd' = $deployUserPassword
    }
    
    foreach ($setting in $appSettings.GetEnumerator()) 
    {
        # Only add a new element if one doesn't already exist.
        if($setting.Value)
        {
            $configElement = $targetConfigXml.configuration.appSettings.add | ?{ $_.key -eq $setting.Name }
            if ($configElement -eq $null)
            {
                $configElement = $targetConfigXml.CreateElement('add')
                $xmlKeyAtt = $targetConfigXml.CreateAttribute("key")
                $xmlKeyAtt.Value = $setting.Name
                $configElement.Attributes.Append($xmlKeyAtt) | Out-Null
                $xmlValueAtt = $targetConfigXml.CreateAttribute("value")
                $xmlValueAtt.Value = $setting.Value
                $configElement.Attributes.Append($xmlValueAtt) | Out-Null
                $targetConfigXml.configuration.appSettings.AppendChild($configElement) | Out-Null
            }
            else
            {
                $configElement.value = $setting.Value
            }
        }
    }

    $targetConfigXml.Save($webConfigPath)
}

Write-Host "Validating parameters."
Write-Host "Validating database credentials."
if(($AxDeployUserCredential -eq $null) -or ($AxdeployextUserCredential -eq $null))
{
    Write-Warning "Credentials for axdeployuser and axdeployextuser cannot be null."
    throw "Credentials for axdeployuser and axdeployextuser cannot be null."
}

$axdeployuserUsername = $AxDeployUserCredential.UserName
$axdeployuserPassword = $AxDeployUserCredential.Password
$axdeployuserBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($axdeployuserPassword)
$axdeployuserPlainPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($axdeployuserBSTR)

$axdeployextuserUsername = $AxdeployextUserCredential.UserName
$axdeployextuserPassword = $AxdeployextUserCredential.Password
$axdeployextuserBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($axdeployextuserPassword)
$axdeployextuserPlainPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($axdeployextuserBSTR)

if([String]::IsNullOrWhiteSpace($axdeployuserUsername) -or [String]::IsNullOrWhiteSpace($axdeployuserPlainPassword) `
    -or [String]::IsNullOrWhiteSpace($axdeployextuserUsername) -or [String]::IsNullOrWhiteSpace($axdeployextuserPlainPassword) )
{
    Write-Warning "You must provide username and password for axdeployuser and axdeployextuser."
    throw "You must provide username and password for axdeployuser and axdeployextuser."
}

Write-Host "Validation is done for database credentials."

Write-Host "Validating state of the environment."

Write-Host "Validating RetailServer website."
$retailServerWebsite = Get-Website -Name $RetailServerWebsiteName

if($retailServerWebsite -eq $null)
{
    Write-Warning "Cannot find retail server website with name $RetailServerWebsiteName"
    throw "Cannot find retail server website with name $RetailServerWebsiteName"
}

$retailServerWebConfigFilePath = Join-Path $retailServerWebsite.physicalPath 'web.config'

if(-not(Test-Path -Path $retailServerWebConfigFilePath))
{
    Write-Warning "Cannot find retail server web.config with path $retailServerWebConfigFilePath"
    throw "Cannot find retail server web.config with path $retailServerWebConfigFilePath"
}

if((Get-ItemProperty $retailServerWebConfigFilePath -Name IsReadOnly).IsReadOnly)
{
    throw "$retailServerWebConfigFilePath is set to read only, please update the file attribute and retry."
}

Write-Host "Validation is done for RetailServer website."

Write-Host "Validating AOS website."
$aosWebsite = Get-Website -Name $AosWebsiteName

if($aosWebsite -eq $null)
{
    Write-Warning "Cannot find AOS website with name $AosWebsiteName"
    throw "Cannot find AOS website with name $AosWebsiteName"
}

$aosWebPath = $aosWebsite.physicalPath
$axConfigEncryptorUtilityPath = Join-Path $aosWebPath $AXConfigEncryptorPath
if(-not (Test-Path $axConfigEncryptorUtilityPath))
{
    throw "$axConfigEncryptorUtilityPath is not found."
}

Write-Host "Validation is done for AOS website."

# Backup Retail Server web.config first
Write-Host "Backup RetailServer website."
$dateString = Get-Date -format 'yyyy-MM-dd-HH-mm-ss'
$backupFolder = Join-Path (Split-Path $retailServerWebsite.physicalPath) "Backup_$dateString"
Copy-Item -Path $retailServerWebsite.physicalPath -Destination $backupFolder -Recurse

try
{
    Write-Host "Decrypt RetailServer web.config"
    Invoke-AxConfigEncryptorUtility -AxEncryptionToolPath $axConfigEncryptorUtilityPath -WebConfigPath $retailServerWebConfigFilePath -Operation 'Decrypt'

    Write-Host "Updating servicing information."
    Update-ChannelDatabaseServicingInformation -WebConfigPath $retailServerWebConfigFilePath `
                                         -AosWebsiteName $AosWebsiteName `
                                         -DbServer $RetailChannelDbServerName `
                                         -DbName $RetailChannelDbName `
                                         -DeployUser $axdeployuserUsername `
                                         -DeployUserPassword $axdeployuserPlainPassword `
                                         -DeployExtUser $axdeployextuserUsername `
                                         -DeployExtUserPassword $axdeployextuserPlainPassword
                                         
    Set-UseDatabaseCredentialInWebConfigForUpgrade
    Write-Host "Retail servicing information has been updated successfully."
}
catch
{
    $message = ($global:error[0] | format-list * -f | Out-String)
    Write-Host $message
    throw $_
}
finally
{
    Invoke-AxConfigEncryptorUtility -AxEncryptionToolPath $axConfigEncryptorUtilityPath -WebConfigPath $retailServerWebConfigFilePath -Operation 'Encrypt'
}
# SIG # Begin signature block
# MIIjnQYJKoZIhvcNAQcCoIIjjjCCI4oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAEkwzF7xJB/L85
# TOnExsR/6rv0kVNQe8h30ACoLWl4QqCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVcjCCFW4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgYZ2WZAQs
# gzWIfxoGk+1kbcfBTXFnn1edoXSm7uB1QNswXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAHWsc15p
# 4TfRlTmE6PMoH1B/sa8jhlgyfuZCOAYFFv/Gb964q86jy6BFyneylNKE2AVwLNm3
# LdzVT1/sZ8336OvSDJGDvwH/vyU8MTGBrnuFFbuiyBShHBbZsDkCvVUJXmz7ERek
# f0gjOYKHox0OYKW195x5o0Q69vqr+lNYIsYdhHh1GDnCpUp9A+EY1jffgvoA+9wu
# TR9WfY1PZyTbHQAAzN6abwy/ytj+507+JufCnG+TH0xBCAGqm0DaydCESK7iuhMn
# CrQmi1dJGWePi/NRQM58CFdrabIxLUlpD6cbHVk/6yMVbsomEt9II7X2pwM3od+u
# SoONFxDIY+4ivLKhghLiMIIS3gYKKwYBBAGCNwMDATGCEs4wghLKBgkqhkiG9w0B
# BwKgghK7MIIStwIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgMf8o
# P21nMA93QvJ46sd/Qlxvuv2cpoFdJ0v23Vy0ReICBl1exl4mKxgTMjAxOTA4Mjcw
# NzIzMzQuODQ2WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00QkIwLTgyNDYxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg45MIIE8TCCA9mg
# AwIBAgITMwAAANuqbeMifzQAJQAAAAAA2zANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTNaFw0xOTExMjMy
# MDI2NTNaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKehmpAMmCSLSzZuzf07rE9UXP5TCqLREDDOqiAw3pa5kSYKdRAwnQmvAw4l
# FA2cTfCLjFL9znS3+J+8CWG2iynHEIirVgkDr6nG18H28rvG7djdoROqHWNmY8yz
# P3YF+kiIv5Rq7gfXYCYsb+0yG37xgW6DfSLHBN8oJq0GZ3c75J4SiGViIF/3tolU
# P2s9I+UpZSGsOR2lRQyxBhTTdavvriKURstRz3PA//P/rC08j5GpNfzft9Sq5TjK
# UPkXvT+uRGHordY6sdaxCqLjvoEYYo2NDKLCXEPC3m8LBSK7WV0CTSwj3AqJNC/s
# ehs2+i3ZF29kczH1itOzJS+qTQsCAwEAAaOCARswggEXMB0GA1UdDgQWBBSyut8d
# gFxzps227eQcjK3eKkMDSDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAVQsKa
# nb0ZYH4iR4kk6YGV1V5uV2NRm/pH7JeTWTFMWGkgFQH9AJkU5E+uEfLgjrdQMq/N
# ycE4QIq0cb0HVnYOKPGnivFDhmadZH1aBQWQf/DlviyHGhID9faqntPOAtm51jAG
# vno7H4xGzd7SzmsvA9hgw9zrdsiCtkx1s5uCPcVFdEAFi+oS9NLk2NFC5utPK6JH
# ONLkFNDpBBYsv5Pd1D2DyY1JPgShshDRr/UxV4bcM+EHGMKXRmeuwMAdEYk+3a3q
# MopMRt9sZIrIo3H6w23Q7LREZqlcuBrMXxT8pOXlUqUfWFi/j3vr8hoP8EJzHJZR
# rkq/cJk6WlRkPSGLMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICyzCCAjQCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjE3OUUtNEJCMC04MjQ2MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBbpSlOrxis+HA8JE9q
# RFutb8fbMKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q8zizAiGA8yMDE5MDgyNzEyNDM1NVoYDzIwMTkwODI4
# MTI0MzU1WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDhDzOLAgEAMAcCAQACAgL/
# MAcCAQACAhF0MAoCBQDhEIULAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQB
# hFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEA
# Y+m4ZZ+zsua4toNhjqjR3iyRFq9wRnhHAk4p++ffJ9kobp4lm+FLGNHzk/+FLX5E
# blnqUn24TaSZ/rzcRFMil0rqbN1boY/m3/72Wi3FTEdx7FjEpcp3iKqUkn3J/SRR
# bhrXaij7TyqkUzRlcotlJMUE+eLuBZKC3f+H6Az4mmAxggMNMIIDCQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANuqbeMifzQAJQAAAAAA
# 2zANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCDLIS24vc3lrARfnTcjb3QNWm/pY2zCpw9OWxFO3amk
# ajCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIAJTHbHTmAEtIrVqIyVjsIt9
# R7biILf8sPry650hjP6qMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAADbqm3jIn80ACUAAAAAANswIgQgDiOaAcmTkHog5c3FOzsDtysK
# XPT7apkfVPqtcVrCxKgwDQYJKoZIhvcNAQELBQAEggEAe8cw2Pos5GLCsyl96i1w
# ojS8nIQ7+eVHL9wgAmtQooEgjmW+Ngzi1SV6rPzGxxwsslKTlIsCP6/AU0OLMzZH
# WopXayIEOecjte/DpNz/vwAyRb0fMrgzpAttiRjrLNWt2OPgrPbaMgeBBsq3xhFS
# NvrUB/nLHONOoZ0Eiy6roMlY1EpGJy70BIH0q0MVL8Rlsl6/enC0RK2rl+U058bU
# mnypGHWqJ4H9+WcyKxm2ZkOzAeWuPN37z49yIQ2t7bU/UN2QCVrtqK9/2+XON9wz
# bainZ61LGZcOOLA3qwkDog+y6H5R5AWfAJCJw7a9sMJnwahWw/wMVGiUDyCDfzsT
# KA==
# SIG # End signature block
