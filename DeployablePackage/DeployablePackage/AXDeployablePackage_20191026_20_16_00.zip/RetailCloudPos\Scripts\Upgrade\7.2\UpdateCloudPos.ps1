<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

<#
.SYNOPSIS
    Allows a user to update Cloud POS deployment.

.DESCRIPTION
    This script provides a mechanism to update existing Cloud POS deployment on a local system.

.PARAMETER RETAILCLOUDPOSWEBSITENAME
    The name of Cloud POS website which is deployed on the local system.

.PARAMETER MINSUPPORTEDVERSION
    An optional parameter to specify the minimum supported build version for Cloud POS service. If the current installed version is less than this then the script will not support update.

.PARAMETER LOGPATH
    Location where all the logs will be stored.

.EXAMPLE 
    # Update the existing Cloud POS deployment with minimum supported version "7.0.0.0". 
    .\UpdateCloudPos.ps1 -MinSupportedVersion "7.0.0.0"
#>

param (
	$RetailCloudPosWebSiteName = 'RetailCloudPos',
	$MinSupportedVersion,
	[string] $LogPath = $env:TEMP
)

$ErrorActionPreference = 'Stop'

function Update-EnvironmentId(
    [ValidateNotNullOrEmpty()]
	[string]$configFilePath = $(throw 'configFilePath is required')
)
{
    # Check if update config.json file contains environment id
    $config = Get-Content $configFilePath
    $configJsonObject = "[ $config ]" | ConvertFrom-JSON

    # Read from registry
    Log-TimedMessage 'Retrieving LCS Environment Id...'
    $envId = Get-LcsEnvironmentId

    if(![string]::IsNullOrWhiteSpace($envId))
    {
        Log-TimedMessage 'Updating LCS Environment Id in config.json...'

        $configJsonObject | Add-Member -MemberType NoteProperty -Name 'EnvironmentId' -Value $envId -Force

        $configJsonObject | ConvertTo-Json | Out-File $configFilePath -Force

        Log-TimedMessage 'Finished updating LCS Environment Id in config.json...'
    }
    else
    {
        # In case of VHD download scenario, Environment Id doesn't exist.
        Log-TimedMessage 'Skip updating LCS Environment Id since it was not set for this environment.'
    }
}

function Upgrade-RetailCloudPOSWebsite(
    [string] $webSiteName = $(throw 'webSiteName is required'),
    [string] $webSitePhysicalPath = $(throw 'webSitePhysicalPath parameter is required'),
    [string] $updatePackageCodeDir =  $(throw 'updatePackageCodeDir parameter is required'),
    [string] $installationInfoXmlPath =$(throw 'installationInfoXmlPath is required'))
{
    # We want to update the deployment in following way:
    # 1. Update all files except "Extensions" when the package is by Microsoft.
    # 2. Update only the "Extensions" and "Connectors" when the package is Customized.

    Log-TimedMessage 'Begin updating Retail Cloud Pos deployment...'

    # Check if Package is released by Microsoft.
    $isMicrosoftPackage = Check-IfUpdatePackageIsReleasedByMicrosoft -installationInfoXml $installationInfoXmlPath

    # Create a temp working folder
    $tempWorkingFolder = Join-Path $env:temp ("{0}_Temp_{1}" -f $webSiteName, $(Get-Date -f yyyy-MM-dd_hh-mm-ss))

    # Copy all the files to a temp location except Extensions if it is a Microsoft update. 
    if($isMicrosoftPackage) 
    { 
        # Get list of all files to be updated
        $fileList = Get-ListOfFilesToCopy -installationInfoXmlPath $installationInfoXmlPath `
                                          -updatePackageCodeFolder $updatePackageCodeDir 
        $fileList | % { 
        Copy-Files -SourceDirPath $updatePackageCodeDir `
                     -DestinationDirPath $tempWorkingFolder `
                     -FilesToCopy $_ `
                     -RobocopyOptions '/S /njs /ndl /np /njh /XD Extensions' #Exclude the Extensions Folder
        }
        Log-TimedMessage 'Checking if config file needs to be merged.'
        if($fileList -contains 'config.json')
        {
            Log-TimedMessage 'Yes.'
        
            # Migrate config.json
            Log-TimedMessage 'Merging config file.'
            $reservedSettings = Get-NonCustomizableConfigSettings
            Merge-JsonFile -sourceJsonFile (Join-Path $webSitePhysicalPath 'config.json') -targetJsonFile (Join-Path $tempWorkingFolder 'config.json') -nonCustomizableConfigSettings $reservedSettings
            Update-EnvironmentId -configFilePath (Join-Path $tempWorkingFolder 'config.json')
        }
    }
    else 
    {
        # Copy only the files in Extensions dir if update is not published by Microsoft.
        $updatePackageCodeDirExtensions= (Join-Path  $updatePackageCodeDir  'Extensions')
        $tempWorkingFolderExtensions= (Join-Path  $tempWorkingFolder  'Extensions')
        $tempWorkingFolderConnectors= (Join-Path  $tempWorkingFolder  'Connectors')
        $updatePackageCodeDirConnectors= (Join-Path  $updatePackageCodeDir  'Connectors')

        Copy-Files -SourceDirPath $updatePackageCodeDirExtensions `
                     -DestinationDirPath $tempWorkingFolderExtensions `
                     -RobocopyOptions '/S /njs /ndl /np /njh'

        Copy-Files -SourceDirPath $updatePackageCodeDirConnectors `
                     -DestinationDirPath $tempWorkingFolderConnectors `
                     -RobocopyOptions '/S /njs /ndl /np /njh'
    }

    # Replace website files from temp working directory to actual working directory
    Replace-WebsiteFiles -webSiteName $webSiteName -newWebFilesPath $tempWorkingFolder

    # Remove the temp working folder
    Log-TimedMessage ('Removing temporary working directory' -f $tempWorkingFolder)
    Remove-Item $tempWorkingFolder -Recurse -Force -ErrorAction SilentlyContinue
    Log-TimedMessage 'Finished updating Retail Cloud Pos deployment...'
}

function Get-NonCustomizableConfigSettings()
{
    $nonCustomizableConfigSettings = @(
    'AppInsightsInstrumentationKey',
    'AADClientId',
    'AADLoginUrl',
    'AdminPrincipalName',
    'EnvironmentId',
    'CommerceAuthenticationAudience',
    'AppInsightsApplicationName',
    'AADRetailServerResourceId',
    'RetailServerUrl')
    
    return $nonCustomizableConfigSettings 
}

try
{
	$ScriptDir = Split-Path -parent $MyInvocation.MyCommand.Path
	. (Join-Path $ScriptDir 'Common-Configuration.ps1')
	. (Join-Path $ScriptDir 'Common-Web.ps1')
	. (Join-Path $ScriptDir 'Common-Upgrade.ps1')

	# Get the service model Code folder from the update package
    Log-TimedMessage 'Getting the Code folder from the deployable update package.'
    $updatePackageCodeDir = (Join-Path (Split-Path (Split-Path (Split-Path $ScriptDir -Parent) -Parent) -Parent) 'Code')
	
	if(!(Check-IfAnyFilesExistInFolder -folderPath $updatePackageCodeDir))
	{
		Log-TimedMessage ('Update Code folder {0} does not exist or is empty. Skipping the update.' -f $updatePackageCodeDir)
		return
	}
	
    Log-TimedMessage ('Found the Code folder from the deployable update package at - {0}.' -f $updatePackageCodeDir)
	
    # Get website physical path.
    Log-TimedMessage ('Getting website physical path for website - {0}' -f $RetailCloudPosWebSiteName)
    $webSitePhysicalPath = Get-WebSitePhysicalPath -webSiteName $RetailCloudPosWebSiteName
    Log-TimedMessage ('Found website physical path - {0}' -f $webSitePhysicalPath)
    
    # Get the installation info manifest file.
    Log-TimedMessage 'Getting installation info XML path.'
    $installationInfoFile = Get-InstallationInfoFilePath -scriptDir $ScriptDir
    Log-TimedMessage ('Found installation info XML path - {0}' -f $installationInfoFile)

    # Upgrade Retail Cloud POS 
    Upgrade-RetailCloudPOSWebsite -webSiteName $RetailCloudPosWebSiteName `
                                  -webSitePhysicalPath $webSitePhysicalPath `
                                  -updatePackageCodeDir $updatePackageCodeDir `
                                  -installationInfoXmlPath $installationInfoFile 
}
catch
{
    Log-Error ($global:error[0] | format-list * -f | Out-String)
    $ScriptLine = "{0}{1}" -f $MyInvocation.MyCommand.Path.ToString(), [System.Environment]::NewLine
    $PSBoundParameters.Keys | % { $ScriptLine += "Parameter: {0} Value: {1}{2}" -f $_.ToString(), $PSBoundParameters[$_.ToString()], [System.Environment]::NewLine}
    Log-TimedMessage ("Executed:{0}$ScriptLine{0}Exiting with error code $exitCode." -f [System.Environment]::NewLine)
    throw ($global:error[0] | format-list * -f | Out-String)
}
# SIG # Begin signature block
# MIIjoAYJKoZIhvcNAQcCoIIjkTCCI40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCArDB42BAoZxyLe
# r02ZBqrmamSd6QBEFNuZRTvvIHit5KCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdTCCFXECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgjZWQRg9h
# rVzuS9xN7KLDz4ozORDuEQbGayN26czhZSQwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAE6WiJcV
# bWTdOVmyttkspDUBDV9x7xuOp9ynQQoYlFU6PjT88IijV0iLKCNrfLnI6ExlKu36
# WZ6+2EUvwjRC8ACzdulHfR2up8tQ1eEG6eISgTCD5/H5qAcPC2nwNbdmYZovT66/
# VDuCa/i6saXp5sOfFs/+fWdufUERGaCQySJa21k4cjssmZX+tM0MF5oxrKcdW/OR
# GTu4oSftGZXDraf6vmfGsA+HTrESH9EHNYpjr8nfxSuFEL4xkRVmk7ipHT8QOWp9
# 3xKMe7MpFPx6b4f6NPeYLROKqrtQQne9MQy31O/rKc8jgseT2XXq8aKbD3Uvgm2v
# W/iqiaiGqjEdpOuhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0B
# BwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgQlvA
# Yzb0WdPiaG1JlnlHOO37sAmtJrasl94VXBD04QYCBl1f8lXMfhgTMjAxOTA4Mjcw
# NzIzMzguMTU4WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RkM0MS00QkQ0LUQyMjAxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAAOGcqCPPPSEhhwAAAAAA4TANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI3MDJaFw0xOTExMjMy
# MDI3MDJaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjpGQzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAJvhrH0LWs8Pa72NDWnSakVkNQXGdlob5H+nmMJfx/haKB7dEtZ69dew01Z5
# cXBCyqGO2Xr4m2Uii/4MGbBcGDrzwdBKMGQJ4oCj/N4f+0zM+RK7BsSYSd9Kvv1j
# CM9aqjvTdJ3a6noaYm+5QufvXMMTZfmhbKa72MnGrs8vtRdOKMBTtYcSSscwHnZM
# MxmuYl04JLuHjTlIBgxoMnjkZc0doBBDNbJipcG11uCZyiEmHegokEn8rx+7LRIM
# 03NaA4XIJBCu9S0o9EKucxH/KV7dnar1WkpG5MsqOyTFokIac4HH7bIIQQgfcPsr
# Jqxo6m9Unov6RpQvLJJt0Jhv9x0CAwEAAaOCARswggEXMB0GA1UdDgQWBBT/Alut
# aLbKjm+FAs/F5FwNXsi4PDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAbcQlO
# 2+9iK1sqSyxFYSRuJxqHjMDRTKi+ZnVjNNGMUfYwlyaJn6ntWPz7rKXrFfUnbtVL
# xFOKhJByuAt41s5GdVJssNwhdVLqJ0ebeIBpvSAeNIdWTiHPuAkiiKYWM+mpSFqe
# Ogzd7hk/OuI26alUjBEkOJCx2AEe1P31MwB2n4c1NkJJPaZ9h7fYVwmec1YasqXN
# 4x/+8y8cwi/g5DBNyvNToL6yUqZS0e3svqrW2gKOQNAN+QpDM0Tf/Xxr4zKTBRRK
# 0DhVAG5qWgNh35vgJnpUAj22AZ8++fLTUiVtLQebEJsyzeliDnHxfF1vPbmYYgT5
# SvK0HXIbIeBv6f7HMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOkZDNDEtNEJENC1EMjIwMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBB33iP2WWCQDtkZKLU
# XodkQcCcTaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q8OBzAiGA8yMDE5MDgyNzEwMDM1MVoYDzIwMTkwODI4
# MTAwMzUxWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhDw4HAgEAMAoCAQACAigv
# AgH/MAcCAQACAhGdMAoCBQDhEF+HAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAiP/TwdSIOpO3qVr8UpfBjz5S8sVsiJLJ8gl7Uu9iH4nmmrHQMHCB8HGveYOR
# BcH3Y5KfYlZYmmWXtM1RtWQruBfaOw9LA3defYVwtRA5mrHrF971K1kLoqJsmZ83
# e1K1/QZMtwkH1npJL2osDu/s0EYETCD4Y2naG0vAy6yGOrcxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAOGcqCPPPSEhhwAA
# AAAA4TANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCBIZ98Lp+IR8A8raSzy4Uv28R03JUXOAPfQq3i3
# RuQeODCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EILxo72txumUJwo/jS6KP
# Un9+XDxQXc4BaS+pMzwzr2zeMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAADhnKgjzz0hIYcAAAAAAOEwIgQgtL+h+Hn1YIW9UmbGYSoe
# QJ11j2alV5Cm2PiKvH+r/zIwDQYJKoZIhvcNAQELBQAEggEAj3xzZkVljCjrdFjm
# WnMTdtDuM8EfbwmSA676HmYbRcf+LSKeDUHIlKk2tpAAd66lnnzavSuXSgSgrOJM
# QeeepG8YvAjg2QP6L+rHbpQibwpnGkFZEmo8Wc6X6uNAiNE4TEVYEXrzZy3ARPUH
# dHl/3IiiCPETUdNCLZsRYHJdhnZqwyBIKpRQCuh1oCR3wsJDsaptpsvWdtnJc2UM
# ACkubmYx3Bfz3K03s7Xx7cHm7d14ls8xdhZB69vYHqEzKd6BQK0BXPmSWifsiPlw
# tocsPmtmeNnwBCRvpiCpqZombmwbnB/3p19PgiXXOUH7DeJolDeomiAUHhwiSOnf
# Ns7SlQ==
# SIG # End signature block
