<#
	Common DVT Script Setup to be dot-sourced by DVT scripts

	Implementation Notes:
	* $scriptName must be defined before dot-sourcing: $scriptName = (Get-Item $PSCommandPath).BaseName
	* ScriptSetup.ps1 must be dot-sourced before this script (note: params need to be defined, see ScriptSetup.ps1 for details)
#>
$script:AutoFailedResultMessage = 'Auto-failed due to failure of prerequisite test'
#region Helper Functions
<#
	.Synopsis
	Get the value of a parameter from the DVT input XML
#>
function Get-DVTParameterValue
{
	[CmdletBinding()]
	[OutputType([string])]
	Param
	(
		# The object containing DVT parameters
		[pscustomobject]
		[ValidateNotNull()]
		$Params,

		# Name of the parameter to access
		[string]
		[ValidateNotNullOrEmpty()]
		$ParameterName
	)

	$parameter = $Params.$ParameterName
	if (!$parameter)
	{
		Write-LogMessage -Message "DVT value not found: $ParameterName"
		return $null
	}

	return $parameter
}

<#
	.Synopsis
	Returns the XML output file and creates the containing directory if needed
#>
function Get-XmlOutputFilePath
{
	[CmdletBinding()]
	[OutputType([string])]
	Param
	(
		# The directory to place the XML output file into. If it does not exist it will be created.
		[string]
		[ValidateNotNullOrEmpty()]
		$XmlOutputDirectory,

		# The name of the service model being tested.
		[string]
		[ValidateNotNullOrEmpty()]
		$ScriptName
	)

	if(!(Test-Path -Path $XmlOutputDirectory))
	{
		[void](New-Item -Path $XmlOutputDirectory -ItemType Directory)
	}

	return Join-Path -Path $XmlOutputDirectory -ChildPath "$((Get-Date).ToFileTimeUtc())_$ScriptName.xml"
}

<#
	.Synopsis
	Creates a new test result
#>
function New-TestResult
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	Param
	(
	)

	<#
		Implementation Notes:
			* Reason for New-Module -AsCustomObject vs pscustomobject, property types can be enforced
			* All properties must be initialized with a valid instance of its type otherwise type enforcement won't occur
			* Function names can't have dashes because they get turned into ScriptMethods
	#>
	$result = New-Module -ScriptBlock {
			[string]$TestName = ''
			[string]$TestType= 'DVT'
			[bool]$TestResult = $false
			[System.Text.StringBuilder]$ResultOutput = New-Object System.Text.StringBuilder
			[datetime]$Timestamp = Get-Date

			function AddOutput
			{
				[CmdletBinding()]
				Param
				(
					[string]
					$Message
				)

				if($Message)
				{
					[void]($this.ResultOutput.AppendLine($Message))
				}
			}

			Export-ModuleMember -Function * -Variable *
		} -AsCustomObject
	# StringBuilder can be casted to [string] but it could add extra lines to the output, so a ScriptProperty is added to prevent the extra lines
	$result | Add-Member -MemberType ScriptProperty -Name 'RawResult' -Value { $this.ResultOutput.ToString().Trim() }
	$result | Add-Member -MemberType ScriptProperty -Name 'Summary' -Value { ($this | fl -Property TestName, TestType, TestResult, Timestamp, RawResult | Out-String).Trim() }
	return $result
}

<#
	.Synopsis
	Creates a new result collection
#>
function New-ResultsCollection
{
	[CmdletBinding()]
	[OutputType([pscustomobject])]
	Param
	(
	)

	$collection = New-Module -ScriptBlock {
			[bool]$OverallResult = $true
			[pscustomobject[]]$Results = @()
			[int]$Passed = 0
			[int]$Failed = 0
			[int]$Total = 0

			function Add
			{
				[CmdletBinding()]
				Param
				(
					[pscustomobject]
					[ValidateNotNull()]
					$Result
				)

				$this.Results += $Result
				$this.Total += 1
				if($Result.TestResult)
				{
					$this.Passed += 1
				}
				else
				{
					$this.OverallResult = $false
					$this.Failed += 1
				}
			}

			Export-ModuleMember -Function * -Variable *
		} -AsCustomObject
	$collection | Add-Member -MemberType ScriptProperty -Name 'Summary' -Value { "Passed: $($this.Passed) ($(($this.Passed / $this.Total).ToString('P'))) Failed: $($this.Failed) ($(($this.Failed / $this.Total).ToString('P')))" }
	return $collection
}

<#
	.Synopsis
	Invokes a test and returns a test result containing the outcome or adds it a test run
	Handles 90% of results, one-offs can use use New-TestResult directly
#>
function Invoke-Test
{
	[CmdletBinding()]
	Param
	(
		# Name of the test
		[string]
		[ValidateNotNullOrEmpty()]
		$TestName,

		# Actual result, scriptblock should return this result
		[scriptblock]
		[ValidateNotNull()] 
		$Actual,

		# Expected result
		[ValidateNotNull()]
		$Expected = $true,

		# Use regex match instead of equals
		[switch]
		$MatchRegex,

		# Message to display if the test fails
		[string]
		$Message,

		# Indicates to fail the test fast
		[switch]
		$FailFast,

		# Test run to add result to
		[pscustomobject]
		$AddToRun,

		# Indicates to return the test result even if its being added to a test run
		[switch]
		$PassThru,

		# Indicates to write the expected result even if the test passes
		[switch]
		$WriteMessageOnSuccess
	)

	$result = New-TestResult
	$result.TestName = $TestName
	if($FailFast)
	{
		Write-LogMessage -Message "Failing test '$TestName' fast"
		$result.AddOutput($AutoFailedResultMessage)
		return $result
	}

	Write-LogMessage -Message "Executing test '$TestName'"
	$actualResult = &$Actual
	if($MatchRegex)
	{
		$result.TestResult = $actualResult -match $Expected
	}
	else
	{
		$result.TestResult = $actualResult -eq $Expected
	}
	
	Write-LogMessage -Message "Test '$TestName' outcome: $($result.TestResult)"
	if($WriteMessageOnSuccess -or !$result.TestResult)
	{
		if($Message)
		{
			$result.AddOutput($Message)
		}
	}

	if(!$result.TestResult)
	{
		$result.AddOutput("Executed: $Actual" )
		$result.AddOutput("Expected: $Expected")
		$result.AddOutput("Actual: $actualResult")
		Write-LogMessage -Message $result.RawResult -Error
	}

	if($AddToRun)
	{
		$AddToRun.Add($result)
	}
	
	if($PassThru -or !$AddToRun)
	{
		return $result
	}
}

<#
	.Synopsis
	Adds an exception test result to the test run
#>
function Add-ExceptionFailureToTestRun
{
	[CmdletBinding()]
	Param
	(
		# Exception to add into the test result
		$Exception,
		
		# Name of the test or script
		$TestName,

		# Test run to add result to
		[pscustomobject]
		[ValidateNotNull()]
		$AddToRun
	)

	# By design to not add types and validate attributes except for AddToRun, could cause an exception to occur inside an exception block
	$failedCount = $AddToRun.Failed
	try
	{
		$result = New-TestResult
		$result.TestName = $TestName
		$errorDetail = Write-ErrorDetail -ErrorThrown $Exception -WriteToConsole -PassThru
		$result.AddOutput($errorDetail)
		$AddToRun.Add($result)
	}
	catch
	{
		if($failedCount -eq $AddToRun.Failed)
		{
			$AddToRun.Failed += 1
		}

		# Bad scenario to be in, just log and the overall test run should fail
		Write-LogMessage -Message "Failed to add error detail to test run: $_" -Error
	}
}

<#
	.Synopsis
	Adds a row to the XML output file.
	Do not pipe an array of results to this function, it cannot handle being multi-threaded
#>
function Add-ResultToOutputXml
{
	[CmdletBinding()]
	Param
	(
		# Name of the test
		[string]
		[ValidateNotNullOrEmpty()] 
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		$TestName,

		# Test type. DVT, CVT, etc
		[string]
		[ValidateNotNullOrEmpty()] 
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		$TestType,

		# Result of the test
		[bool]
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		$TestResult,

		# Raw result of the test
		[string]
		[ValidateNotNull()]
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		$RawResult,

		# Timestamp that the test ran
		[datetime]
		[ValidateNotNull()] 
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		$TimeStamp,

		# Xml file to append the data too
		[xml]
		[ValidateNotNull()]
		$XmlTemplate
	)

	Write-LogMessage -Message 'Getting existing rows from XML Template'
	$rows = $XmlTemplate.SelectSingleNode('CollectionResult/TabularResults/TabularData/Rows')
	Write-LogMessage -Message 'Creating new row'
	$row = $XmlTemplate.CreateElement('ArrayOfStrings')
	Write-LogMessage -Message "Adding column value for TestName: $TestName"
	$column = $XmlTemplate.CreateElement('string') # TestName
	$column.InnerText = $TestName
	[void]($row.AppendChild($column))
	Write-LogMessage -Message "Adding column value for TestType: $TestType"
	$column = $XmlTemplate.CreateElement('string') # TestType
	$column.InnerText = $TestType
	[void]($row.AppendChild($column))
	Write-LogMessage -Message "Adding column value: $([int]$TestResult)"
	$column = $XmlTemplate.CreateElement('string') # TestResult
	$column.InnerText = [int]$TestResult
	[void]($row.AppendChild($column))
	$RawResult = $RawResult.Trim()
	Write-LogMessage -Message "Adding column value for RawResult."
	$column = $XmlTemplate.CreateElement('string') # RawResult
	$column.InnerText = $RawResult
	[void]($row.AppendChild($column))
	Write-LogMessage -Message "Adding column value for TimeStamp: $TimeStamp"
	$column = $XmlTemplate.CreateElement('string') # TimeStamp
	$column.InnerText = $TimeStamp.ToString()
	[void]($row.AppendChild($column))
	Write-LogMessage -Message 'Adding row to collection of rows'
	[void]($rows.AppendChild($row))
	Write-LogMessage -Message 'Adding collection of rows to table'
	[void]($XmlTemplate.CollectionResult.TabularResults.TabularData.AppendChild($rows))
}

<#
	.Synopsis
	Get XML Output Template
#>
function Get-XmlOutputTemplate
{
	[CmdletBinding()]
	[OutputType([xml])]
	Param
	(
		# Name of the collector
		[string]
		[ValidateNotNullOrEmpty()]
		$CollectorName,

		# Type of collector. Default is 'PowerShellCollector'.
		[string]
		[ValidateNotNullOrEmpty()]
		$CollectorType = 'PowerShellCollector',

		# Name of the target being tested
		[string]
		[ValidateNotNullOrEmpty()]
		$TargetName = $env:COMPUTERNAME
	)

	return [xml]@"
<?xml version="1.0"?>
<CollectionResult xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
	<CollectorName>$CollectorName</CollectorName>
	<CollectorType>$CollectorType</CollectorType>
	<ErrorMessages />
	<TabularResults>
	<TabularData>
		<TargetName>$TargetName</TargetName>
		<Columns>
		<string>TestName</string>
		<string>TestType</string>
		<string>PassResult</string>
		<string>RawResult</string>
		<string>TimeStamp</string>
		</Columns>
		<Rows>
		</Rows>
	</TabularData>
	</TabularResults>
</CollectionResult>
"@
}

<#
	.Synopsis
	Decrypt an encrypted string from XML input file
#>
function Unprotect-EncryptedString
{
	[CmdletBinding()]
	[OutputType([string])]
	Param
	(
		[securestring]
		[ValidateNotNull()]
		$EncryptedString
	)

	$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($EncryptedString)
	$decryptedString = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
	[System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR)
	return $decryptedString
}

<#
	.Synopsis
	Executes the given logic in a retry loop
#>
function Invoke-RetryLoop
{
	[CmdletBinding()]
	Param
	(
		# How many times to retry
		[int]
		[ValidateNotNull()]
		$RetryCount,
		
		# How long in seconds to delay between retries
		[int]
		[ValidateNotNull()]
		$DelayInSeconds,

		# Action to retry. Should return a boolean indicating if the action was 
		# successful (and therefore no more retries are required).
		[scriptblock]
		[ValidateNotNull()] 
		$Action
	)
	
	[bool]$success = $false
	while ($RetryCount -gt 0 -and !$success)
	{
		Write-LogMessage -Message "Executing retry loop. Retry count is $RetryCount"
		$success = Invoke-Command -ScriptBlock $Action
		if (!$success)
		{
			$RetryCount -= 1
			Start-Sleep -Seconds $DelayInSeconds
		}
	}

	return $success
}
#endregion

function Initialize-DVTScript
{
	Write-LogMessage -Message "Running $scriptName DVT Script"
	Import-MRDeployModule
	if (!(Get-Command 'Invoke-SqlQuery' -ErrorAction SilentlyContinue))
	{
		Write-LogMessage -Message 'DVTs are not supported on this version. Exiting.' -Warning
		exit
	}

	Write-LogMessage -Message 'Loading parameters from database and deployed config files'
	$script:currentFolder = (Get-ChildItem -Path (Split-Path -Path $PSScriptRoot -Parent) -Recurse -Filter DVTScriptSetup.ps1 | Select-Object -First 1).Directory.FullName
	$loadParamsPath = Join-Path -Path $script:currentFolder -ChildPath "LoadParams.ps1"
	$loadParamsPath = Resolve-Path -Path $loadParamsPath
	. $loadParamsPath -InstallPaths (Get-MRFilePaths)
	Initialize-DVTParams

	$script:installPath = Get-DVTParameterValue -Params $DVTParams -ParameterName 'MR.InstallPath'
	$script:xmlOutputPath = Get-DVTParameterValue -Params $DVTParams -ParameterName 'OutputPath'
	$script:serviceModelName = Get-DVTParameterValue -Params $DVTParams -ParameterName 'ServiceModelName'
	$script:xmlFilePath = Get-XmlOutputFilePath -XmlOutputDirectory $xmlOutputPath -ScriptName $scriptName
	[xml]$script:xmlTemplate = Get-XmlOutputTemplate -CollectorName "$serviceModelName.DVT"
	Write-LogMessage -Message 'Setting up results collection'
	$script:resultsCollection = New-ResultsCollection
	Write-LogMessage -Message 'Loading Deployment.Common'
	Add-Type -Path (Join-Path -Path  (Get-MRFilePaths).Server -ChildPath 'Console\Microsoft.Dynamics.Performance.Deployment.Common.dll')
	Write-LogMessage -Message 'Loading Instrumentation.dll'
	Add-Type -Path (Join-Path -Path  (Get-MRFilePaths).Server -ChildPath 'Console\Microsoft.Dynamics.Reporting.Instrumentation.dll')

	# Force TLS settings to first attempt TLS1.2, then fall back to TLS1.1 and TLS1.0.
	# This is currently required because the BI machines are configured for TLS1.0/SSL3 while the AOS machines are configured for TLS1.2
	# When SSRS is updated to support TLS1.2, then BI machines will be updated as well and this line can be removed.
	Write-LogMessage -Message 'Setting TLS security protocol'
	[System.Net.ServicePointManager]::SecurityProtocol = ([System.Net.ServicePointManager]::SecurityProtocol -band (-bnot[System.Net.SecurityProtocolType]::Ssl3)) -bor [System.Net.SecurityProtocolType]::Tls12 -bor [System.Net.SecurityProtocolType]::Tls11 -bor [System.Net.SecurityProtocolType]::Tls

	# Set certificate policy so if we use localhost for service calls certificate validation allows for a name mismatch
	Write-LogMessage -Message 'Setting certificate validation policy'
	[Microsoft.Dynamics.Performance.Core.CertificateManager]::SetHttpsCertificateValidationPolicy()

	# Start process service in BI and Onebox machines.
	try
	{
        $autoStartMRProcessServiceScriptPath = Join-Path -Path $script:currentFolder -ChildPath "AutoStartMRProcessService.ps1"
        if(Test-Path -Path $autoStartMRProcessServiceScriptPath)
        {
            & $autoStartMRProcessServiceScriptPath
        }
	}
	catch
	{
		Write-LogMessage -Message "Exception thrown when trying to start the process service."
		Write-LogMessage -Message ($_.ToString()) -Warning
	}
}
# SIG # Begin signature block
# MIIjnQYJKoZIhvcNAQcCoIIjjjCCI4oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAlRNM6hEcjnuif
# 2l5wlf8s05IhnTLMrvdvlgv8w33knKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVcjCCFW4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgbIWuUKqZ
# 5R7csw7dEWdeyN63iEcIuoL3Z+Ito8b5/+8wXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAGkpfVez
# OrYp4vH/Mk2+Rc1NTyclZVs/RmhSUm5XTyZFQVtRsv4u25PQzmJx2IcyuuqFAkoT
# TvxOtmKDsuHQDBvVnar/ETfIiHTW0NTGjcCiesohF8gqmuQR+8GSP8A4mGd0TbZn
# +blY7ASCtO+e/Eok8vLs96rX+lzEE8HCj88lhV4CxBtkj8mpH70Ax9oQPfvGPXgl
# Xy8zJ+kSbBOx8XDplNm7xcC/CItSpLlo42K7xnc6fB0fMIxaAt03LNhgvRA2U/+z
# 1Lzvh/Ks0Arnu+z7Cs5/MnucYhjHRo6SHe2wmV27RO3tKgRb/7xGkzmdKVdcxHrf
# BB7NBhBFW64EfGahghLiMIIS3gYKKwYBBAGCNwMDATGCEs4wghLKBgkqhkiG9w0B
# BwKgghK7MIIStwIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgFcQ9
# yzf8E2fnaVQyTShyFIe3/l96JK+ACys6ch+3nUoCBl1exl4mQxgTMjAxOTA4Mjcw
# NzIzMzYuODI2WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00QkIwLTgyNDYxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg45MIIE8TCCA9mg
# AwIBAgITMwAAANuqbeMifzQAJQAAAAAA2zANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTNaFw0xOTExMjMy
# MDI2NTNaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKehmpAMmCSLSzZuzf07rE9UXP5TCqLREDDOqiAw3pa5kSYKdRAwnQmvAw4l
# FA2cTfCLjFL9znS3+J+8CWG2iynHEIirVgkDr6nG18H28rvG7djdoROqHWNmY8yz
# P3YF+kiIv5Rq7gfXYCYsb+0yG37xgW6DfSLHBN8oJq0GZ3c75J4SiGViIF/3tolU
# P2s9I+UpZSGsOR2lRQyxBhTTdavvriKURstRz3PA//P/rC08j5GpNfzft9Sq5TjK
# UPkXvT+uRGHordY6sdaxCqLjvoEYYo2NDKLCXEPC3m8LBSK7WV0CTSwj3AqJNC/s
# ehs2+i3ZF29kczH1itOzJS+qTQsCAwEAAaOCARswggEXMB0GA1UdDgQWBBSyut8d
# gFxzps227eQcjK3eKkMDSDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAVQsKa
# nb0ZYH4iR4kk6YGV1V5uV2NRm/pH7JeTWTFMWGkgFQH9AJkU5E+uEfLgjrdQMq/N
# ycE4QIq0cb0HVnYOKPGnivFDhmadZH1aBQWQf/DlviyHGhID9faqntPOAtm51jAG
# vno7H4xGzd7SzmsvA9hgw9zrdsiCtkx1s5uCPcVFdEAFi+oS9NLk2NFC5utPK6JH
# ONLkFNDpBBYsv5Pd1D2DyY1JPgShshDRr/UxV4bcM+EHGMKXRmeuwMAdEYk+3a3q
# MopMRt9sZIrIo3H6w23Q7LREZqlcuBrMXxT8pOXlUqUfWFi/j3vr8hoP8EJzHJZR
# rkq/cJk6WlRkPSGLMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICyzCCAjQCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjE3OUUtNEJCMC04MjQ2MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBbpSlOrxis+HA8JE9q
# RFutb8fbMKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q8zizAiGA8yMDE5MDgyNzEyNDM1NVoYDzIwMTkwODI4
# MTI0MzU1WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDhDzOLAgEAMAcCAQACAgL/
# MAcCAQACAhF0MAoCBQDhEIULAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQB
# hFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEA
# Y+m4ZZ+zsua4toNhjqjR3iyRFq9wRnhHAk4p++ffJ9kobp4lm+FLGNHzk/+FLX5E
# blnqUn24TaSZ/rzcRFMil0rqbN1boY/m3/72Wi3FTEdx7FjEpcp3iKqUkn3J/SRR
# bhrXaij7TyqkUzRlcotlJMUE+eLuBZKC3f+H6Az4mmAxggMNMIIDCQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANuqbeMifzQAJQAAAAAA
# 2zANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCCcpXKYlNhO3DGOYpVyHuVgvaqAkyaBflguoyYO+17P
# yTCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIAJTHbHTmAEtIrVqIyVjsIt9
# R7biILf8sPry650hjP6qMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAADbqm3jIn80ACUAAAAAANswIgQgDiOaAcmTkHog5c3FOzsDtysK
# XPT7apkfVPqtcVrCxKgwDQYJKoZIhvcNAQELBQAEggEAdQOcgjMIxDAikav/6zRY
# XfX7kY3T+JUmR49ktJNWOjZJ5rbM4JdSd/qy7dZnqEjQIdNoYEtebtEkCuXZ2oZd
# gltkkAcXBaaGE/Z+SdHG120uPluNob0WmwB/RnoxKsJjTHGvyNvwoVZfIPwbA13L
# sfXlJvSAY2OBTOSX8mvsa2scyLmrNBoLDndNASgZef0/6yvHHuIo2QfUeb5Ph3DS
# 2CGpKPKeoSF8u/ka33Lm5c6IldVrInV4f4qjg423ArDLj1K7mWQYhGMKNgVEFTvx
# Xipe7aOabT1mcrcZQVZbTGzL7ukOm44nbllID0+uVq+scrUqxVy4/SF8HNC2MRj4
# 5w==
# SIG # End signature block
